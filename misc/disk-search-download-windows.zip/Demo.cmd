@echo off
start "" "%~dp0disk-search-download.exe" --demo
