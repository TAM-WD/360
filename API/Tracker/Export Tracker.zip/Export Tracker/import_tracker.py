#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
Скрипт предназначен для импорта экспортированных задач из скрипта export_tracker.py

При импорте скрипт подключается по OAuth токену, проверяет, что очередь с новым ключом ещё не существует и создаёт новую очередь-копию с новым ключом, с заданным названием, с базовыми 
настройками исходной очереди. Затем скрипт создаёт в новой очереди все задачи из экспорта, каждая задача получает новый ключ в целевой очереди. После создания задач скрипт обновляет их и переносит 
содержимое задачи, затем добавляет комментарии и вложения. После создания всех задач скрипт восстанавливает связи между ними и статусы

Скрипт не удаляет задачи, не изменяет другие очереди, не работает с очередями, не связанными с переносом, импортирует данные только в новую очередь с новым ключом.

Скрипт ограничен по RPS: 10 RPS на запросы по поиску задач в очереди (максимум можно выставить 20 RPS), и 60 RPS на все остальные запросы (максимум может быть 100).

Перед каждым новым импортом в новую очередь рекомендуется удалять папку export_data/_import_state и делать экспорт заново

При каждом импорте TARGET_QUEUE_KEY должен быть уникальным

В ходе работы скрипта будет перенесено:
-очередь
-задачи
-описания
-типы
-приоритеты
-теги
-статусы
-комментарии
-вложения
-связи
-parent
-часть простых кастомных полей
Не перенесётся:
• пользователи ( автор, исполнитель, наблюдатель, призывы как реальные пользователи и тд)
• системные даты и авторы
• история изменений
• проекты/спринты/компоненты/версии
• часть сложных кастомных полей
• настройки очереди: триггеры,автодействия, макросы и т.д.

При этом к каждому комментарию, который будет добавлен при переносе от имени владельца очереди, будет указано, кто его оставил ранее и когда. Пример с переносом обычного комментария "test":
Оригинальный автор: Иван Иванов
Оригинальная дата: 2026-04-22T11:17:52.918+0000

test

Также не сохранятся ключи задач в первоначальном виде. Например, была задача TEST-1, она может стать задачей TEST-2. Также не сохраняется автор, наблюдатели и исполнитель
В задаче будет указана такая подпись в описании задачи: 
Original issue key: TEST-1 
Original queue key: TEST
Original author: Иван Иванов
Original followers: Данил Данилов

Для работы скрипта понадобится заполнить:
• ORGID - ID организации (облачной или со стороны Яндекс 360)
• TOKEN - токен администратора организации ( токен для облачной организации выдается другим способом). У приложения указанного токена должны быть права tracker:read и tracker:write
• ORG_TYPE - X-Org-ID для Яндекс 360 и X-Cloud-Org-ID для Яндекс Cloud
• SOURCE_QUEUE_KEY - Ключ очереди, которую планируется импортировать из экспортированных данных
• TARGET_QUEUE_KEY - Ключ, с которым будет создана новая очередь в целевой организации при импорте задач
• TARGET_QUEUE_NAME - Название очереди для импорта задач
• INPUT_DIR - Название папки, из которой будет происходить импорт
• QUEUE_LEAD - Логин владельца созданной очереди (без доменной части)
'''

import json
import time
import random
import logging
import threading
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

# =========================================================
# НАСТРОЙКИ ИМПОРТА
# =========================================================

ORGID = '8260785'
# ID целевой организации, куда импортируем

TOKEN = 'y0__wgBEO...'
# OAuth токен целевой организации

ORG_TYPE = 'X-Org-ID'
# Тип организации:
# 'X-Org-ID'       -> Яндекс 360
# 'X-Cloud-Org-ID' -> Cloud Organization

SOURCE_QUEUE_KEY = 'OCHERED'
# Ключ очереди в экспортированных данных

TARGET_QUEUE_KEY = 'TARGETOCHERED'
# Новый ключ очереди в target.
# Должен быть новым и не существовать заранее.

TARGET_QUEUE_NAME = 'Targetochered'
# Название новой очереди в target

INPUT_DIR = 'export_data'
# Папка с экспортированными данными

QUEUE_LEAD = 'ivanovav'
# ЛОГИН владельца новой очереди В ЦЕЛЕВОЙ ОРГАНИЗАЦИИ.
# БЕЗ доменной части.

# Параллелизм.
# Создание задач намеренно последовательное — см. create_all_issues()
MAX_WORKERS_PATCH = 8       # патч задач
MAX_WORKERS_COMMENTS = 4    # комментарии (тяжелее из-за вложений)
MAX_WORKERS_ATTACHMENTS = 4 # вложения
MAX_WORKERS_LINKS = 8       # связи
MAX_WORKERS_STATUS = 4      # статусы (требуют последовательных переходов)

# Лимиты ниже максимальных
SEARCH_RPS = 10       # поиск задач максимум 20 rps по API
DEFAULT_RPS = 60      # остальное максимум 100 rps по API

MAX_RETRIES = 6
API_BASE = 'https://api.tracker.yandex.net/v3'

# =========================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)
logger = logging.getLogger('tracker_import')


SYSTEM_SKIP_FIELDS = {
    'self', 'id', 'key', 'version', 'createdAt', 'updatedAt',
    'createdBy', 'updatedBy', 'lastCommentUpdatedAt',
    'status', 'previousStatus', 'favorite', 'votes', 'aliases',
    'queue', 'assignee', 'author', 'followers', 'project', 'sprint',
    'resolution', 'resolvedAt', 'resolvedBy', 'statusStartTime',
    'statusType', 'boards', 'commentWithoutExternalMessageCount',
    'commentWithExternalMessageCount'
}


def ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


def load_json(path: Path, default=None):
    if path.exists():
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return default


def save_json(path: Path, data):
    ensure_dir(path.parent)
    tmp = path.with_suffix('.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(path)


class RateLimiter:
    def __init__(self, rate_per_sec: float):
        self.rate = rate_per_sec
        self.capacity = 1.0
        self.tokens = 1.0
        self.updated_at = time.monotonic()
        self.lock = threading.Lock()

    def acquire(self):
        while True:
            with self.lock:
                now = time.monotonic()
                elapsed = now - self.updated_at
                self.updated_at = now
                self.tokens = min(self.capacity, self.tokens + elapsed * self.rate)

                if self.tokens >= 1:
                    self.tokens -= 1
                    return

                need = (1 - self.tokens) / self.rate

            # Спим точное время снаружи лока
            time.sleep(need)


class TrackerClient:
    def __init__(self, org_id: str, token: str, org_type: str):
        self.base_url = API_BASE
        self.session = requests.Session()
        self.session.headers.update({
            org_type: org_id,
            'Authorization': f'OAuth {token}'
        })

        self.search_limiter = RateLimiter(SEARCH_RPS)
        self.default_limiter = RateLimiter(DEFAULT_RPS)

    def _choose_limiter(self, path: str):
        if path == '/issues/_search':
            return self.search_limiter
        return self.default_limiter

    def request(self, method: str, path: str, **kwargs):
        url = f'{self.base_url}{path}'
        limiter = self._choose_limiter(path)

        for attempt in range(1, MAX_RETRIES + 1):
            limiter.acquire()
            try:
                resp = self.session.request(method, url, timeout=120, **kwargs)

                if resp.status_code == 429:
                    retry_after = int(resp.headers.get('Retry-After', '3'))
                    sleep_s = retry_after + random.uniform(0.1, 0.7)
                    logger.warning(f'429 on {method} {path}, sleep {sleep_s:.2f}s')
                    time.sleep(sleep_s)
                    continue

                if 500 <= resp.status_code < 600:
                    sleep_s = min(2 ** attempt, 20) + random.uniform(0.1, 0.5)
                    logger.warning(f'{resp.status_code} on {method} {path}, retry {attempt}/{MAX_RETRIES}')
                    time.sleep(sleep_s)
                    continue

                return resp

            except (requests.ConnectionError, requests.Timeout) as e:
                sleep_s = min(2 ** attempt, 20) + random.uniform(0.1, 0.5)
                logger.warning(f'Network error on {method} {path}: {e}, retry {attempt}/{MAX_RETRIES}')
                time.sleep(sleep_s)

            except requests.RequestException as e:
                raise RuntimeError(f'Request failed {method} {path}: {e}') from e

        raise RuntimeError(f'Request failed after retries: {method} {path}')

    def get(self, path, params=None):
        return self.request('GET', path, params=params)

    def post(self, path, params=None, json_data=None, files=None, data=None):
        if files is not None:
            return self.request('POST', path, params=params, files=files, data=data)
        return self.request('POST', path, params=params, json=json_data)

    def patch(self, path, params=None, json_data=None):
        return self.request('PATCH', path, params=params, json=json_data)


def topological_sort_issues(issues):
    key_to_issue = {i['key']: i for i in issues}
    order = []
    visited = set()
    visiting = set()

    def visit(key):
        if key in visited:
            return
        if key in visiting:
            # Цикл в иерархии — просто добавляем как есть
            logger.warning(f'Cycle detected in parent hierarchy at {key}, skipping')
            return
        visiting.add(key)
        issue = key_to_issue.get(key)
        if issue:
            parent_key = (issue.get('parent') or {}).get('key')
            if parent_key and parent_key in key_to_issue:
                visit(parent_key)
        visiting.discard(key)
        visited.add(key)
        order.append(key)

    for issue in issues:
        visit(issue['key'])

    key_to_pos = {k: i for i, k in enumerate(order)}
    return sorted(issues, key=lambda i: key_to_pos.get(i['key'], len(order)))


def relationship_from_link(link):
    type_id = (link.get('type') or {}).get('id')
    direction = link.get('direction')

    if type_id == 'relates':
        return 'relates'
    if type_id == 'subtask':
        return 'is parent task for' if direction == 'outward' else 'is subtask for'
    if type_id in ('dependency', 'depend'):
        return 'is dependent by' if direction == 'outward' else 'depends on'
    if type_id in ('duplicate', 'duplicates'):
        return 'is duplicated by' if direction == 'outward' else 'duplicates'
    if type_id == 'epic':
        return 'is epic of' if direction == 'outward' else 'has epic'
    return None


class Importer:
    def __init__(self, client: TrackerClient, input_dir: Path, queue_lead: str):
        self.client = client
        self.input_dir = input_dir
        self.queue_lead = queue_lead

        self.state_dir = input_dir / '_import_state'
        ensure_dir(self.state_dir)

        # Единый лок для issue_map — покрывает и словарь и запись файла
        self._issue_map_lock = threading.Lock()
        self._links_lock = threading.Lock()

        self.issue_map = load_json(self.state_dir / 'issue_map.json', {})
        self.created_links = set(load_json(self.state_dir / 'created_links.json', []))

        self.global_fields = load_json(input_dir / 'fields' / 'global_fields.json', [])
        self.global_field_map = {}
        for fld in self.global_fields:
            self.global_field_map[fld['key']] = fld

    def _save_issue_map(self):
        """Вызывать только под _issue_map_lock."""
        save_json(self.state_dir / 'issue_map.json', self.issue_map)

    def _save_links(self):
        """Вызывать только под _links_lock."""
        save_json(self.state_dir / 'created_links.json', sorted(self.created_links))

    def save_state(self):
        with self._issue_map_lock:
            self._save_issue_map()
        with self._links_lock:
            self._save_links()

    def queue_exists(self, queue_key: str):
        resp = self.client.get(f'/queues/{queue_key}')
        return resp.status_code == 200

    def ensure_target_queue_does_not_exist(self, queue_key: str):
        if self.queue_exists(queue_key):
            raise RuntimeError(
                f'ОПАСНО: очередь {queue_key} уже существует в целевой организации. '
                f'Импорт остановлен, чтобы не записывать данные в существующую очередь.'
            )

    def create_target_queue(self, source_queue_key: str, target_queue_key: str, target_queue_name: str):
        src_queue = load_json(self.input_dir / 'queues' / f'{source_queue_key}.json')
        if not src_queue:
            raise RuntimeError(f'Missing queue definition: {source_queue_key}')

        issue_types_config = []
        for item in src_queue.get('issueTypesConfig', []):
            issue_type = item.get('issueType', {}).get('key')
            workflow = item.get('workflow', {}).get('id')
            resolutions = [r.get('key') for r in item.get('resolutions', []) if r.get('key')]
            if issue_type and workflow:
                issue_types_config.append({
                    'issueType': issue_type,
                    'workflow': workflow,
                    'resolutions': resolutions
                })

        body = {
            'key': target_queue_key,
            'name': target_queue_name,
            'lead': self.queue_lead,
            'defaultType': src_queue['defaultType']['key'],
            'defaultPriority': src_queue['defaultPriority']['key'],
            'issueTypesConfig': issue_types_config
        }

        logger.info(f'Creating queue {target_queue_key} with lead={self.queue_lead}')
        resp = self.client.post('/queues/', json_data=body)
        if resp.status_code != 201:
            raise RuntimeError(f'Create queue failed {target_queue_key}: {resp.status_code} {resp.text}')
        logger.info(f'Target queue created: {target_queue_key}')

    def load_source_issues(self, source_queue_key):
        issue_keys = load_json(self.input_dir / '_meta' / f'{source_queue_key}_issues.json', [])
        issues = []
        for k in issue_keys:
            issue = load_json(self.input_dir / 'issues' / f'{k}.json')
            if issue:
                issues.append(issue)
        return topological_sort_issues(issues)

    def create_issue_minimal(self, issue, target_queue_key):
        body = {
            'queue': target_queue_key,
            'summary': issue.get('summary') or '(no summary)'
        }

        if issue.get('type') and issue['type'].get('key'):
            body['type'] = issue['type']['key']

        if issue.get('priority') and issue['priority'].get('key'):
            body['priority'] = issue['priority']['key']

        resp = self.client.post('/issues/', params={'notify': 'false'}, json_data=body)
        if resp.status_code != 201:
            raise RuntimeError(f'Create issue failed {issue["key"]}: {resp.status_code} {resp.text}')

        return resp.json()

    def create_all_issues(self, source_queue_key, target_queue_key):
        """
        Создание задач выполняется последовательно, а не параллельно.
        Это критично для корректного построения issue_map при parent-иерархии:
        топологическая сортировка гарантирует порядок только при последовательном создании.
        """
        issues = self.load_source_issues(source_queue_key)
        errors = []

        for idx, issue in enumerate(issues, start=1):
            old_key = issue['key']
            try:
                with self._issue_map_lock:
                    if old_key in self.issue_map:
                        logger.info(f'[create] {idx}/{len(issues)} {old_key} already in map, skip')
                        continue

                created = self.create_issue_minimal(issue, target_queue_key)
                new_key = created['key']

                with self._issue_map_lock:
                    self.issue_map[old_key] = new_key
                    self._save_issue_map()

                logger.info(f'[create] {idx}/{len(issues)} {old_key} -> {new_key}')

            except Exception as e:
                logger.error(f'[create] failed {old_key}: {e}')
                errors.append({'issue': old_key, 'error': str(e)})

        save_json(self.state_dir / 'create_errors.json', errors)

    def is_simple_supported_field(self, field_key, value, local_field_map):
        if field_key in SYSTEM_SKIP_FIELDS:
            return False
        if value is None:
            return False

        meta = local_field_map.get(field_key) or self.global_field_map.get(field_key)
        if not meta:
            return False
        if meta.get('readonly'):
            return False

        schema = meta.get('schema') or {}
        schema_type = schema.get('type')

        if schema_type == 'string':
            return isinstance(value, (str, int, float, bool))
        if schema_type == 'array':
            return isinstance(value, list)

        return False

    def upload_temp_file(self, path: Path, filename: str):
        with open(path, 'rb') as f:
            resp = self.client.post('/attachments/', files={'file': (filename, f)})
        if resp.status_code != 201:
            raise RuntimeError(f'Temp upload failed {path}: {resp.status_code} {resp.text}')
        return resp.json()['id']

    def build_patch_body(self, issue, local_field_map, old_key):
        body = {}

        if issue.get('summary'):
            body['summary'] = issue['summary']

        original_author = (issue.get('createdBy') or {}).get('display', '')
        original_assignee = (issue.get('assignee') or {}).get('display', '')
        original_followers = ', '.join(
            [x.get('display', '') for x in issue.get('followers', []) if x.get('display')]
        )

        original_meta_lines = [
            f'Original issue key: {issue.get("key", "")}',
            f'Original queue key: {(issue.get("queue") or {}).get("key", "")}',
        ]

        if original_author:
            original_meta_lines.append(f'Original author: {original_author}')

        if original_assignee:
            original_meta_lines.append(f'Original assignee: {original_assignee}')

        if original_followers:
            original_meta_lines.append(f'Original followers: {original_followers}')

        original_key_block = '\n'.join(original_meta_lines) + '\n\n'

        original_description = issue.get('description') or ''
        body['description'] = original_key_block + original_description

        issue_attachment_meta = load_json(self.input_dir / 'attachments' / old_key / 'issue_attachments.json', [])
        description_attachment_ids = []

        for att in issue_attachment_meta:
            local_file = att.get('_local_file')
            if not local_file:
                continue
            path = self.input_dir / 'attachments' / old_key / local_file
            if path.exists():
                try:
                    temp_id = self.upload_temp_file(path, att.get('name') or path.name)
                    description_attachment_ids.append(temp_id)
                except Exception as e:
                    logger.warning(f'Failed upload temp description attachment for {old_key}: {e}')

        if description_attachment_ids:
            body['descriptionAttachmentIds'] = description_attachment_ids

        if issue.get('type') and issue['type'].get('key'):
            body['type'] = issue['type']['key']

        if issue.get('priority') and issue['priority'].get('key'):
            body['priority'] = issue['priority']['key']

        if issue.get('tags') is not None:
            body['tags'] = issue['tags']

        if issue.get('parent'):
            old_parent = issue['parent']['key']
            with self._issue_map_lock:
                new_parent = self.issue_map.get(old_parent)
            if new_parent:
                body['parent'] = new_parent
            else:
                logger.warning(
                    f'Parent {old_parent} for {old_key} not found in issue_map, '
                    f'parent link will be skipped'
                )

        for k, v in issue.items():
            if k in body:
                continue
            if self.is_simple_supported_field(k, v, local_field_map):
                body[k] = v

        return body

    def patch_one_issue(self, issue, local_field_map):
        old_key = issue['key']

        with self._issue_map_lock:
            new_key = self.issue_map.get(old_key)
        if not new_key:
            return old_key, 'skipped: no new key'

        try:
            body = self.build_patch_body(issue, local_field_map, old_key)
            if not body:
                return old_key, None

            # Retry на конфликт версии (409)
            for attempt in range(1, MAX_RETRIES + 1):
                current = self.client.get(f'/issues/{new_key}')
                if current.status_code != 200:
                    return old_key, f'GET current issue failed {new_key}'

                version = current.json().get('version')
                params = {'version': version} if version is not None else None
                resp = self.client.patch(f'/issues/{new_key}', params=params, json_data=body)

                if resp.status_code == 200:
                    return old_key, None

                if resp.status_code == 409:
                    sleep_s = min(2 ** attempt, 10) + random.uniform(0.1, 0.5)
                    logger.warning(
                        f'[patch] 409 conflict on {old_key}->{new_key}, '
                        f'retry {attempt}/{MAX_RETRIES} after {sleep_s:.2f}s'
                    )
                    time.sleep(sleep_s)
                    continue

                return old_key, f'PATCH failed {resp.status_code} {resp.text}'

            return old_key, f'PATCH failed after {MAX_RETRIES} retries due to version conflict'

        except Exception as e:
            return old_key, str(e)

    def patch_all_issues(self, source_queue_key):
        issues = self.load_source_issues(source_queue_key)
        local_fields = load_json(self.input_dir / 'local_fields' / f'{source_queue_key}.json', [])
        local_field_map = {x['key']: x for x in local_fields}

        errors = []
        with ThreadPoolExecutor(max_workers=MAX_WORKERS_PATCH) as ex:
            futures = [ex.submit(self.patch_one_issue, issue, local_field_map) for issue in issues]
            for idx, fut in enumerate(as_completed(futures), start=1):
                old_key, err = fut.result()
                if err and not err.startswith('skipped'):
                    logger.error(f'[patch] failed {old_key}: {err}')
                    errors.append({'issue': old_key, 'error': err})
                else:
                    logger.info(f'[patch] {idx}/{len(issues)} {old_key}')

        save_json(self.state_dir / 'patch_errors.json', errors)

    def import_comments_one_issue(self, old_key):
        with self._issue_map_lock:
            new_key = self.issue_map.get(old_key)
        if not new_key:
            return old_key, 'skipped: no new key'

        marker = self.state_dir / f'comments_{old_key}.done'
        if marker.exists():
            return old_key, None

        try:
            comments = load_json(self.input_dir / 'comments' / f'{old_key}.json', [])
            comment_attachment_meta = load_json(self.input_dir / 'attachments' / old_key / 'comment_attachments.json', {})
            comment_attachment_meta = {
                str(k): v for k, v in (comment_attachment_meta or {}).items()
            }

            for c in comments:
                text = c.get('text') or ''
                author = (c.get('createdBy') or {}).get('display', 'Unknown')
                created_at = c.get('createdAt', '')

                summon_list = []
                for s in c.get('summonees', []):
                    display = s.get('display') or s.get('id')
                    if display:
                        summon_list.append(display)

                for s in c.get('maillistSummonees', []) or c.get('maillistsummonees', []):
                    display = s.get('display') or s.get('id')
                    if display:
                        summon_list.append(display)

                summon_text = ''
                if summon_list:
                    summon_text = 'Оригинальные призывы: ' + ', '.join(summon_list) + '\n'

                final_text = (
                    f'Оригинальный автор: {author}\n'
                    f'Оригинальная дата: {created_at}\n'
                    f'{summon_text}\n'
                    f'{text}'
                )

                attachment_ids = []

                comment_id = str(c.get('id'))
                attachments_for_comment = comment_attachment_meta.get(comment_id, [])

                for src in attachments_for_comment:
                    local_file = src.get('_local_file')
                    if not local_file:
                        continue
                    path = self.input_dir / 'attachments' / old_key / local_file
                    if path.exists():
                        temp_id = self.upload_temp_file(path, src.get('name') or path.name)
                        attachment_ids.append(temp_id)

                body = {
                    'text': final_text,
                    'markupType': 'md',
                }
                if attachment_ids:
                    body['attachmentIds'] = attachment_ids

                resp = self.client.post(
                    f'/issues/{new_key}/comments',
                    params={'isAddToFollowers': 'false'},
                    json_data=body
                )
                if resp.status_code != 201:
                    raise RuntimeError(f'Create comment failed {resp.status_code} {resp.text}')

            marker.write_text('ok', encoding='utf-8')
            return old_key, None
        except Exception as e:
            return old_key, str(e)

    def import_comments(self, source_queue_key):
        issue_keys = load_json(self.input_dir / '_meta' / f'{source_queue_key}_issues.json', [])
        errors = []

        with ThreadPoolExecutor(max_workers=MAX_WORKERS_COMMENTS) as ex:
            futures = [ex.submit(self.import_comments_one_issue, old_key) for old_key in issue_keys]
            for idx, fut in enumerate(as_completed(futures), start=1):
                old_key, err = fut.result()
                if err and not err.startswith('skipped'):
                    logger.error(f'[comments] failed {old_key}: {err}')
                    errors.append({'issue': old_key, 'error': err})
                else:
                    logger.info(f'[comments] {idx}/{len(issue_keys)} {old_key}')

        save_json(self.state_dir / 'comments_errors.json', errors)

    def import_issue_attachments_one_issue(self, old_key):
        with self._issue_map_lock:
            new_key = self.issue_map.get(old_key)
        if not new_key:
            return old_key, 'skipped: no new key'

        marker = self.state_dir / f'attachments_{old_key}.done'
        if marker.exists():
            return old_key, None

        try:
            meta = load_json(self.input_dir / 'attachments' / old_key / 'issue_attachments.json', [])
            for att in meta:
                local_file = att.get('_local_file')
                if not local_file:
                    continue
                path = self.input_dir / 'attachments' / old_key / local_file
                if not path.exists():
                    continue

                with open(path, 'rb') as f:
                    resp = self.client.post(
                        f'/issues/{new_key}/attachments/',
                        files={'file': (att.get('name') or path.name, f)}
                    )
                if resp.status_code != 201:
                    raise RuntimeError(f'Attachment upload failed {resp.status_code} {resp.text}')

            marker.write_text('ok', encoding='utf-8')
            return old_key, None
        except Exception as e:
            return old_key, str(e)

    def import_attachments_to_issue(self, source_queue_key):
        issue_keys = load_json(self.input_dir / '_meta' / f'{source_queue_key}_issues.json', [])
        errors = []

        with ThreadPoolExecutor(max_workers=MAX_WORKERS_ATTACHMENTS) as ex:
            futures = [ex.submit(self.import_issue_attachments_one_issue, old_key) for old_key in issue_keys]
            for idx, fut in enumerate(as_completed(futures), start=1):
                old_key, err = fut.result()
                if err and not err.startswith('skipped'):
                    logger.error(f'[attachments] failed {old_key}: {err}')
                    errors.append({'issue': old_key, 'error': err})
                else:
                    logger.info(f'[attachments] {idx}/{len(issue_keys)} {old_key}')

        save_json(self.state_dir / 'attachments_errors.json', errors)

    def restore_status(self, issue, new_key):
        old_key = issue['key']
        target_status_key = (issue.get('status') or {}).get('key')
        target_resolution_key = (issue.get('resolution') or {}).get('key')

        if not target_status_key:
            return None

        guard = 0
        while guard < 20:
            guard += 1

            resp = self.client.get(f'/issues/{new_key}')
            if resp.status_code != 200:
                return f'Cannot read imported issue {new_key} for status restore'

            current_status = (resp.json().get('status') or {}).get('key')
            if current_status == target_status_key:
                return None

            trans = self.client.get(f'/issues/{new_key}/transitions')
            if trans.status_code != 200:
                return f'Cannot get transitions for {new_key}'

            transitions = trans.json()
            matched = None
            for t in transitions:
                to_key = (t.get('to') or {}).get('key')
                if to_key == target_status_key:
                    matched = t
                    break

            if not matched:
                logger.warning(
                    f'No direct transition to {target_status_key} for {old_key}->{new_key}, '
                    f'available: {[((t.get("to") or {}).get("key")) for t in transitions]}'
                )
                return f'No transition to target status {target_status_key} for {old_key}->{new_key}'

            body = {}
            if target_resolution_key:
                body['resolution'] = target_resolution_key

            execute = self.client.post(
                f'/issues/{new_key}/transitions/{matched["id"]}/_execute',
                json_data=body
            )

            if execute.status_code == 200:
                continue

            if 'Резолюция' not in execute.text and 'resolution' not in execute.text.lower():
                return f'Transition failed {execute.status_code} {execute.text}'

            if body:
                execute_retry = self.client.post(
                    f'/issues/{new_key}/transitions/{matched["id"]}/_execute',
                    json_data={}
                )
                if execute_retry.status_code == 200:
                    continue
                return f'Transition failed {execute_retry.status_code} {execute_retry.text}'

            return f'Transition failed {execute.status_code} {execute.text}'

        return f'Status restore guard limit for {old_key}->{new_key}'

    def restore_status_one_issue(self, issue):
        old_key = issue['key']
        with self._issue_map_lock:
            new_key = self.issue_map.get(old_key)
        if not new_key:
            return old_key, 'skipped: no new key'
        try:
            err = self.restore_status(issue, new_key)
            return old_key, err
        except Exception as e:
            return old_key, str(e)

    def restore_all_statuses(self, source_queue_key):
        issues = self.load_source_issues(source_queue_key)
        errors = []

        with ThreadPoolExecutor(max_workers=MAX_WORKERS_STATUS) as ex:
            futures = [ex.submit(self.restore_status_one_issue, issue) for issue in issues]
            for idx, fut in enumerate(as_completed(futures), start=1):
                old_key, err = fut.result()
                if err and not err.startswith('skipped'):
                    logger.error(f'[status] failed {old_key}: {err}')
                    errors.append({'issue': old_key, 'error': err})
                else:
                    logger.info(f'[status] {idx}/{len(issues)} {old_key}')

        save_json(self.state_dir / 'status_errors.json', errors)

    def import_links_one_issue(self, old_key):
        with self._issue_map_lock:
            new_key = self.issue_map.get(old_key)
        if not new_key:
            return old_key, 'skipped: no new key'

        try:
            links = load_json(self.input_dir / 'links' / f'{old_key}.json', [])
            for link in links:
                rel = relationship_from_link(link)
                if not rel:
                    continue

                if rel in ('is parent task for', 'is subtask for'):
                    continue

                other_old = (link.get('object') or {}).get('key')
                with self._issue_map_lock:
                    other_new = self.issue_map.get(other_old)
                if not other_new:
                    continue

                dedup = f'{new_key}|{rel}|{other_new}'
                rev = f'{other_new}|{rel}|{new_key}'

                with self._links_lock:
                    # Проверяем обе стороны для всех типов связей
                    if dedup in self.created_links or rev in self.created_links:
                        continue

                resp = self.client.post(f'/issues/{new_key}/links', json_data={
                    'relationship': rel,
                    'issue': other_new
                })

                if resp.status_code == 201:
                    with self._links_lock:
                        self.created_links.add(dedup)
                        self._save_links()

                elif resp.status_code in (409, 422):
                    # 409 — конфликт, 422 — "уже связаны" от Яндекс Трекера.
                    # Оба случая означают что связь уже существует — считаем успехом.
                    text_lower = resp.text.lower()
                    if (
                        'уже связаны' in text_lower
                        or 'already' in text_lower
                        or resp.status_code == 409
                    ):
                        logger.warning(
                            f'Link already exists {new_key} -{rel}-> {other_new} '
                            f'({resp.status_code}), skipping'
                        )
                        with self._links_lock:
                            self.created_links.add(dedup)
                            self._save_links()
                    else:
                        raise RuntimeError(f'Link failed {resp.status_code} {resp.text}')

                else:
                    raise RuntimeError(f'Link failed {resp.status_code} {resp.text}')

            return old_key, None
        except Exception as e:
            return old_key, str(e)

    def import_links(self, source_queue_key):
        issue_keys = load_json(self.input_dir / '_meta' / f'{source_queue_key}_issues.json', [])
        errors = []

        with ThreadPoolExecutor(max_workers=MAX_WORKERS_LINKS) as ex:
            futures = [ex.submit(self.import_links_one_issue, old_key) for old_key in issue_keys]
            for idx, fut in enumerate(as_completed(futures), start=1):
                old_key, err = fut.result()
                if err and not err.startswith('skipped'):
                    logger.error(f'[links] failed {old_key}: {err}')
                    errors.append({'issue': old_key, 'error': err})
                else:
                    logger.info(f'[links] {idx}/{len(issue_keys)} {old_key}')

        save_json(self.state_dir / 'links_errors.json', errors)

    def run(self, source_queue_key: str, target_queue_key: str, target_queue_name: str):
        self.ensure_target_queue_does_not_exist(target_queue_key)
        self.create_target_queue(source_queue_key, target_queue_key, target_queue_name)

        self.create_all_issues(source_queue_key, target_queue_key)
        self.patch_all_issues(source_queue_key)
        self.import_comments(source_queue_key)
        self.import_attachments_to_issue(source_queue_key)
        self.import_links(source_queue_key)
        self.restore_all_statuses(source_queue_key)


def main():
    logger.info(f'Using queue lead: {QUEUE_LEAD}')

    client = TrackerClient(ORGID, TOKEN, ORG_TYPE)
    importer = Importer(client, Path(INPUT_DIR), QUEUE_LEAD)
    importer.run(SOURCE_QUEUE_KEY, TARGET_QUEUE_KEY, TARGET_QUEUE_NAME)
    logger.info('Import done')


if __name__ == '__main__':
    main()
