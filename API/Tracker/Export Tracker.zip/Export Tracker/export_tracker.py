#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
Скрипт предназначен для подключения к организации по OAuth-токену, чтения выбранной очереди в Трекере, сбора данных из нее, которые возможно забрать и сохранения их в папку с экспортом.
Скрипт ограничен по RPS: 10 RPS на запросы по поиску задач в очереди (максимум можно выставить 20 RPS), и 60 RPS на все остальные запросы (максимум может быть 100).

Для работы скрипта понадобится заполнить:
• ORGID - ID организации (облачной или со стороны Яндекс 360)
• TOKEN - токен администратора организации ( токен для облачной организации выдается другим способом). У приложения указанного токена должны быть права tracker:read
• ORG_TYPE - X-Org-ID для Яндекс 360 и X-Cloud-Org-ID для Яндекс Cloud
• SOURCE_QUEUE_KEY - Ключ очереди, которую планируется экспортировать
• OUTPUT_DIR - Название папки, куда сохранятся экспортируемые файлы (будет создана в папке со скриптом)
'''

import re
import json
import time
import random
import logging
import threading
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

# =========================================================
# НАСТРОЙКИ ЭКСПОРТА
# =========================================================

ORGID = '8260785'
# ID исходной организации, из которой читаем задачи

TOKEN = 'y0__wgBE...'
# OAuth токен в исходной организации

ORG_TYPE = 'X-Org-ID'
# Тип организации:
# 'X-Org-ID'         -> для Яндекс 360
# 'X-Cloud-Org-ID'   -> для Cloud Organization

SOURCE_QUEUE_KEY = 'OCHERED'
# КЛЮЧ ОЧЕРЕДИ В ИСХОДНОЙ ОРГАНИЗАЦИИ.
# Именно из этой очереди будут экспортированы задачи.

OUTPUT_DIR = 'export_data'
# Папка, куда будет сохранен экспорт

# Параллелизм
MAX_WORKERS_ISSUES = 8    # для экспорта задач
MAX_WORKERS_FIELDS = 4    # для экспорта локальных полей

# Лимиты ниже максимальных, чтобы не упираться в потолок
SEARCH_RPS = 10       # максимум у API 20 rps
DEFAULT_RPS = 60      # максимум у API 100 rps

MAX_RETRIES = 6
API_BASE = 'https://api.tracker.yandex.net/v3'

# =========================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)
logger = logging.getLogger('tracker_export')


def ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


def load_json(path: Path, default=None):
    if path.exists():
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return default


def save_json(path: Path, data):
    ensure_dir(path.parent)
    tmp = path.with_suffix('.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(path)


def safe_filename(name: str) -> str:
    name = (name or '').strip()
    name = re.sub(r'[\\/*?:"<>|]', '_', name)
    return name[:200] if name else 'file'


def parse_next_link(link_header: str):
    if not link_header:
        return None
    for part in link_header.split(','):
        part = part.strip()
        if 'rel="next"' not in part:
            continue
        url_match = re.search(r'<([^>]+)>', part)
        if not url_match:
            continue
        url = url_match.group(1)
        id_match = re.search(r'[?&]id=([^&]+)', url)
        if id_match:
            return id_match.group(1)
    return None


class RateLimiter:
    def __init__(self, rate_per_sec: float):
        self.rate = rate_per_sec
        # capacity = 1.0 чтобы не было burst-залпа в начале работы
        self.capacity = 1.0
        self.tokens = 1.0
        self.updated_at = time.monotonic()
        self.lock = threading.Lock()

    def acquire(self):
        while True:
            with self.lock:
                now = time.monotonic()
                elapsed = now - self.updated_at
                self.updated_at = now
                self.tokens = min(self.capacity, self.tokens + elapsed * self.rate)

                if self.tokens >= 1:
                    self.tokens -= 1
                    return

                need = (1 - self.tokens) / self.rate

            # Спим точное время снаружи лока
            time.sleep(need)


class TrackerClient:
    def __init__(self, org_id: str, token: str, org_type: str):
        self.base_url = API_BASE
        self.session = requests.Session()
        self.session.headers.update({
            org_type: org_id,
            'Authorization': f'OAuth {token}'
        })

        self.search_limiter = RateLimiter(SEARCH_RPS)
        self.default_limiter = RateLimiter(DEFAULT_RPS)

    def _choose_limiter(self, path: str):
        if path == '/issues/_search':
            return self.search_limiter
        return self.default_limiter

    def request(self, method: str, path: str, **kwargs):
        url = f'{self.base_url}{path}'
        limiter = self._choose_limiter(path)

        for attempt in range(1, MAX_RETRIES + 1):
            limiter.acquire()
            try:
                resp = self.session.request(method, url, timeout=120, **kwargs)

                if resp.status_code == 429:
                    retry_after = int(resp.headers.get('Retry-After', '3'))
                    sleep_s = retry_after + random.uniform(0.1, 0.7)
                    logger.warning(f'429 on {method} {path}, sleep {sleep_s:.2f}s')
                    time.sleep(sleep_s)
                    continue

                if 500 <= resp.status_code < 600:
                    sleep_s = min(2 ** attempt, 20) + random.uniform(0.1, 0.5)
                    logger.warning(f'{resp.status_code} on {method} {path}, retry {attempt}/{MAX_RETRIES}')
                    time.sleep(sleep_s)
                    continue

                return resp

            except (requests.ConnectionError, requests.Timeout) as e:
                sleep_s = min(2 ** attempt, 20) + random.uniform(0.1, 0.5)
                logger.warning(f'Network error on {method} {path}: {e}, retry {attempt}/{MAX_RETRIES}')
                time.sleep(sleep_s)

            except requests.RequestException as e:
                raise RuntimeError(f'Request failed {method} {path}: {e}') from e

        raise RuntimeError(f'Request failed after retries: {method} {path}')

    def get(self, path, params=None):
        return self.request('GET', path, params=params)

    def post(self, path, params=None, json_data=None, files=None, data=None):
        if files is not None:
            return self.request('POST', path, params=params, files=files, data=data)
        return self.request('POST', path, params=params, json=json_data)

    def download_file(self, url: str, dest: Path):
        for attempt in range(1, MAX_RETRIES + 1):
            self.default_limiter.acquire()
            try:
                r = self.session.get(url, stream=True, timeout=300)

                if r.status_code == 429:
                    retry_after = int(r.headers.get('Retry-After', '3'))
                    sleep_s = retry_after + random.uniform(0.1, 0.7)
                    logger.warning(f'429 on download {url}, sleep {sleep_s:.2f}s')
                    time.sleep(sleep_s)
                    continue

                if 500 <= r.status_code < 600:
                    sleep_s = min(2 ** attempt, 20) + random.uniform(0.1, 0.5)
                    logger.warning(f'{r.status_code} on download {url}, retry {attempt}/{MAX_RETRIES}')
                    time.sleep(sleep_s)
                    continue

                if r.status_code != 200:
                    raise RuntimeError(f'Download failed {url}: {r.status_code}')

                tmp = dest.with_suffix('.tmp')
                with open(tmp, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=131072):
                        if chunk:
                            f.write(chunk)
                tmp.replace(dest)
                return

            except (requests.ConnectionError, requests.Timeout) as e:
                sleep_s = min(2 ** attempt, 20) + random.uniform(0.1, 0.5)
                logger.warning(f'Network error on download {url}: {e}, retry {attempt}/{MAX_RETRIES}')
                time.sleep(sleep_s)

            except requests.RequestException as e:
                raise RuntimeError(f'Download failed {url}: {e}') from e

        raise RuntimeError(f'Download failed after retries: {url}')


class Exporter:
    def __init__(self, client: TrackerClient, out_dir: Path):
        self.client = client
        self.out_dir = out_dir

        for d in [
            out_dir,
            out_dir / '_meta',
            out_dir / 'queues',
            out_dir / 'fields',
            out_dir / 'local_fields',
            out_dir / 'issues',
            out_dir / 'comments',
            out_dir / 'links',
            out_dir / 'attachments',
        ]:
            ensure_dir(d)

    def export_global_fields(self):
        logger.info('Export global fields')
        resp = self.client.get('/fields')
        if resp.status_code != 200:
            raise RuntimeError(f'GET /fields failed: {resp.status_code} {resp.text}')
        save_json(self.out_dir / 'fields' / 'global_fields.json', resp.json())

    def export_queue(self, queue_key: str):
        logger.info(f'Export queue {queue_key}')
        resp = self.client.get(f'/queues/{queue_key}', params={'expand': 'all'})
        if resp.status_code != 200:
            raise RuntimeError(f'GET queue failed {queue_key}: {resp.status_code} {resp.text}')
        save_json(self.out_dir / 'queues' / f'{queue_key}.json', resp.json())

    def export_local_fields(self, queue_key: str):
        logger.info(f'Export local fields for {queue_key}')
        resp = self.client.get(f'/queues/{queue_key}/localFields')
        if resp.status_code != 200:
            raise RuntimeError(f'GET local fields failed {queue_key}: {resp.status_code} {resp.text}')
        fields = resp.json()
        save_json(self.out_dir / 'local_fields' / f'{queue_key}.json', fields)

        detailed = {}
        errors = []

        def fetch_field(field):
            key = field['key']
            r = self.client.get(f'/queues/{queue_key}/localFields/{key}')
            if r.status_code == 200:
                return key, r.json(), None
            return key, None, f'{r.status_code} {r.text}'

        with ThreadPoolExecutor(max_workers=MAX_WORKERS_FIELDS) as ex:
            futures = [ex.submit(fetch_field, field) for field in fields]
            for fut in as_completed(futures):
                key, data, err = fut.result()
                if err:
                    logger.warning(f'Failed to fetch local field {key}: {err}')
                    errors.append({'field': key, 'error': err})
                else:
                    detailed[key] = data

        save_json(self.out_dir / 'local_fields' / f'{queue_key}__detailed.json', detailed)
        if errors:
            save_json(self.out_dir / 'local_fields' / f'{queue_key}__detailed_errors.json', errors)

    def export_issue_keys(self, queue_key: str):
        logger.info(f'Export issue list for queue {queue_key}')
        body = {'filter': {'queue': queue_key}}
        params = {
            'scrollType': 'unsorted',
            'perScroll': 500,
            'scrollTTLMillis': 60000
        }

        resp = self.client.post('/issues/_search', params=params, json_data=body)
        if resp.status_code != 200:
            raise RuntimeError(f'_search failed for {queue_key}: {resp.status_code} {resp.text}')

        result = []
        batch = resp.json()
        result.extend(batch)

        scroll_id = resp.headers.get('X-Scroll-Id')
        while scroll_id:
            resp = self.client.post(
                '/issues/_search',
                params={'scrollId': scroll_id, 'scrollTTLMillis': 60000},
                json_data={}
            )
            if resp.status_code != 200:
                raise RuntimeError(f'_search scroll failed for {queue_key}: {resp.status_code} {resp.text}')

            batch = resp.json()
            if not batch:
                break
            result.extend(batch)
            scroll_id = resp.headers.get('X-Scroll-Id')
            logger.info(f'{queue_key}: exported {len(result)} issues so far')

        keys = [x['key'] for x in result]
        save_json(self.out_dir / '_meta' / f'{queue_key}_issues.json', keys)
        return keys

    def export_issue_full(self, issue_key: str):
        resp = self.client.get(f'/issues/{issue_key}', params={'expand': 'attachments,transitions'})
        if resp.status_code != 200:
            raise RuntimeError(f'GET issue failed {issue_key}: {resp.status_code} {resp.text}')
        save_json(self.out_dir / 'issues' / f'{issue_key}.json', resp.json())

    def export_comments(self, issue_key: str):
        comments = []
        next_id = None

        while True:
            params = {'expand': 'all', 'perPage': 100}
            if next_id:
                params['id'] = next_id

            resp = self.client.get(f'/issues/{issue_key}/comments', params=params)
            if resp.status_code != 200:
                raise RuntimeError(f'GET comments failed {issue_key}: {resp.status_code} {resp.text}')

            batch = resp.json()
            comments.extend(batch)

            link = resp.headers.get('Link')
            if not link or 'rel="next"' not in link:
                break

            next_id = parse_next_link(link)
            if not next_id:
                break

        save_json(self.out_dir / 'comments' / f'{issue_key}.json', comments)

    def export_links(self, issue_key: str):
        resp = self.client.get(f'/issues/{issue_key}/links')
        if resp.status_code != 200:
            raise RuntimeError(f'GET links failed {issue_key}: {resp.status_code} {resp.text}')
        save_json(self.out_dir / 'links' / f'{issue_key}.json', resp.json())

    def export_attachments(self, issue_key: str):
        comments = load_json(self.out_dir / 'comments' / f'{issue_key}.json', [])
        comment_attachment_ids = set()
        comment_attachment_map = {}

        for c in comments:
            comment_id = str(c.get('id'))
            comment_attachment_map[comment_id] = []
            for att in c.get('attachments', []):
                aid = str(att.get('id'))
                if aid:
                    comment_attachment_ids.add(aid)

        resp = self.client.get(f'/issues/{issue_key}/attachments')
        if resp.status_code != 200:
            raise RuntimeError(f'GET attachments failed {issue_key}: {resp.status_code} {resp.text}')

        attachments = resp.json()
        issue_dir = self.out_dir / 'attachments' / issue_key
        ensure_dir(issue_dir)

        all_meta = []
        issue_attachments = []
        attachment_by_id = {}

        for att in attachments:
            att_id = str(att['id'])
            file_name = safe_filename(att.get('name', att_id))
            local_file = f'{att_id}__{file_name}'
            local_path = issue_dir / local_file

            if not local_path.exists():
                # Используем download_file с retry и rate limiter
                self.client.download_file(att['content'], local_path)

            item = dict(att)
            item['_local_file'] = local_file
            attachment_by_id[att_id] = item
            all_meta.append(item)

        for c in comments:
            comment_id = str(c.get('id'))
            for att in c.get('attachments', []):
                aid = str(att.get('id'))
                if aid in attachment_by_id:
                    comment_attachment_map[comment_id].append(attachment_by_id[aid])

        for att_id, item in attachment_by_id.items():
            if att_id not in comment_attachment_ids:
                issue_attachments.append(item)

        save_json(issue_dir / '_meta.json', all_meta)
        save_json(issue_dir / 'issue_attachments.json', issue_attachments)
        save_json(issue_dir / 'comment_attachments.json', comment_attachment_map)

    def export_one_issue(self, issue_key: str):
        try:
            self.export_issue_full(issue_key)
            self.export_comments(issue_key)
            self.export_links(issue_key)
            self.export_attachments(issue_key)
            return issue_key, None
        except Exception as e:
            return issue_key, str(e)

    def run(self, source_queue_key: str):
        save_json(self.out_dir / '_meta' / 'manifest.json', {
            'sourceQueueKey': source_queue_key,
            'exportedAt': time.strftime('%Y-%m-%d %H:%M:%S')
        })

        self.export_global_fields()
        self.export_queue(source_queue_key)
        self.export_local_fields(source_queue_key)

        issue_keys = self.export_issue_keys(source_queue_key)

        logger.info(f'Start parallel export of {len(issue_keys)} issues with {MAX_WORKERS_ISSUES} workers')
        errors = []
        with ThreadPoolExecutor(max_workers=MAX_WORKERS_ISSUES) as ex:
            future_map = {ex.submit(self.export_one_issue, issue_key): issue_key for issue_key in issue_keys}
            for i, future in enumerate(as_completed(future_map), start=1):
                issue_key, err = future.result()
                if err:
                    logger.error(f'Export failed for {issue_key}: {err}')
                    errors.append({'issue': issue_key, 'error': err})
                else:
                    logger.info(f'Exported {i}/{len(issue_keys)}: {issue_key}')

        save_json(self.out_dir / '_meta' / 'export_errors.json', errors)
        if errors:
            logger.warning(f'Export finished with {len(errors)} errors')
        else:
            logger.info('Export finished without errors')


def main():
    client = TrackerClient(ORGID, TOKEN, ORG_TYPE)
    exporter = Exporter(client, Path(OUTPUT_DIR))
    exporter.run(SOURCE_QUEUE_KEY)
    logger.info('Export done')


if __name__ == '__main__':
    main()
