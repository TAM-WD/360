/* Local, Russian date and 24-hour time pickers. No locale-dependent native date/time controls. */
(() => {
  const byId = id => document.getElementById(id);
  const months = ["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"];
  const pad = n => String(n).padStart(2, "0");
  const dateText = d => `${pad(d.getDate())}.${pad(d.getMonth()+1)}.${String(d.getFullYear()).padStart(4,"0")}`;
  const makeDate = (y,m,d) => {const value=new Date();value.setHours(0,0,0,0);value.setFullYear(y,m,d);return value;};
  function parseDate(value) {
    const parts = value.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
    if (!parts) return null;
    const date=makeDate(Number(parts[3]),Number(parts[2])-1,Number(parts[1]));
    return dateText(date)===value && date.getFullYear()>0 ? date : null;
  }
  let active=null, target=null, month=0, year=0, selected=null;
  const calendar=byId("date-picker"), time=byId("time-picker"), grid=byId("calendar-grid");
  function close(focus=false) {
    const previous=target;
    calendar.hidden=true;time.hidden=true;
    if (previous) previous.setAttribute("aria-expanded","false");
    active=null;target=null;
    if (focus && previous) previous.focus();
  }
  function position(popup, input) {
    const rect=input.getBoundingClientRect();
    popup.style.left=`${Math.max(12,Math.min(rect.left,window.innerWidth-popup.offsetWidth-12))}px`;
    const below=rect.bottom+7;
    popup.style.top=`${Math.max(12,Math.min(below,window.innerHeight-popup.offsetHeight-12))}px`;
  }
  function open(popup,input) {
    close();active=popup;target=input;popup.hidden=false;
    input.setAttribute("aria-expanded","true");position(popup,input);
  }
  function apply(value) {
    const input=target;
    input.value=value;
    input.dispatchEvent(new Event("input",{bubbles:true}));
    close(true);
  }
  function renderCalendar(focusDate=null) {
    byId("calendar-title").textContent=`${months[month]} ${year}`;
    byId("calendar-prev").disabled=year===1 && month===0;
    byId("calendar-next").disabled=year===9999 && month===11;
    grid.replaceChildren();
    const first=makeDate(year,month,1), offset=(first.getDay()+6)%7, today=dateText(new Date());
    for(let index=0;index<42;index++) {
      const day=makeDate(year,month,index-offset+1), value=dateText(day), button=document.createElement("button");
      button.type="button";button.className="calendar-day";button.dataset.date=value;
      button.textContent=day.getDate();button.setAttribute("aria-label",value);
      button.setAttribute("role","gridcell");button.setAttribute("aria-selected",String(value===selected));
      button.classList.toggle("outside",day.getMonth()!==month);
      button.classList.toggle("is-selected",value===selected);button.classList.toggle("today",value===today);
      button.disabled=day.getFullYear()<1 || day.getFullYear()>9999;
      button.tabIndex=value===(focusDate||selected) || (!focusDate && !selected && day.getDate()===1 && day.getMonth()===month) ? 0 : -1;
      button.addEventListener("click",()=>apply(value));
      button.addEventListener("keydown",event=>{
        const offsets={ArrowLeft:-1,ArrowRight:1,ArrowUp:-7,ArrowDown:7};
        if (!(event.key in offsets)) return;
        event.preventDefault();
        const next=makeDate(day.getFullYear(),day.getMonth(),day.getDate()+offsets[event.key]);
        if(next.getFullYear()<1 || next.getFullYear()>9999)return;
        year=next.getFullYear();month=next.getMonth();renderCalendar(dateText(next));
      });
      grid.append(button);
    }
    if(focusDate)grid.querySelector(`[data-date="${focusDate}"]`)?.focus();
    if(active===calendar)position(calendar,target);
  }
  function openDate() {
    const input=byId("date"), value=parseDate(input.value)||new Date();
    selected=parseDate(input.value)?dateText(value):null;month=value.getMonth();year=value.getFullYear();
    renderCalendar();open(calendar,input);
    (grid.querySelector('[aria-selected="true"]')||grid.querySelector('[tabindex="0"]'))?.focus();
  }
  function moveMonth(delta) {
    const next=makeDate(year,month+delta,1);year=next.getFullYear();month=next.getMonth();renderCalendar(dateText(next));
  }
  byId("calendar-prev").addEventListener("click",()=>moveMonth(-1));
  byId("calendar-next").addEventListener("click",()=>moveMonth(1));
  byId("calendar-today").addEventListener("click",()=>apply(dateText(new Date())));
  byId("calendar-manual").addEventListener("click",()=>{close(true);byId("date").select();});
  for(const [id,count] of [["picker-hour",24],["picker-minute",60],["picker-second",60]]) {
    for(let value=0;value<count;value++){const option=document.createElement("option");option.value=pad(value);option.textContent=pad(value);byId(id).append(option);}
  }
  function setTimeValues(value) {
    const parts=/^([01]\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?$/.exec(value);
    byId("picker-hour").value=parts?.[1]||"00";byId("picker-minute").value=parts?.[2]||"00";byId("picker-second").value=parts?.[3]||"00";
  }
  function openTime(id) {
    const input=byId(id);setTimeValues(input.value);
    byId("time-picker-title").textContent=id==="time-from"?"Время начала · 24 часа":"Время окончания · 24 часа";
    open(time,input);byId("picker-hour").focus();
  }
  byId("time-apply").addEventListener("click",()=>apply(["picker-hour","picker-minute","picker-second"].map(id=>byId(id).value).join(":")));
  byId("time-manual").addEventListener("click",()=>{const input=target;close(true);input?.select();});
  document.querySelectorAll("[data-time-preset]").forEach(button=>button.addEventListener("click",()=>setTimeValues(button.dataset.timePreset)));
  for(const id of ["date","time-from","time-to"]) {
    const input=byId(id), show=()=>id==="date"?openDate():openTime(id);
    input.setAttribute("aria-haspopup","dialog");input.setAttribute("aria-expanded","false");
    input.addEventListener("click",show);
    input.addEventListener("keydown",event=>{if(event.key==="ArrowDown" && event.altKey){event.preventDefault();show();}});
    byId(`${id}-toggle`).addEventListener("click",event=>{event.preventDefault();show();});
  }
  document.addEventListener("pointerdown",event=>{
    if(active && !active.contains(event.target) && event.target!==target && !event.target.closest(".picker-toggle"))close();
  });
  document.addEventListener("keydown",event=>{if(event.key==="Escape" && active){event.preventDefault();close(true);}});
  window.addEventListener("resize",()=>{if(active)position(active,target);});
})();
