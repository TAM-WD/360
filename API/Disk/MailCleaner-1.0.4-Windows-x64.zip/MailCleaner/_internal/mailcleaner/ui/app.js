"use strict";
const $ = id => document.getElementById(id);
const statusLabels = {deleted:"Удалено",already_absent:"Уже отсутствует",stale:"Устаревший список",error:"Ошибка",unknown:"Не подтверждено",cancelled:"Остановлено"};
let state = null, table = {page:1,pages:1,total:0,rows:[]}, sort="mailbox", descending=false, pending=null;
let updating=false, initialized=false, lastRevision=-1, toastTimer, tableTimer;
const safeText = value => String(value ?? "").replace(/[\u0000-\u001f\u007f-\u009f]/g," ");
function text(node,value){node.textContent=safeText(value)}
function toast(message,error=false){clearTimeout(toastTimer);text($("toast"),message);$("toast").classList.toggle("error",error);$("toast").hidden=false;toastTimer=setTimeout(()=>$("toast").hidden=true,8000)}
async function api(method,...args){
  if(!window.pywebview?.api) throw new Error("Окно ещё подключается к приложению. Повторите через несколько секунд.");
  const result = await window.pywebview.api[method](...args);
  if(!result?.ok) throw new Error(result?.error || "Не удалось выполнить операцию.");
  return result.data;
}
function handle(fn){return async event=>{try{await fn(event)}catch(error){toast(error.message,true)}}}
function showView(name){document.querySelectorAll(".view").forEach(el=>el.hidden=el.id!==`view-${name}`);document.querySelectorAll(".nav-item").forEach(el=>el.classList.toggle("active",el.dataset.view===name))}
function dateToApi(value){return value.trim().replaceAll(".","-")}
function toTime(value){value=value.trim();return value.length===5?value+":00":value}
function syncSenderOption(){const hasSender=!!$("sender").value.trim();$("include-sender").disabled=!hasSender;if(!hasSender)$("include-sender").checked=false}
function formValue(){return {sender:$("sender").value.trim()||null,date:dateToApi($("date").value),time_from:toTime($("time-from").value),time_to:toTime($("time-to").value),recipients:$("recipients").value.trim()?[$("recipients").value]:[],subject:$("subject").value===""?null:$("subject").value,subject_mode:$("subject-mode").value,message_id:$("message-id").value===""?null:$("message-id").value,include_sender:$("include-sender").checked}}
function applyForm(form){if(!form)return;$("sender").value=form.sender??"";$("date").value=form.date.replaceAll("-",".");$("time-from").value=form.time_from;$("time-to").value=form.time_to;$("recipients").value=form.recipients.join(", ");$("subject").value=form.subject??"";$("subject-mode").value=form.subject_mode;$("message-id").value=form.message_id??"";$("include-sender").checked=form.include_sender;syncSenderOption()}
function deletable(){return state&&!!state.run_id&&state.count>0&&!state.busy&&!state.invalidated&&!state.executed}
function renderState(){
  const s=state;if(!s)return;
  $("demo-mode").checked=s.demo;$("demo-mode").disabled=s.busy;$("demo-banner").hidden=!s.demo;
  text($("org-label"),s.demo?"Демонстрационная организация":s.configured?`Организация ${s.organization_id}`:"Подключение не настроено");
  $("connection-dot").classList.toggle("connected",s.configured||s.demo);text($("version"),s.version);
  $("search-fields").disabled=s.busy;$("connection-fields").disabled=s.busy;syncSenderOption();
  $("check-button").disabled=s.busy;$("load-saved").disabled=s.busy||!s.has_saved;$("forget-saved").disabled=s.busy||!s.has_saved;
  text($("saved-info"),s.has_saved?"Настройки доступны текущему пользователю Windows.":"Настройки ещё не сохранены.");
  text($("check-result"),["checking","checked","error"].includes(s.phase)?s.message:"");
  $("progress-card").hidden=!s.busy;$("stop-button").disabled=!s.busy;text($("progress-message"),s.message);
  if(s.total){$("progress-bar").value=s.current;$("progress-bar").max=s.total}else{$("progress-bar").removeAttribute("value")}
  $("summary").hidden=!s.run_id;$("count-found").textContent=s.count;$("count-boxes").textContent=s.mailboxes;$("count-selected").textContent=s.selected_count;$("count-issues").textContent=s.issues.length;$("result-count").textContent=s.count;
  const metrics=s.metrics||{},seconds=Math.round(metrics.elapsed_seconds||0);
  $("scan-metrics").hidden=!s.run_id||s.busy||metrics.elapsed_seconds===undefined;
  text($("scan-metrics"),`Время поиска: ${Math.floor(seconds/60)} мин ${seconds%60} с · Прочитано Message-ID: ${metrics.message_ids_read||0} · Заголовков кандидатов: ${metrics.headers_read||0}`);
  $("incomplete-banner").hidden=!s.run_id||s.complete||s.busy||s.invalidated;
  text($("incomplete-title"),s.executed?"Поиск был неполным":s.count?"Поиск неполный — найденные копии можно удалить":"Поиск неполный");
  text($("incomplete-description"),s.executed?"Результат обработки относится только к выбранным копиям. Другие совпадения могли быть пропущены. Ошибки поиска сохранены в журнале.":s.count?"Вы можете выбрать проверенные копии из таблицы. Другие совпадения могли быть пропущены. Подробности — в журнале операций.":"Совпадений не найдено, но часть данных не удалось проверить. Устраните ошибки из журнала и повторите поиск.");
  $("invalid-banner").hidden=!s.run_id||!s.invalidated;
  $("result-banner").hidden=!s.executed||s.busy||s.invalidated;
  text($("result-summary"),Object.entries(s.counts).map(([key,count])=>`${statusLabels[key]||key}: ${count}`).join(" · ")||"Проверьте журнал операций.");
  $("step1").classList.toggle("active",!s.run_id||s.invalidated||s.busy&&s.phase!=="deletion");
  $("step2").classList.toggle("active",!!s.run_id&&!s.invalidated&&!s.executed);
  $("step3").classList.toggle("active",s.executed);
  $("empty-state").hidden=s.count>0;$("table-area").hidden=!s.count;
  text($("empty-title"),s.busy?"Идёт поиск…":s.run_id?"Совпадений не найдено":"Начните с поиска");
  text($("empty-description"),s.busy?"Проверяем аудит-лог и доступные папки.":s.run_id?(s.complete?"По указанным условиям текущих копий нет.":"В поиске есть ошибки. Подробности — в журнале."):"Укажите период и отправителя, тему или Message-ID. Поиск не изменяет письма в ящиках.");
  $("demo-start").hidden=s.busy||!!s.run_id||s.demo;
  $("selection-bar").hidden=!s.count;text($("selection-label"),`Выбрано ${s.selected_count} из ${s.count} копий`);
  $("review-delete").disabled=!deletable()||!s.selected_count;
  $("select-all").disabled=!deletable();text($("select-all"),`Выбрать все ${s.count} найденных`);
  $("clear-selection").disabled=s.busy||!s.selected_count;
  $("export-csv").disabled=s.busy||!s.run_id;$("export-zip").disabled=s.busy||!s.run_id;
  $("open-reports").hidden=!s.report_dir;$("journal-folder").disabled=!s.report_dir;
  text($("result-caption"),s.not_located?`Каждая строка — отдельная копия. Не найдены копии для ${s.not_located} пар ящик / Message-ID; подробности в отчёте.`:"Каждая строка — отдельная копия письма в конкретной папке.");
  $("issues-panel").hidden=!s.issues.length;$("issues-list").replaceChildren();
  for(const issue of s.issues){const div=document.createElement("div");div.className="issue-item";text(div,issue.message);const small=document.createElement("small");text(small,[issue.code,issue.mailbox,issue.folder].filter(Boolean).join(" · "));div.append(small);$("issues-list").append(div)}
  $("journal-list").replaceChildren();
  for(const event of [...s.events].reverse()){const li=document.createElement("li"),time=document.createElement("time"),msg=document.createElement("span");text(time,new Date(event.at).toLocaleTimeString("ru-RU"));text(msg,event.message);li.append(time,msg);$("journal-list").append(li)}
  if(!s.events.length){const li=document.createElement("li");li.className="muted";text(li,"Операции ещё не запускались.");$("journal-list").append(li)}
  text($("journal-status"),s.message);
}
async function renderRows(){
  table=await api("get_rows",$("table-query").value,table.page,Number($("page-size").value),sort,descending);
  const tbody=$("result-rows");tbody.replaceChildren();
  for(const row of table.rows){
    const tr=document.createElement("tr");tr.classList.toggle("row-selected",row.selected);
    const select=document.createElement("td");select.className="checkbox-cell";
    const cb=document.createElement("input");cb.type="checkbox";cb.checked=row.selected;cb.disabled=!deletable();cb.setAttribute("aria-label",`Выбрать: ${safeText(row.subject)} — ${safeText(row.mailbox)}`);cb.addEventListener("change",handle(async()=>{await api("select_rows",[row.id],cb.checked);await refresh(true)}));select.append(cb);
    const subject=document.createElement("td"),title=document.createElement("span"),sender=document.createElement("span"),id=document.createElement("span");title.className="row-title";sender.className="row-sender";id.className="row-id";text(title,row.subject||"(без темы)");text(sender,`От: ${row.sender}`);text(id,`<${row.message_id}>`);subject.append(title,sender,id);
    const mailbox=document.createElement("td"),folder=document.createElement("td"),status=document.createElement("td");text(mailbox,row.mailbox);folder.className="row-folder";text(folder,row.folder);
    const badge=document.createElement("span");badge.className="badge"+(row.outcome?` ${row.outcome.status}`:"");text(badge,row.outcome?statusLabels[row.outcome.status]||row.outcome.status:"Найдено");if(row.outcome)badge.title=safeText(row.outcome.detail);status.append(badge);
    tr.append(select,subject,mailbox,folder,status);tbody.append(tr);
  }
  if(!table.rows.length&&state?.count){const tr=document.createElement("tr"),td=document.createElement("td");td.colSpan=5;td.className="muted";text(td,"В таблице нет строк с таким текстом. Выбранные на других страницах строки сохраняются.");tr.append(td);tbody.append(tr)}
  $("page-checkbox").checked=table.rows.length>0&&table.rows.every(x=>x.selected);
  $("page-checkbox").indeterminate=table.rows.some(x=>x.selected)&&!table.rows.every(x=>x.selected);
  $("page-checkbox").disabled=!deletable()||!table.rows.length;
  text($("page-description"),`Показано ${table.rows.length} из ${table.total} строк${$("table-query").value?" по фильтру таблицы":""}`);
  text($("page-number"),`${table.page} / ${table.pages}`);$("prev-page").disabled=table.page<=1;$("next-page").disabled=table.page>=table.pages;
  document.querySelectorAll(".sort-button").forEach(button=>{button.parentElement.setAttribute("aria-sort",button.dataset.sort===sort?(descending?"descending":"ascending"):"none")});
}
async function refresh(force=false){
  if(updating)return;updating=true;
  try{const next=await api("get_state");const changed=next.revision!==lastRevision||force;state=next;if(changed){lastRevision=state.revision;renderState();await renderRows();if(state.error)toast(state.error,true)}}finally{updating=false}
}
async function activateDemo(){const form=await api("set_demo",true);applyForm(form);table.page=1;await refresh(true);showView("search")}
async function bootstrap(){
  if(initialized)return;initialized=true;
  try{await refresh(true);if(state.demo){const form=await api("set_demo",true);applyForm(form);await refresh(true)}}catch(error){toast(error.message,true);initialized=false;return}
  setInterval(()=>refresh().catch(error=>toast(error.message,true)),600);
}
const today=new Date();$("date").value=`${String(today.getDate()).padStart(2,"0")}.${String(today.getMonth()+1).padStart(2,"0")}.${today.getFullYear()}`;
$("date").addEventListener("blur",()=>{const value=$("date").value.trim();const parts=value.match(/^(\d{1,2})[.-](\d{1,2})[.-](\d{4})$/);if(parts)$("date").value=`${parts[1].padStart(2,"0")}.${parts[2].padStart(2,"0")}.${parts[3]}`;else if(/^\d{8}$/.test(value))$("date").value=`${value.slice(0,2)}.${value.slice(2,4)}.${value.slice(4)}`});
for(const id of ["time-from","time-to"]){$(id).addEventListener("blur",()=>{const parts=$(id).value.trim().match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);if(parts)$(id).value=`${parts[1].padStart(2,"0")}:${parts[2]}:${parts[3]??"00"}`})}
document.querySelectorAll(".nav-item").forEach(button=>button.addEventListener("click",()=>showView(button.dataset.view)));
$("search-form").addEventListener("submit",handle(async event=>{event.preventDefault();await api("start_search",formValue());clearTimeout(toastTimer);$("toast").hidden=true;table.page=1;$("table-query").value="";await refresh(true)}));
$("search-form").addEventListener("input",handle(async()=>{syncSenderOption();if(state?.run_id&&!state.busy&&!state.invalidated){await api("invalidate_plan");await refresh(true)}}));
$("search-form").addEventListener("change",handle(async()=>{syncSenderOption();if(state?.run_id&&!state.busy&&!state.invalidated){await api("invalidate_plan");await refresh(true)}}));
$("demo-mode").addEventListener("change",handle(async()=>{if($("demo-mode").checked){await activateDemo()}else{await api("set_demo",false);await refresh(true)}}));
$("demo-start").addEventListener("click",handle(activateDemo));
$("connection-form").addEventListener("submit",handle(async event=>{event.preventDefault();await api("configure",{organization_id:$("org-id").value,oauth_token:$("oauth-token").value,client_id:$("client-id").value,client_secret:$("client-secret").value},$("remember").checked);for(const id of ["oauth-token","client-id","client-secret"]){$(id).value=""}await refresh(true);toast("Настройки применены. Можно проверить доступ или перейти к поиску.")}));
$("load-saved").addEventListener("click",handle(async()=>{await api("use_saved_connection");await refresh(true);toast("Сохранённое подключение применено.")}));
$("forget-saved").addEventListener("click",handle(async()=>{await api("forget_saved_connection");await refresh(true);toast("Сохранённые настройки удалены.")}));
$("check-button").addEventListener("click",handle(async()=>{await api("check_connection",$("check-mailbox").value);await refresh(true)}));
$("stop-button").addEventListener("click",handle(async()=>{await api("stop");await refresh(true)}));
$("select-all").addEventListener("click",handle(async()=>{await api("select_all");await refresh(true)}));
$("clear-selection").addEventListener("click",handle(async()=>{await api("clear_selection");await refresh(true)}));
$("page-checkbox").addEventListener("change",handle(async()=>{await api("select_rows",table.rows.map(x=>x.id),$("page-checkbox").checked);await refresh(true)}));
$("table-query").addEventListener("input",()=>{clearTimeout(tableTimer);tableTimer=setTimeout(()=>{table.page=1;renderRows().catch(error=>toast(error.message,true))},180)});
$("page-size").addEventListener("change",handle(async()=>{table.page=1;await renderRows()}));
$("prev-page").addEventListener("click",handle(async()=>{table.page--;await renderRows()}));
$("next-page").addEventListener("click",handle(async()=>{table.page++;await renderRows()}));
document.querySelectorAll(".sort-button").forEach(button=>button.addEventListener("click",handle(async()=>{descending=sort===button.dataset.sort?!descending:false;sort=button.dataset.sort;table.page=1;await renderRows()})));
$("review-delete").addEventListener("click",handle(async()=>{
  pending=await api("prepare_delete");text($("confirm-title"),`Удаление ${pending.count} выбранных копий`);
  const criteria=pending.criteria,context=[`Организация ${pending.organization_id}`,`Отправитель: ${criteria.sender||"любой"}`];
  if(criteria.subject)context.push(`Тема ${criteria.subject_mode==="exact"?"точно":"содержит"}: «${criteria.subject}»`);
  if(criteria.message_id)context.push(`Message-ID: <${criteria.message_id}>`);
  context.push(`${criteria.date.replaceAll("-",".")}, ${criteria.time_from}–${criteria.time_to} (Москва)`);
  text($("confirm-context"),context.join(" · "));
  text($("confirm-warning"),pending.demo?"Демо: будут обработаны только искусственные письма":"Эта операция безвозвратна");
  $("confirm-coverage").hidden=pending.search_complete;
  text($("confirm-coverage"),pending.search_complete?"":`Поиск неполный (проблем: ${pending.search_issue_count}). Будут обработаны только выбранные копии. Другие совпадения могли быть пропущены.`);
  text($("confirm-phrase"),pending.phrase);$("confirm-input").value="";$("confirm-error").textContent="";$("confirm-delete").disabled=true;$("confirm-list").replaceChildren();
  for(const row of pending.rows){const div=document.createElement("div"),title=document.createElement("strong"),sender=document.createElement("span"),small=document.createElement("small");div.className="confirm-row";sender.className="row-sender";text(title,row.subject||"(без темы)");text(sender,`От: ${row.sender}`);text(div,`${row.mailbox} · ${row.folder}`);text(small,`<${row.message_id}>`);div.prepend(title);div.append(sender,small);$("confirm-list").append(div)}
  $("confirm-dialog").showModal();$("confirm-input").focus();
}));
$("confirm-input").addEventListener("input",()=>$("confirm-delete").disabled=$("confirm-input").value!==pending?.phrase);
$("cancel-confirm").addEventListener("click",()=>{$("confirm-dialog").close();pending=null});
$("confirm-dialog").addEventListener("cancel",()=>{pending=null});
$("confirm-delete").addEventListener("click",async()=>{if(!pending)return;$("confirm-delete").disabled=true;try{await api("confirm_delete",pending.token,$("confirm-input").value);$("confirm-dialog").close();pending=null;await refresh(true)}catch(error){text($("confirm-error"),error.message);$("confirm-delete").disabled=false}});
for(const [id,kind] of [["export-csv","csv"],["export-zip","zip"]]){$(id).addEventListener("click",handle(async()=>{const path=await api("export_report",kind);if(path)toast(`Отчёт сохранён: ${path}`)}))}
for(const id of ["open-reports","journal-folder"]){$(id).addEventListener("click",handle(async()=>{await api("open_report_folder")}))}
document.addEventListener("click",event=>{if(event.target.closest("a")){event.preventDefault()}});
window.addEventListener("pywebviewready",bootstrap);
if(window.pywebview?.api)bootstrap();
