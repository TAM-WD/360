(function () {
  'use strict';

  const SELECTOR = '[class*="react-message-wrapper__body"]';
  const DONE_ATTR = 'data-openpath-done';

  // Поддерживаем максимально типовые пути:
  // - file:///Z:\...
  // - file:///Z:/...
  // - file://server/share/...
  // - Z:\...
  // - Z:/...
  // - \\server\share\...
  // - /Users/...
  // - /home/...
  // - /mnt/... /media/... /opt/... /var/... /srv/...
  const PATH_PATTERNS = [
    /file:\/\/\/[^\r\n<>"]+/gi,
    /file:\/\/[^\r\n<>"]+/gi,
    /[A-Za-z]:[\\\/][^\r\n<>"]+/gi,
    /\\\\[^\r\n<>"]+/gi,
    /\/(?:home|Users|mnt|media|opt|var|srv|Volumes)\/[^\r\n<>"]+/gi
  ];

  const KNOWN_EXTENSIONS =
    /\.(xlsx|xls|docx|doc|pptx|ppt|pdf|txt|csv|zip|rar|7z|jpg|jpeg|png|gif|bmp|msg|eml|xml|json|sql|log|exe|msi|bat|cmd|ps1|sh)\b/i;

  function cleanupPath(raw) {
    let s = raw.trim();

    // Если в конце есть известное расширение файла — обрезаем всё после него
    const extMatch = s.match(KNOWN_EXTENSIONS);
    if (extMatch) {
      const rx = new RegExp(KNOWN_EXTENSIONS.source, 'ig');
      let m, last;
      while ((m = rx.exec(s)) !== null) last = m;
      if (last) {
        s = s.slice(0, last.index + last[0].length);
      }
    }

    // Убираем типичный мусор в конце
    s = s
      .replace(/[ \t]+$/g, '')
      .replace(/[.,;!?]+$/g, '')
      .replace(/[)"'»]+$/g, '')
      .replace(/[\]}]+$/g, '');

    return s.trim();
  }

  function buildUrl(rawPath) {
    // ВАЖНО:
    // передаём исходный путь как параметр path=...
    // ничего не нормализуем в расширении
    return 'openpath://open?path=' + encodeURIComponent(rawPath.trim());
  }

  function createLink(pathText) {
    const a = document.createElement('a');
    a.href = buildUrl(pathText);
    a.textContent = pathText;
    a.title = 'Открыть папку';
    a.setAttribute('data-openpath', '1');
    a.style.cssText = [
      'color:#1a73e8',
      'text-decoration:underline',
      'cursor:pointer',
      'word-break:break-all',
      'font-family:inherit',
      'font-size:inherit'
    ].join(';');

    // Не ставим preventDefault — даём браузеру самому вызывать внешний протокол
    return a;
  }

  function processTextNode(textNode) {
    const text = textNode.nodeValue;
    if (!text || !text.trim()) return false;

    const matches = [];

    for (const regex of PATH_PATTERNS) {
      regex.lastIndex = 0;
      let m;
      while ((m = regex.exec(text)) !== null) {
        const cleaned = cleanupPath(m[0]);
        if (cleaned.length < 4) continue;

        matches.push({
          start: m.index,
          end: m.index + cleaned.length,
          text: cleaned
        });
      }
    }

    if (!matches.length) return false;

    matches.sort((a, b) => a.start - b.start);

    // убираем пересечения
    const deduped = [];
    for (const m of matches) {
      if (!deduped.length) {
        deduped.push(m);
        continue;
      }

      const prev = deduped[deduped.length - 1];
      if (m.start < prev.end) {
        const prevLen = prev.end - prev.start;
        const curLen = m.end - m.start;
        if (curLen > prevLen) deduped[deduped.length - 1] = m;
      } else {
        deduped.push(m);
      }
    }

    const frag = document.createDocumentFragment();
    let cursor = 0;

    for (const m of deduped) {
      if (m.start > cursor) {
        frag.appendChild(document.createTextNode(text.slice(cursor, m.start)));
      }

      frag.appendChild(createLink(m.text));
      cursor = m.end;
    }

    if (cursor < text.length) {
      frag.appendChild(document.createTextNode(text.slice(cursor)));
    }

    textNode.parentNode.replaceChild(frag, textNode);
    return true;
  }

  function processBody(bodyEl) {
    bodyEl.setAttribute(DONE_ATTR, '1');

    const walker = document.createTreeWalker(bodyEl, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue || !node.nodeValue.trim()) {
          return NodeFilter.FILTER_SKIP;
        }

        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_SKIP;

        const tag = parent.tagName;
        if (['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA'].includes(tag)) {
          return NodeFilter.FILTER_SKIP;
        }

        if (parent.getAttribute('data-openpath')) {
          return NodeFilter.FILTER_SKIP;
        }

        return NodeFilter.FILTER_ACCEPT;
      }
    });

    const nodes = [];
    let n;
    while ((n = walker.nextNode())) nodes.push(n);

    for (const node of nodes) {
      processTextNode(node);
    }
  }

  function scan() {
    const bodies = document.querySelectorAll(`${SELECTOR}:not([${DONE_ATTR}])`);
    for (const body of bodies) {
      processBody(body);
    }
  }

  function observe() {
    let timer;
    new MutationObserver(() => {
      clearTimeout(timer);
      timer = setTimeout(scan, 300);
    }).observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  function init() {
    scan();
    observe();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
