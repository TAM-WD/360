@echo off
chcp 65001 >nul
setlocal

echo.
echo ============================================
echo   OpenPath - удаление
echo ============================================
echo.

reg delete "HKCU\Software\Classes\openpath" /f >nul 2>&1

set "INSTALL_DIR=%LOCALAPPDATA%\OpenPath"
if exist "%INSTALL_DIR%" rmdir /S /Q "%INSTALL_DIR%"

echo Готово.
echo.
pause
