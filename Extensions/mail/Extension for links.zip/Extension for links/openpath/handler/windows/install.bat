@echo off
setlocal

set "INSTALL_DIR=%LOCALAPPDATA%\OpenPath"
set "PS1=%INSTALL_DIR%\openpath-handler.ps1"

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

copy /Y "%~dp0openpath-handler.ps1" "%PS1%" >nul

if not exist "%PS1%" (
    echo ERROR: openpath-handler.ps1 not found next to install.bat
    pause
    exit /b 1
)

reg add "HKCU\Software\Classes\openpath" /ve /d "URL:OpenPath Protocol" /f >nul
reg add "HKCU\Software\Classes\openpath" /v "URL Protocol" /d "" /f >nul
reg add "HKCU\Software\Classes\openpath\shell\open\command" /ve /d "\"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe\" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%PS1%\" \"%%1\"" /f >nul

echo.
echo OpenPath installed.
echo Log file: %LOCALAPPDATA%\OpenPath\openpath.log
echo.
pause
