param(
    [string]$Url
)

$InstallDir = Join-Path $env:LOCALAPPDATA "OpenPath"
$LogFile = Join-Path $InstallDir "openpath.log"

if (-not (Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
}

function Write-Log($Text) {
    $Time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $LogFile -Value "$Time  $Text"
}

function Decode-Deep([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) { return $Value }

    $Current = $Value
    for ($i = 0; $i -lt 3; $i++) {
        try {
            $Decoded = [System.Uri]::UnescapeDataString($Current)
            if ($Decoded -eq $Current) { break }
            $Current = $Decoded
        } catch {
            break
        }
    }
    return $Current
}

function Get-QueryParamValue($InputUrl, $ParamName) {
    $pattern = '[?&]' + [regex]::Escape($ParamName) + '=([^&]+)'
    $m = [regex]::Match($InputUrl, $pattern)
    if ($m.Success) {
        return $m.Groups[1].Value
    }
    return $null
}

function Normalize-InputPath($RawPath) {
    if ([string]::IsNullOrWhiteSpace($RawPath)) {
        return $RawPath
    }

    $Path = Decode-Deep($RawPath)
    $Path = $Path.Trim('"').Trim()

    # file:///Z:\folder\file.xlsx
    # file:///Z:/folder/file.xlsx
    if ($Path -match '^file:///') {
        $Rest = $Path -replace '^file:///', ''
        $Rest = Decode-Deep($Rest)

        if ($Rest -match '^[A-Za-z]:') {
            return ($Rest -replace '/', '\')
        }

        # Unix absolute path
        return ('/' + $Rest.TrimStart('/'))
    }

    # file://server/share/folder/file
    if ($Path -match '^file://') {
        $Rest = $Path -replace '^file://', ''
        $Rest = Decode-Deep($Rest)
        $Rest = $Rest -replace '/', '\'
        return ('\\' + $Rest)
    }

    # C:/Temp -> C:\Temp
    if ($Path -match '^[A-Za-z]:/') {
        return ($Path -replace '/', '\')
    }

    # //server/share -> \\server\share
    if ($Path -match '^//') {
        return ($Path -replace '/', '\')
    }

    # already UNC or Windows path or Unix path
    return $Path
}

try {
    Write-Log "RAW URL: $Url"

    if ([string]::IsNullOrWhiteSpace($Url)) {
        Write-Log "Empty URL"
        exit 1
    }

    $EncodedPath = Get-QueryParamValue -InputUrl $Url -ParamName "path"
    if ([string]::IsNullOrWhiteSpace($EncodedPath)) {
        Write-Log "No path parameter found"
        exit 1
    }

    Write-Log "ENCODED PATH: $EncodedPath"

    $Path = Normalize-InputPath $EncodedPath
    Write-Log "NORMALIZED PATH: $Path"

    if (Test-Path -LiteralPath $Path -PathType Leaf) {
        Write-Log "Detected file"
        Start-Process -FilePath explorer.exe -ArgumentList "/select,`"$Path`""
        exit 0
    }

    if (Test-Path -LiteralPath $Path -PathType Container) {
        Write-Log "Detected folder"
        Start-Process -FilePath explorer.exe -ArgumentList "`"$Path`""
        exit 0
    }

    $Parent = Split-Path -Path $Path -Parent
    Write-Log "Parent: $Parent"

    if (-not [string]::IsNullOrWhiteSpace($Parent)) {
        Start-Process -FilePath explorer.exe -ArgumentList "`"$Parent`""
        exit 0
    }

    Write-Log "Fallback open path as-is"
    Start-Process -FilePath explorer.exe -ArgumentList "`"$Path`""
    exit 0
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    exit 1
}
