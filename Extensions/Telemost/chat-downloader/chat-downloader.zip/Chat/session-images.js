(function (root) {
  'use strict';

  const imageExtensions = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp' };
  const validKey = key => typeof key === 'string' && /^[a-zA-Z0-9_-]{1,80}$/.test(key);
  const validRun = id => typeof id === 'string' && /^[a-zA-Z0-9-]{8,80}$/.test(id);
  const validReference = (key, path) => validKey(key) && Object.values(imageExtensions).some(ext => path === `media/${key}.${ext}`);
  const maxImage = 8 * 1024 * 1024;
  const maxRun = 4 * maxImage;
  const maxCache = 3 * maxRun;
  const retentionMs = 7 * 24 * 3600 * 1000;
  let connection;

  function database() {
    if (!connection) connection = new Promise((resolve, reject) => {
      const open = indexedDB.open('chatDownloaderSessionImages', 1);
      open.onupgradeneeded = () => {
        open.result.createObjectStore('images', { keyPath: ['runId', 'key'] });
        open.result.createObjectStore('runs', { keyPath: 'runId' });
      };
      open.onsuccess = () => {
        const db = open.result;
        db.onversionchange = () => { db.close(); connection = null; };
        resolve(db);
      };
      open.onerror = () => { connection = null; reject(open.error); };
    });
    return connection;
  }

  function parseImage(dataUrl) {
    if (typeof dataUrl !== 'string' || dataUrl.length > Math.ceil(maxImage / 3) * 4 + 32) return null;
    const header = /^data:(image\/(?:png|jpeg|gif|webp));base64,/.exec(dataUrl);
    if (!header) return null;
    const binary = atob(dataUrl.slice(header[0].length));
    if (!binary.length || binary.length > maxImage) return null;
    const mime = header[1];
    const matches = mime === 'image/png' ? binary.startsWith('\x89PNG\r\n\x1a\n') :
      mime === 'image/jpeg' ? binary.startsWith('\xff\xd8\xff') :
      mime === 'image/gif' ? /^GIF8[79]a/.test(binary) :
      binary.startsWith('RIFF') && binary.slice(8, 12) === 'WEBP';
    if (!matches) return null;
    return { mime, bytes: Uint8Array.from(binary, char => char.charCodeAt(0)) };
  }

  async function storeImage(runId, key, dataUrl) {
    if (!validRun(runId) || !validKey(key)) return { ok: false };
    const image = parseImage(dataUrl);
    if (!image) return { ok: false, reason: 'session-image-unsupported' };
    const db = await database();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(['images', 'runs'], 'readwrite');
      const images = tx.objectStore('images'), runs = tx.objectStore('runs');
      let result = { ok: false, reason: 'session-image-run-limit' };
      tx.oncomplete = () => resolve(result);
      tx.onabort = () => reject(tx.error || new Error('image-storage-aborted'));
      const all = runs.getAll();
      all.onsuccess = () => {
        const now = Date.now(), size = image.bytes.byteLength;
        const current = all.result.find(run => run.runId === runId);
        if ((current?.size || 0) + size > maxRun) return;
        let total = all.result.reduce((sum, run) => sum + run.size, size);
        for (const run of all.result.sort((a, b) => a.updated - b.updated)) {
          if (run.runId === runId || (now - run.updated < retentionMs && total <= maxCache)) continue;
          images.delete(IDBKeyRange.bound([run.runId], [run.runId, []]));
          runs.delete(run.runId);
          total -= run.size;
        }
        images.add({ runId, key, ...image });
        runs.put({ runId, size: (current?.size || 0) + size, updated: now });
        result = { ok: true };
      };
    });
  }

  async function getImage(runId, key) {
    if (!validRun(runId) || !validKey(key)) return null;
    const db = await database();
    return new Promise((resolve, reject) => {
      const request = db.transaction('images').objectStore('images').get([runId, key]);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  async function getDataURL(runId, key) {
    const image = await getImage(runId, key);
    if (!image) return '';
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(new Blob([image.bytes], { type: image.mime }));
    });
  }

  function installStore(chrome) {
    chrome.runtime.onMessage.addListener((message, sender, reply) => {
      if (message?.type !== 'session-image:store' || sender?.id !== chrome.runtime.id || !sender.tab) return;
      storeImage(message.runId, message.key, message.dataUrl).then(reply,
        () => reply({ ok: false, reason: 'session-image-storage-error' }));
      return true;
    });
  }

  // Resolve the actual stored bytes before building either Excel links or a download job.
  async function prepareArchiveImages(runId, messages) {
    const files = new Map(), paths = new Map();
    for (const message of messages) for (const link of message.attachmentLinks || []) {
      const key = link.sessionImageKey;
      if (!key || link.url) continue;
      if (!paths.has(key)) {
        const image = await getImage(runId, key).catch(() => null);
        const path = image && validKey(key) && Object.hasOwn(imageExtensions, image.mime)
          ? `media/${key}.${imageExtensions[image.mime]}` : '';
        if (path) files.set(path, image.bytes);
        paths.set(key, path);
      }
      if (paths.get(key)) link.sessionImagePath = paths.get(key);
      else {
        delete link.sessionImageKey;
        delete link.sessionImagePath;
        link.urlReason = 'session-image-unavailable';
      }
    }
    return files;
  }

  root.SessionImages = { validReference, getDataURL, installStore, prepareArchiveImages };
})(globalThis);
