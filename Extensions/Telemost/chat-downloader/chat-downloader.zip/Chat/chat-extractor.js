(function (root) {
  'use strict';

  // Keep cancellation tokens outside the injected function so a second inspect
  // injection cannot detach an already running collector from its Stop button.
  const controls = root.__chatDownloaderControls || (root.__chatDownloaderControls = {
    active: null, pending: new Set(), finished: new Set()
  });
  controls.pendingPaused ||= new Set();
  function remember(set, id) {
    set.add(id);
    if (set.size > 100) set.delete(set.values().next().value);
  }
  function cancel(runId) {
    if (typeof runId !== 'string' || !runId || controls.finished.has(runId)) return false;
    if (controls.active?.id === runId) {
      controls.active.stopped = true;
      controls.active.record?.('collector.cancel', { stopped: true, reason: 'user-stopped' });
      controls.active.wake?.();
      controls.active.resumeWake?.();
    } else remember(controls.pending, runId);
    return true;
  }
  function setPaused(runId, paused) {
    if (typeof runId !== 'string' || !runId || typeof paused !== 'boolean' || controls.finished.has(runId)) return false;
    const active = controls.active;
    if (active?.id === runId) {
      if (active.stopped) return false;
      if (active.paused === paused) return true;
      if (paused) {
        active.capturePause?.();
        active.pausedAt = Date.now();
        active.paused = true;
        active.wasPaused = true;
      } else {
        active.pausedMs += Math.max(0, Date.now() - active.pausedAt);
        active.paused = false;
        active.resumeSeq++;
      }
      active.record?.(paused ? 'collector.pause' : 'collector.resume', { paused, ...active.timing?.() });
      if (paused) active.wake?.();
      else active.resumeWake?.();
      return true;
    }
    if (active || controls.pending.has(runId)) return false;
    if (paused) { remember(controls.pendingPaused, runId); return true; }
    return controls.pendingPaused.delete(runId);
  }

  function classifyCoverage(coverage, metadata = {}) {
    try {
      const classified = root.ChatExport?.classifyCoverage(coverage, metadata);
      if (classified && ['complete', 'partial', 'unverified'].includes(classified.status) &&
          classified.complete === (classified.status === 'complete')) return classified;
    } catch {}
    // A missing optional helper must not discard already collected messages or
    // turn an unconfirmed boundary into a claim that messages are missing.
    const interrupted = new Set(['limit', 'user-stopped', 'running', 'gaps', 'unstable-ids', 'missing-replies',
      'not-opened', 'open-failed', 'thread-error', 'close-failed', 'thread-close-failed', 'no-scroller', 'error']);
    const threadEntries = Array.isArray(metadata.threads) ? metadata.threads : [];
    const partialThreads = threadEntries.filter(entry => entry.coverage?.status === 'partial');
    const reasons = [coverage.reason, coverage.upwardStopReason, coverage.downwardStopReason,
      ...partialThreads.map(entry => entry.coverage.statusReason).filter(reason => ['user-stopped', 'limit'].includes(reason))];
    const statusReason = reasons.includes('user-stopped') ? 'user-stopped' : reasons.includes('limit') ? 'limit'
      : reasons.find(reason => interrupted.has(reason)) || (coverage.hasGaps ? 'gaps'
        : coverage.unstableIds ? 'unstable-ids'
        : metadata.scope === 'thread' && metadata.expectedReplies > metadata.collectedReplies ? 'missing-replies'
        : partialThreads.length ? 'threads-incomplete' : '');
    const positionGaps = coverage.positionGaps === true || coverage.positionGapCount > 0;
    const complete = !statusReason && !positionGaps && coverage.complete === true && coverage.startReached === true &&
      coverage.endReached === true && metadata.threadsSummary?.complete !== false &&
      threadEntries.every(entry => entry.coverage?.complete === true);
    return { ...coverage, positionGaps, status: statusReason ? 'partial' : complete ? 'complete' : 'unverified', complete, statusReason };
  }

  function hasThreadCollectionIssues(metadata) {
    try {
      const result = root.ChatExport?.hasThreadCollectionIssues(metadata);
      if (typeof result === 'boolean') return result;
    } catch {}
    const issues = new Set(['gaps', 'unstable-ids', 'missing-replies', 'open-failed', 'not-opened',
      'no-scroller', 'thread-error', 'close-failed', 'thread-close-failed', 'error']);
    return metadata.threads.some(entry => {
      const coverage = entry.coverage || {};
      return entry.collectedReplies < entry.expectedReplies || coverage.hasGaps === true || coverage.unstableIds === true ||
        [coverage.reason, coverage.upwardStopReason, coverage.downwardStopReason].some(reason => issues.has(reason));
    });
  }

  async function run(options = {}) {
    let recorder = null;
    try {
      if (options.mode !== 'inspect') recorder = root.ChatDiagnostics?.createRecorder({
        runId: options.runId, version: options.version, source: 'collector'
      }) || null;
    } catch {}
    const record = (event, fields) => { try { recorder?.record(event, fields); } catch {} };
    const reference = value => { try { return value ? root.ChatDiagnostics?.ref(value) : undefined; } catch { return undefined; } };
    const errorCode = error => { try { return root.ChatDiagnostics?.errorCode(error); } catch { return undefined; } };
    async function finish(result, fields) {
      record('collector.finish', fields);
      try { await recorder?.flush(); } catch {}
      try { if (recorder) result.diagnostics = recorder.snapshot(); } catch {}
      return result;
    }
    const warnings = new Set();
    const trim = value => (value || '').trim();
    const visible = node => node && node.getClientRects().length > 0 &&
      getComputedStyle(node).visibility !== 'hidden';
    const panelFor = content => content.closest('.yamb-chat') || content.closest('.yamb-conversation') || content.parentElement;
    const isThread = content => Boolean(panelFor(content).querySelector('.yamb-thread-header-controls-container'));
    const allContents = () => Array.from(document.querySelectorAll('.yamb-conversation__content')).filter(visible);
    const roots = Array.from(document.querySelectorAll('.yamb-conversation__content')).filter(content =>
      !isThread(content) && (visible(content) ||
        panelFor(content).classList?.contains('yamb-chat_thread-openned') && allContents().some(isThread)));
    if (!roots.length) return finish({ detected: false, error: 'Откройте основную переписку и дождитесь загрузки сообщений.' },
      { outcome: 'error', reason: 'no-root' });
    if (roots.length > 1) return finish({ detected: false, error: 'Открыто несколько переписок. Оставьте один основной чат и повторите выгрузку.' },
      { outcome: 'error', reason: 'ambiguous' });
    function createScope(content, rootId = '', expectedReplies = 0) {
      const conversation = content.closest('.yamb-conversation') || content.parentElement;
      const legacy = conversation.querySelector('.ui-InfiniteList-ScrollContainer[data-scroll-container="true"]') ||
        conversation.querySelector('.ui-InfiniteList[data-scroll-container="true"]');
      let scroller = legacy;
      if (!scroller) {
        for (let node = content; node && node !== document.body; node = node.parentElement) {
          if (node.matches('.ui-virtual-list__scroller, .ui-scroll-area__container') ||
              /auto|scroll/.test(getComputedStyle(node).overflowY)) { scroller = node; break; }
        }
      }
      return { content, conversation, panel: panelFor(content), legacy, scroller, rootId, expectedReplies,
        messages: new Map(), seenPositions: new Set(), knownTotal: 0, reason: 'stable-boundaries',
        startReached: false, endReached: false, startEvidence: '', endEvidence: '',
        upwardStopReason: 'not-started', downwardStopReason: 'not-started', nativeUsed: !legacy,
        audit: { observedIds: new Set(), dateIds: new Set(), windowSeq: 0, windowChangeCount: 0,
          windowGapTotal: 0, omittedGapEvents: 0, mutationReadCount: 0, mutationNewMessages: 0,
          readErrorCount: 0, idCollisionTotal: 0, idPositionChangedTotal: 0 },
        scrollAttempts: { wheel: 0, native: 0 } };
    }
    const main = createScope(roots[0]);
    if (!main.scroller) return finish({ detected: false, error: 'Не найден контейнер прокрутки переписки.' },
      { outcome: 'error', reason: 'no-scroller' });
    const titleNode = document.querySelector('.yamb-chat-header__title, .yamb-conversation-header__title');
    const chatTitle = trim(titleNode && titleNode.textContent) || document.title.replace(/\s*[—–]\s*\d+.*$/, '');
    if (options.mode === 'inspect') return { detected: true, chatTitle, adapter: main.legacy ? 'infinite-list' : 'native-scroll' };
    if (root.__chatDownloaderRunning) return finish({ error: 'В этой вкладке уже идёт выгрузка.' },
      { outcome: 'error', reason: 'busy' });
    root.__chatDownloaderRunning = true;
    const runId = typeof options.runId === 'string' ? options.runId : '';
    const control = { id: runId, stopped: controls.pending.delete(runId), wake: null, resumeWake: null, record,
      paused: controls.pendingPaused.delete(runId), pausedAt: Date.now(), pausedMs: 0, resumeSeq: 0 };
    control.wasPaused = control.paused;
    controls.active = control;
    const now = () => {
      const wall = Date.now();
      return wall - control.pausedMs - (control.paused ? Math.max(0, wall - control.pausedAt) : 0);
    };
    async function waitWhilePaused() {
      while (control.paused && !control.stopped) {
        await new Promise(resolve => {
          const wake = () => { if (control.resumeWake === wake) control.resumeWake = null; resolve(); };
          control.resumeWake = wake;
        });
      }
    }
    const rawSleep = ms => new Promise(resolve => {
      if (control.stopped) { resolve(); return; }
      let timer;
      let settled = false;
      const done = () => {
        if (settled) return;
        settled = true;
        if (typeof clearTimeout === 'function') clearTimeout(timer);
        if (control.wake === done) control.wake = null;
        resolve();
      };
      control.wake = done;
      timer = setTimeout(done, ms);
    });
    const sleep = async ms => {
      await waitWhilePaused();
      if (!control.stopped) await rawSleep(ms);
      await waitWhilePaused();
    };

    const startedAt = now();
    const wallStartedAt = Date.now();
    control.timing = () => ({ activeElapsedMs: now() - startedAt,
      pausedDurationMs: Date.now() - wallStartedAt - (now() - startedAt) });
    const originalURL = location.href;
    const delayMs = Math.max(20, options.delayMs || 300);
    const stableRounds = Math.max(2, options.stableRounds || 12);
    const maxDurationMs = Number.isFinite(options.maxDurationMs) && options.maxDurationMs > 0 ? options.maxDurationMs : 0;
    const remainingBudget = () => maxDurationMs ? Math.max(0, maxDurationMs - (now() - startedAt)) : Infinity;
    const noProgressTimeoutMs = options.noProgressTimeoutMs || 60 * 1000;
    const threadOpenTimeoutMs = options.threadOpenTimeoutMs || 15000;
    const threadParentSearchTimeoutMs = options.threadParentSearchTimeoutMs || 60000;
    const edgeRetryDelayMs = Math.max(20, options.edgeRetryDelayMs || 3000);
    const threads = new Map();
    const anonymousNodes = new WeakMap();
    let anonymousIndex = 0;
    let limitReached = false;
    let threadNavigationFailed = false;

    record('collector.start', { delayMs, stableRounds, maxDurationMs, noProgressTimeoutMs, threadOpenTimeoutMs, threadParentSearchTimeoutMs, edgeRetryDelayMs,
      stopped: control.stopped, paused: control.paused, hidden: document.hidden === true });
    if (control.stopped) record('collector.cancel', { stopped: true, reason: 'user-stopped' });

    const articles = scope => Array.from(scope.content.querySelectorAll('article.message'));
    function diagnosticState(scope) {
      if (!recorder) return {};
      try { return { scope: scope.rootId ? 'thread' : 'main', threadRef: reference(scope.rootId),
        adapter: scope.legacy ? 'infinite-list' : 'native-scroll', nativeUsed: scope.nativeUsed,
        scrollTop: scope.scroller.scrollTop, scrollHeight: scope.scroller.scrollHeight,
        clientHeight: scope.scroller.clientHeight, visible: visible(scope.content),
        connected: Boolean(scope.content.isConnected && scope.scroller.isConnected), hidden: document.hidden === true,
        elapsedMs: now() - startedAt, ...control.timing(), paused: control.paused, messageCount: scope.messages.size,
        oldestTimestampMs: scope.oldestTimestampMs, newestTimestampMs: scope.newestTimestampMs,
        seenPositionCount: scope.seenPositions.size, minPosition: scope.diagnosticMinPosition,
        maxPosition: scope.diagnosticMaxPosition, expectedTotal: scope.knownTotal || scope.expectedReplies || 0,
        wheelAttempts: scope.scrollAttempts.wheel, nativeAttempts: scope.scrollAttempts.native,
        ...scope.lastDiagnosticSnapshot }; } catch { return {}; }
    }
    function navigationState(rootId) {
      if (!recorder) return {};
      try {
        const list = articles(main);
        return { ...diagnosticState(main), threadRef: reference(rootId),
          firstPosition: Number(list[0]?.getAttribute('aria-posinset')) || 0,
          lastPosition: Number(list[list.length - 1]?.getAttribute('aria-posinset')) || 0,
          // Opening or closing a thread can remount the main window before the
          // next collection snapshot. Do not reuse its previous endpoint IDs.
          firstRef: undefined, lastRef: undefined };
      } catch { return {}; }
    }
    function stableIdentity(article, strict = false) {
      const explicit = article.getAttribute('data-message-id');
      const bases = trim(article.getAttribute('aria-labelledby')).split(/\s+/)
        .map(label => /^(\d+)_(?:h|fr|c|i|fo)$/.exec(label)).filter(Boolean).map(match => match[1]);
      const labels = bases.length && bases.every(base => base === bases[0]) ? bases[0] : '';
      if (!strict && explicit) return { id: explicit, source: 'explicit' };
      if (!strict && labels) return { id: labels, source: 'label' };
      // Messenger's own message body carries the same microsecond ID. Do not
      // take IDs from quoted messages or embedded cards inside another article.
      const timestamps = Array.from(article.querySelectorAll('.yamb-message-content[data-timestamp]'))
        .filter(node => node.closest('article.message') === article && !node.closest('.yamb-message-reply'))
        .map(node => node.getAttribute('data-timestamp'))
        .filter(value => /^\d{16}$/.test(value || '') && Number(value.slice(0, -3)) >= 946684800000 &&
          Number(value.slice(0, -3)) < 4102444800000);
      const timestamp = timestamps.length && timestamps.every(value => value === timestamps[0]) ? timestamps[0] : '';
      if (strict && new Set([explicit, ...bases, ...timestamps].filter(Boolean)).size > 1) {
        return { id: '', source: 'mixed', conflict: true };
      }
      if (explicit) return { id: explicit, source: 'explicit' };
      if (labels) return { id: labels, source: 'label' };
      if (timestamp) return { id: timestamp, source: 'timestamp' };
      if (article.id) return { id: article.id, source: 'element' };
      return { id: '', source: 'none' };
    }
    function threadIdentity(content) {
      const conversation = content.closest('.yamb-conversation') || content.parentElement;
      const legacyParent = conversation.querySelector('.ui-InfiniteList-Header article.message');
      const list = conversation.querySelectorAll ? Array.from(conversation.querySelectorAll('article.message')) : [];
      if (legacyParent && !list.includes(legacyParent)) list.push(legacyParent);
      const candidates = list.filter(article => {
        if (article.closest?.('.yamb-message-reply') || article.parentElement?.closest('article.message')) return false;
        const owner = article.closest?.('.yamb-conversation');
        if (owner && owner !== conversation) return false;
        // The parent is outside the reply list. Legacy layouts may place the
        // header inside the list container; ordinary replies must never match.
        return article === legacyParent || article.closest?.('.ui-InfiniteList-Header') ||
          !(content.contains?.(article) || article.closest?.('.yamb-conversation__content'));
      });
      const info = { id: '', parentIdSource: 'none', parentCandidateCount: candidates.length };
      if (!candidates.length) return { ...info, threadOpenReason: 'parent-missing' };
      const identities = candidates.map(article => stableIdentity(article, true));
      if (identities.some(identity => identity.conflict)) return { ...info, parentIdSource: 'mixed', threadOpenReason: 'parent-id-conflict' };
      const ids = new Set(identities.map(identity => identity.id).filter(Boolean));
      if (ids.size > 1) return { ...info, parentIdSource: 'mixed', threadOpenReason: 'parent-ambiguous' };
      if (ids.size !== 1 || identities.some(identity => !identity.id)) return { ...info, threadOpenReason: 'parent-id-missing' };
      const sources = new Set(identities.map(identity => identity.source));
      return { ...info, id: identities[0].id, parentIdSource: sources.size === 1 ? identities[0].source : 'mixed', threadOpenReason: 'matched' };
    }
    function idSource(article) {
      const identity = stableIdentity(article);
      if (identity.id) return identity.source;
      if (Number(article.getAttribute('aria-posinset')) > 0) return 'position';
      return 'anonymous';
    }
    record('collector.container', diagnosticState(main));
    function messageId(article, scope = main) {
      const identity = stableIdentity(article);
      if (identity.id) return identity.id;
      const position = article.getAttribute('aria-posinset');
      const prefix = scope.rootId ? `thread-${scope.rootId}-` : '';
      if (position && Number(position) > 0) {
        warnings.add('Идентификаторы части сообщений восстановлены по позиции в истории.');
        return `${prefix}position-${position}`;
      }
      warnings.add('У части сообщений нет устойчивого ID; возможны повторы после перерисовки страницы.');
      if (!anonymousNodes.has(article)) anonymousNodes.set(article, `unidentified-${prefix}${++anonymousIndex}`);
      return anonymousNodes.get(article);
    }
    function renderedText(node) {
      if (!node) return '';
      // innerText preserves paragraphs and line breaks in copyable rich text.
      return trim(node.innerText || node.textContent);
    }
    function safeAttachmentURL(value) {
      if (!value) return '';
      try {
        const url = new URL(value, location.href);
        return /^https?:$/.test(url.protocol) && !url.username && !url.password ? url.href : '';
      } catch { return ''; }
    }
    function attachmentURL(node) {
      const anchor = node.matches('a[href]') ? node : node.querySelector('a[href]');
      const direct = safeAttachmentURL(anchor && anchor.getAttribute('href'));
      if (direct) return direct;
      const media = node.matches('img, video, audio, source') ? node : node.querySelector('video, audio, source, img');
      const source = safeAttachmentURL(media && (media.currentSrc || media.getAttribute('src')));
      // Download the original rather than a thumbnail when its storage ID is available.
      const thumbnail = node.matches('[data-lightbox-gallery-thumbnail]') ? node
        : node.querySelector('[data-lightbox-gallery-thumbnail]');
      const fileId = thumbnail && thumbnail.getAttribute('data-lightbox-gallery-thumbnail');
      if (/^disk\/[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(fileId || '')) {
        let origin = '';
        for (const link of document.querySelectorAll('.yamb-message-file a[href], a.yamb-message-file[href]')) {
          const value = safeAttachmentURL(link.getAttribute('href'));
          if (!value) continue;
          const url = new URL(value);
          if (/^files\.messenger\.yandex\.(ru|net|com)$/.test(url.hostname) &&
              url.pathname.startsWith('/file_shortterm/')) { origin = url.origin; break; }
        }
        if (!origin && /^(?:(?:telemost|messenger)(?:\.360)?\.)?yandex\.ru$/.test(new URL(location.href).hostname)) {
          origin = 'https://files.messenger.yandex.ru';
        }
        if (origin) return `${origin}/file_shortterm/${fileId}?attach=true`;
      }
      return source;
    }
    function exactTimestamp(article, datetime) {
      const body = article.querySelector('.yamb-message-content[data-timestamp]');
      const raw = body && body.getAttribute('data-timestamp');
      let milliseconds = null;
      if (/^\d{16}$/.test(raw || '')) milliseconds = Number(raw.slice(0, -3));
      else if (/^\d{13}$/.test(raw || '')) milliseconds = Number(raw);
      // System messages may have no body. Their accessible IDs use the same
      // microsecond timestamp as the message body in Messenger.
      if (milliseconds === null && !datetime) {
        const labels = trim(article.getAttribute('aria-labelledby')).split(/\s+/);
        const bases = labels.map(label => /^(\d{16})_(?:h|fr|c|i|fo)$/.exec(label)).filter(Boolean).map(match => match[1]);
        if (bases.length && bases.every(base => base === bases[0])) milliseconds = Number(bases[0].slice(0, -3));
      }
      return milliseconds !== null && milliseconds >= 946684800000 && milliseconds < 4102444800000 ? milliseconds : null;
    }
    function parseArticle(article, scope) {
      const row = article.querySelector('.yamb-message-row');
      const system = article.querySelector('.yamb-message-system');
      const call = Array.from(article.querySelectorAll('.yamb-message-call')).find(node =>
        node.closest('article.message') === article && !node.closest('.yamb-message-reply'));
      // A date separator can precede a NORMAL message within the same article.
      if (!row && !call && system && /^(?:сегодня|вчера|today|yesterday|\d{1,2}\s+[а-яa-z]+(?:\s+\d{4})?)$/i.test(renderedText(system))) return null;
      const id = messageId(article, scope);
      const own = Boolean(article.querySelector('.yamb-message-row_own'));
      const senderNode = article.querySelector('.yamb-message-user');
      const sender = trim(senderNode && senderNode.getAttribute('aria-label')) ||
        renderedText(article.querySelector('.yamb-message-user__name')) || '';
      const reply = article.querySelector('.yamb-message-reply');
      const textNodes = Array.from(article.querySelectorAll('[data-copyable="true"]'))
        .filter(node => !node.closest('.yamb-message-reply, .yamb-message-system'));
      const outerTextNodes = textNodes.filter(node => !textNodes.some(other => other !== node && other.contains(node)));
      let text = outerTextNodes.map(renderedText).filter(Boolean).join('\n');
      if (!text) {
        const textBlock = article.querySelector('.yamb-message-text');
        if (textBlock) {
          // Older variants put the clock inside this wrapper.
          const plain = textBlock.querySelector('.text');
          text = renderedText(plain) || Array.from(textBlock.childNodes)
            .filter(node => node.nodeType === 3).map(node => trim(node.textContent)).join('\n');
        }
      }
      const attachments = [];
      const attachmentLinks = [];
      function addAttachment(node, name) {
        const url = attachmentURL(node);
        attachments.push(name);
        attachmentLinks.push({ name, url });
      }
      article.querySelectorAll('.yamb-message-file').forEach(file => {
        if (file.closest('.yamb-message-reply')) return;
        const name = renderedText(file.querySelector('.yamb-message-file__name')) || 'Файл';
        const size = renderedText(file.querySelector('.yamb-message-file__size'));
        addAttachment(file, size ? `${name} (${size})` : name);
      });
      const attachmentTypes = [
        ['.yamb-message-image, .yamb-gallery-image', 'Изображение'],
        ['.yamb-message-video', 'Видео'],
        ['.yamb-message-voice', 'Голосовое сообщение'],
        ['.yamb-message-audio', 'Аудио'],
        ['.yamb-message-sticker', 'Стикер']
      ];
      attachmentTypes.forEach(([selector, label]) => {
        article.querySelectorAll(selector).forEach(node => {
          // A gallery wrapper is not another attachment alongside its images.
          if (!node.closest('.yamb-message-reply') && !node.querySelector(selector)) addAttachment(node, label);
        });
      });
      const timeNode = article.querySelector('.yamb-message-info__time');
      const time = trim(timeNode && (timeNode.getAttribute('aria-label') || timeNode.textContent));
      const datetime = timeNode && timeNode.getAttribute('datetime');
      const timestampMs = exactTimestamp(article, datetime);
      const date = datetime ? datetime.slice(0, 10) : (time.match(/^\d{1,2}:\d{2}\s+(.+)$/) || [])[1] ||
        (row && system ? renderedText(system) : '');
      const questionText = renderedText(reply && reply.querySelector('.yamb-message-reply__description'));
      const questionAuthor = renderedText(reply && reply.querySelector('.yamb-message-reply__title'));
      const replyToId = reply && (reply.getAttribute('data-reply-to-id') || reply.getAttribute('data-message-id')) || '';
      if (!row && system) text = renderedText(system);
      const buttonLabels = Array.from(article.querySelectorAll('.yamb-message-api-keyboard button.yamb-message-api-keyboard__button-wrapper'))
        .filter(button => button.closest?.('article.message') === article &&
          !button.closest?.('.yamb-message-reply, .yamb-message-system') &&
          typeof button.getClientRects === 'function' && visible(button))
        .map(button => {
          const label = button.querySelector('span.ui-button__text');
          return label && label.closest?.('article.message') === article &&
            typeof label.getClientRects === 'function' && visible(label) ? renderedText(label).replace(/\s+/g, ' ') : '';
        }).filter(Boolean);
      if (buttonLabels.length) text = [text, `Кнопки: ${buttonLabels.join('; ')}`].filter(Boolean).join('\n');
      if (call) {
        // Call cards have their own text nodes. The status also contains the
        // message clock, which belongs in the date/time column, not the body.
        const title = renderedText(call.querySelector('.yamb-message-call__title')) || 'Звонок';
        const statusNode = call.querySelector('.yamb-message-call__status');
        function callStatusText(node) {
          if (!node) return '';
          if (node.nodeType === 3) return node.textContent || '';
          if (node.matches?.('.yamb-message-info, .yamb-message-info__time, button, a, .ui-icon')) return '';
          return Array.from(node.childNodes || []).map(callStatusText).join('');
        }
        const status = callStatusText(statusNode).replace(/\s+/g, ' ').replace(/[\s•·]+$/g, '').trim();
        text = [title, status].filter(Boolean).join('\n');
      }
      let contentUnavailable = false;
      if (!text && !attachments.length && row) {
        text = '[Сообщение без доступного текста]';
        contentUnavailable = true;
      }
      if (!text && !attachments.length) return null;
      return { id, threadRootId: id === scope.rootId ? '' : scope.rootId, time, date, datetime: datetime || '', timestampMs, sender, isOwnMessage: own, message: text, contentUnavailable, replyToId,
        questionText, questionAuthor, attachments, attachmentLinks, type: call || !row && system ? 'Системное' : reply ? 'Ответ' : 'Сообщение',
        order: Number(article.getAttribute('aria-posinset')) || 0 };
    }
    function windowState(scope, list) {
      const ids = list.map(article => messageId(article, scope));
      const positions = list.map(article => Number(article.getAttribute('aria-posinset')) || 0);
      return { ids: new Set(ids), signature: ids.map((id, index) => `${id}:${positions[index]}`).join('\0'),
        elapsedMs: now() - startedAt,
        articleCount: list.length, firstPosition: positions[0] || 0, lastPosition: positions.at(-1) || 0,
        firstRef: reference(ids[0]), lastRef: reference(ids.at(-1)) };
    }
    function recordWindow(scope, current, trigger, newMessages) {
      const audit = scope.audit;
      if (trigger === 'mutation') {
        audit.mutationReadCount++;
        audit.mutationNewMessages += newMessages;
      }
      const previous = audit.window;
      if (audit.lastWindowSignature === current.signature) return;
      audit.lastWindowSignature = current.signature;
      audit.windowSeq++;
      audit.windowChangeCount++;
      const overlap = previous ? Array.from(current.ids).filter(id => previous.ids.has(id)).length : 0;
      const disjoint = previous?.ids.size > 0 && current.ids.size > 0 && overlap === 0;
      const gap = !disjoint ? 0 : current.firstPosition > previous.lastPosition
        ? Math.max(0, current.firstPosition - previous.lastPosition - 1)
        : previous.firstPosition > current.lastPosition ? Math.max(0, previous.firstPosition - current.lastPosition - 1) : 0;
      const fields = { scope: scope.rootId ? 'thread' : 'main', threadRef: reference(scope.rootId),
        ...scope.scrollContext, elapsedMs: now() - startedAt, readTrigger: trigger,
        previousElapsedMs: previous?.elapsedMs, stepElapsedMs: scope.scrollStartedAt == null ? 0 : now() - scope.scrollStartedAt,
        windowSeq: audit.windowSeq, articleCount: current.articleCount,
        firstPosition: current.firstPosition, lastPosition: current.lastPosition,
        firstRef: current.firstRef, lastRef: current.lastRef,
        previousFirstPosition: previous?.firstPosition, previousLastPosition: previous?.lastPosition,
        previousFirstRef: previous?.firstRef, previousLastRef: previous?.lastRef,
        previousArticleCount: previous?.articleCount, windowOverlapCount: overlap, windowGapCount: gap,
        newMessages, messageCount: scope.messages.size, scrollTopAfter: scope.scroller.scrollTop,
        scrollHeight: scope.scroller.scrollHeight, clientHeight: scope.scroller.clientHeight,
        loading: Boolean(scope.conversation.querySelector('[aria-busy="true"], [role="progressbar"]')) };
      record('collector.window', fields);
      if (disjoint) {
        audit.windowGapTotal++;
        // Keep the first transitions as evidence, without flooding the log
        // when a broken list repeatedly oscillates between disjoint windows.
        const firstNumberedGap = gap > 0 && !audit.firstGap?.windowGapCount;
        if (audit.windowGapTotal <= 8 || firstNumberedGap) record('collector.window-gap', fields);
        else audit.omittedGapEvents++;
        if (!audit.firstGap || firstNumberedGap) audit.firstGap = fields;
      }
      if (current.ids.size) audit.window = current;
    }
    function scopeAudit(scope, stage = 'collected', extra = {}) {
      const expected = scope.expectedReplies || scope.knownTotal;
      const positions = Array.from(scope.seenPositions).filter(n => n <= expected).sort((a, b) => a - b);
      const ranges = [];
      let next = 1, unseenPositionCount = 0, rangeCount = 0;
      function addRange(first, last) {
        if (last < first) return;
        unseenPositionCount += last - first + 1;
        rangeCount++;
        if (ranges.length < 32) ranges.push([first, last]);
      }
      if (expected > 0) {
        for (const position of positions) { addRange(next, position - 1); next = position + 1; }
        addRange(next, expected);
      }
      const audit = scope.audit;
      const firstGap = audit.firstGap || {};
      record('collector.scope-audit', { scope: scope.rootId ? 'thread' : 'main', threadRef: reference(scope.rootId), stage,
        expectedReplies: scope.expectedReplies, expectedTotal: expected || 0,
        observedMessageCount: audit.observedIds.size,
        collectedReplies: Array.from(scope.messages.keys()).filter(id => id !== scope.rootId).length,
        unparsedMessageCount: Array.from(audit.observedIds).filter(id => !scope.messages.has(id)).length,
        skippedDateCount: audit.dateIds.size, seenPositionCount: scope.seenPositions.size,
        unseenPositionCount, unseenPositionRanges: ranges, rangesTruncated: rangeCount > ranges.length,
        readErrorCount: audit.readErrorCount, idCollisionTotal: audit.idCollisionTotal,
        idPositionChangedTotal: audit.idPositionChangedTotal,
        observingMutations: audit.observingMutations === true, mutationReadCount: audit.mutationReadCount,
        mutationNewMessages: audit.mutationNewMessages, windowChangeCount: audit.windowChangeCount,
        windowGapTotal: audit.windowGapTotal, omittedGapEvents: audit.omittedGapEvents,
        previousFirstPosition: firstGap.previousFirstPosition, previousLastPosition: firstGap.previousLastPosition,
        firstPosition: firstGap.firstPosition, lastPosition: firstGap.lastPosition, windowGapCount: firstGap.windowGapCount,
        previousFirstRef: firstGap.previousFirstRef, previousLastRef: firstGap.previousLastRef,
        firstRef: firstGap.firstRef, lastRef: firstGap.lastRef, ...extra });
    }
    function collect(scope, trigger = 'poll') {
      const list = articles(scope);
      const beforeCount = scope.messages.size;
      const currentWindow = windowState(scope, list);
      const diagnostic = recorder ? { articleCount: list.length, visibleCount: 0, newMessages: 0, newPositions: 0,
        parsedCount: 0, skippedCount: 0, duplicateCount: 0, idCollisionCount: 0, idPositionChangedCount: 0,
        firstPosition: Number(list[0]?.getAttribute('aria-posinset')) || 0,
        lastPosition: Number(list[list.length - 1]?.getAttribute('aria-posinset')) || 0,
        idExplicitCount: 0, idLabelCount: 0, idTimestampCount: 0, idElementCount: 0, idPositionCount: 0, idAnonymousCount: 0 } : null;
      const windowIds = new Set();
      for (const article of list) {
        const observedId = messageId(article, scope);
        const system = article.querySelector('.yamb-message-system');
        const ownCall = Array.from(article.querySelectorAll('.yamb-message-call')).some(node =>
          node.closest('article.message') === article && !node.closest('.yamb-message-reply'));
        const dateOnly = !article.querySelector('.yamb-message-row') && !ownCall && system &&
          /^(?:сегодня|вчера|today|yesterday|\d{1,2}\s+[а-яa-z]+(?:\s+\d{4})?)$/i.test(renderedText(system));
        if (dateOnly) scope.audit.dateIds.add(observedId);
        else if (observedId !== scope.rootId) scope.audit.observedIds.add(observedId);
        const position = Number(article.getAttribute('aria-posinset'));
        if (diagnostic) {
          if (typeof article.getClientRects === 'function' && visible(article)) diagnostic.visibleCount++;
          if (Number.isInteger(position) && position > 0) {
            if (!scope.seenPositions.has(position)) diagnostic.newPositions++;
            scope.diagnosticMinPosition = Math.min(scope.diagnosticMinPosition ?? position, position);
            scope.diagnosticMaxPosition = Math.max(scope.diagnosticMaxPosition ?? position, position);
          }
          const source = idSource(article);
          const key = { explicit: 'idExplicitCount', label: 'idLabelCount', timestamp: 'idTimestampCount', element: 'idElementCount',
            position: 'idPositionCount', anonymous: 'idAnonymousCount' }[source];
          diagnostic[key]++;
        }
        if (Number.isInteger(position) && position > 0) scope.seenPositions.add(position);
        const total = Number(article.getAttribute('aria-setsize'));
        if (Number.isInteger(total) && total > 0) scope.knownTotal = Math.max(scope.knownTotal, total);
        let message;
        try { message = parseArticle(article, scope); }
        catch (error) { scope.audit.readErrorCount++; throw error; }
        if (!message) { if (diagnostic) diagnostic.skippedCount++; continue; }
        if (Number.isFinite(message.timestampMs)) {
          scope.oldestTimestampMs = Math.min(scope.oldestTimestampMs ?? message.timestampMs, message.timestampMs);
          scope.newestTimestampMs = Math.max(scope.newestTimestampMs ?? message.timestampMs, message.timestampMs);
        }
        const previous = scope.messages.get(message.id);
        if (windowIds.has(message.id)) scope.audit.idCollisionTotal++;
        if (previous && previous.order !== message.order) scope.audit.idPositionChangedTotal++;
        if (diagnostic) {
          diagnostic.parsedCount++;
          if (previous) diagnostic.duplicateCount++;
          else diagnostic.newMessages++;
          if (windowIds.has(message.id)) diagnostic.idCollisionCount++;
          if (previous && previous.order !== message.order) diagnostic.idPositionChangedCount++;
          if (diagnostic.firstRef === undefined) diagnostic.firstRef = reference(message.id);
          diagnostic.lastRef = reference(message.id);
        }
        windowIds.add(message.id);
        scope.messages.set(message.id, previous ? { ...message, sender: message.sender || previous.sender,
          message: !previous.contentUnavailable && (message.contentUnavailable || !message.message) ? previous.message : message.message,
          contentUnavailable: message.contentUnavailable && previous.contentUnavailable,
          type: message.contentUnavailable && !previous.contentUnavailable ? previous.type : message.type,
          date: message.date || previous.date, datetime: message.datetime || previous.datetime,
          timestampMs: message.timestampMs ?? previous.timestampMs,
          attachments: message.attachments.length ? message.attachments : previous.attachments,
          attachmentLinks: message.attachmentLinks.length ? message.attachmentLinks.map((link, index) => ({ ...link,
            url: link.url || previous.attachmentLinks?.[index]?.name === link.name && previous.attachmentLinks[index].url || '' }))
            : previous.attachmentLinks } : message);
      }
      recordWindow(scope, currentWindow, trigger, scope.messages.size - beforeCount);
      if (diagnostic) {
        scope.lastDiagnosticSnapshot = diagnostic;
        if (trigger === 'poll') record('collector.snapshot', diagnosticState(scope));
      }
    }
    function checkChat() {
      if (location.href !== originalURL || !main.content.isConnected || !main.scroller.isConnected) {
        const error = new Error('Во время выгрузки чат изменился. Откройте нужную переписку и повторите выгрузку.');
        error.chatChanged = true;
        error.diagnosticReason = 'chat-changed';
        throw error;
      }
    }
    function withinBudget() {
      if (maxDurationMs > 0 && now() - startedAt >= maxDurationMs) limitReached = true;
      return !limitReached;
    }
    function knownThreadWindow(scope) {
      return articles(scope).some(article => {
        const id = stableIdentity(article, true).id;
        return id && (scope.pausedIds?.has(id) || scope.messages.has(id));
      });
    }
    control.capturePause = () => {
      for (const entry of threads.values()) {
        const scope = entry.scope;
        if (!scope || !scope.content.isConnected || !visible(scope.content)) continue;
        const identity = threadIdentity(scope.content);
        if (identity.id && identity.id !== scope.rootId ||
            ['parent-id-conflict', 'parent-ambiguous'].includes(identity.threadOpenReason)) continue;
        scope.pausedIds = new Set(articles(scope).map(article => stableIdentity(article, true).id).filter(Boolean));
      }
    };
    function checkState(scope) {
      checkChat();
      if (scope.observerError) throw scope.observerError;
      if (control.stopped) { scope.reason = 'user-stopped'; return false; }
      if (!withinBudget()) { scope.reason = 'limit'; return false; }
      if (!scope.content.isConnected || !scope.scroller.isConnected || !visible(scope.content)) {
        const error = new Error('Панель переписки закрылась во время выгрузки.');
        error.diagnosticReason = 'panel-closed';
        throw error;
      }
      if (scope.rootId) {
        const identity = threadIdentity(scope.content);
        // Virtualization can unmount the verified parent during scrolling. Its
        // absence is not evidence that the user switched to another discussion.
        if (identity.id && identity.id !== scope.rootId ||
            ['parent-id-conflict', 'parent-ambiguous'].includes(identity.threadOpenReason) ||
            scope.resumeSeq !== control.resumeSeq && !identity.id && !knownThreadWindow(scope)) {
          const error = new Error('Открыто другое обсуждение.');
          error.diagnosticReason = 'thread-changed';
          throw error;
        }
        scope.resumeSeq = control.resumeSeq;
      }
      return true;
    }
    function progressTracker(scope, direction) {
      const { scroller, legacy } = scope;
      // Each pass needs its own frontier: the downward pass revisits messages
      // already collected on the way up. Oscillating between old windows does
      // not extend this frontier and must not keep the collector alive.
      const visitedIds = new Set();
      let bestPosition = null;
      let bestNumericId = null;
      let bestOffset = scroller.scrollTop;
      let knownScrollRange = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
      let initialized = false;
      const compareIds = (a, b) => a.length - b.length || a.localeCompare(b);
      const farther = (comparison) => direction < 0 ? comparison < 0 : comparison > 0;
      return () => {
        let position = null;
        let numericId = null;
        let hasNewId = false;
        for (const article of articles(scope)) {
          const value = Number(article.getAttribute('aria-posinset'));
          if (Number.isInteger(value) && value > 0 &&
              (position === null || farther(value - position))) position = value;
          const id = messageId(article, scope);
          // Anonymous IDs change on remount; they are not evidence of progress.
          if (id.startsWith('unidentified-')) continue;
          if (!visitedIds.has(id)) hasNewId = true;
          visitedIds.add(id);
          if (/^\d+$/.test(id)) {
            const normalized = id.replace(/^0+(?=\d)/, '');
            if (numericId === null || farther(compareIds(normalized, numericId))) numericId = normalized;
          }
        }
        const positionAdvanced = position !== null &&
          (bestPosition === null || farther(position - bestPosition));
        const idAdvanced = numericId !== null &&
          (bestNumericId === null || farther(compareIds(numericId, bestNumericId)));
        if (positionAdvanced) bestPosition = position;
        if (idAdvanced) bestNumericId = numericId;
        // Positions can restart at 1 when another older history batch is loaded.
        // The directional frontier of stable numeric IDs is independent of that
        // local numbering; observing a new older ID is still real progress.
        let advanced = positionAdvanced || idAdvanced || position === null && numericId === null && hasNewId;
        // A native list can keep the same articles mounted while the viewport
        // advances through them. Only a new directional scroll extreme counts.
        // Layout growth alone must not keep extending the progress deadline.
        // Extend the native range only when history itself has advanced.
        if (advanced) knownScrollRange = Math.max(knownScrollRange, scroller.scrollHeight - scroller.clientHeight);
        const offset = Math.min(scroller.scrollTop, knownScrollRange);
        if (scope.nativeUsed && farther(offset - bestOffset)) {
          bestOffset = offset;
          advanced = true;
        }
        if (!initialized) {
          initialized = true;
          return false;
        }
        return advanced;
      };
    }
    function boundaryEvidence(scope, direction) {
      const list = articles(scope);
      if (!list.length) return '';
      const firstPosition = Number(list[0].getAttribute('aria-posinset'));
      const last = list[list.length - 1];
      const lastPosition = Number(last.getAttribute('aria-posinset'));
      const total = Number(last.getAttribute('aria-setsize'));
      // A physical scroll edge only bounds the loaded fragment. It does not
      // prove that the service has supplied its oldest or newest message.
      if (direction < 0 && scope.rootId && scope.expectedReplies > 0 && firstPosition === 1) return 'first-position';
      if (direction < 0 && !scope.rootId) {
        // A local position of 1 is only the start of the currently loaded batch.
        // Accept a creation marker only as an actual system item, never text
        // from an ordinary message or its quoted reply.
        const first = list[0];
        const system = first.querySelector('.yamb-message-system');
        if (system && !first.querySelector('.yamb-message-row') &&
            /^(?:чат создан|создан чат|групповой чат создан|создан групповой чат|chat created|group chat created)[.!]?$/i.test(renderedText(system))) {
          return 'chat-created-event';
        }
      }
      if (direction > 0 && total > 0 && lastPosition >= total) return 'total-count';
      if (direction > 0 && scope.expectedReplies > 0 && lastPosition >= scope.expectedReplies) return 'thread-reply-count';
      return '';
    }
    function physicalEdge(scope, direction) {
      const scroller = scope.scroller;
      return direction < 0 ? scroller.scrollTop <= 1
        : scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 1;
    }
    async function settle() {
      await sleep(Math.min(delayMs, remainingBudget()));
    }
    async function traverse(scope, direction, recovery = false) {
      await waitWhilePaused();
      scope.passSeq = (scope.passSeq || 0) + 1;
      scope.scrollContext = { passSeq: scope.passSeq, scrollSeq: 0, direction: direction < 0 ? 'up' : 'down', recovery };
      let observer = null;
      if (typeof root.MutationObserver === 'function') {
        observer = new root.MutationObserver(() => {
          // The main list can be intentionally hidden while its thread is open.
          if (scope.observationPaused || control.paused) return;
          if (scope.observerError) return;
          try {
            if (checkState(scope)) {
              collect(scope, 'mutation');
              scope.onMutationProgress?.();
            }
          }
          catch (error) { scope.observerError = error; }
        });
        observer.observe(scope.content, { subtree: true, childList: true, characterData: true, attributes: true,
          attributeFilter: ['aria-posinset', 'aria-setsize', 'aria-labelledby', 'data-message-id', 'data-timestamp', 'class', 'href', 'src'] });
        scope.audit.observingMutations = true;
      }
      try { return await traverseObserved(scope, direction, recovery); }
      finally { observer?.disconnect(); scope.onMutationProgress = null; }
    }
    async function traverseObserved(scope, direction, recovery = false) {
      const { scroller, legacy, conversation } = scope;
      const loggedDirection = direction < 0 ? 'up' : 'down';
      let stable = 0;
      let edgeRetries = 0;
      let lastEdgeRetryAt = 0;
      const stopField = direction < 0 ? 'upwardStopReason' : 'downwardStopReason';
      const evidenceField = direction < 0 ? 'startEvidence' : 'endEvidence';
      const edgeField = direction < 0 ? 'stoppedAtTopEdge' : 'stoppedAtBottomEdge';
      scope[stopField] = 'running';
      record('collector.pass-start', { ...diagnosticState(scope), direction: loggedDirection });
      const endPass = result => {
        record('collector.pass-end', { ...diagnosticState(scope), direction: loggedDirection,
          reason: scope[stopField], evidence: scope[evidenceField] || 'none', atEdge: physicalEdge(scope, direction),
          stableCount: stable, startReached: scope.startReached || direction < 0 && result,
          endReached: scope.endReached || direction > 0 && result });
        return result;
      };
      const progressed = progressTracker(scope, direction);
      progressed();
      let lastProgressAt = now();
      let mutationAdvanced = false;
      scope.onMutationProgress = () => {
        if (progressed()) { mutationAdvanced = true; lastProgressAt = now(); edgeRetries = 0; }
      };
      const observedProgress = () => {
        const advanced = progressed() || mutationAdvanced;
        mutationAdvanced = false;
        return advanced;
      };
      async function probeTopEdge() {
        const count = ++edgeRetries;
        lastEdgeRetryAt = now();
        record('collector.edge-probe', { ...diagnosticState(scope), phase: 'before', direction: 'up', count, outcome: 'started' });
        const finishProbe = (advanced, outcome) => {
          record('collector.edge-probe', { ...diagnosticState(scope), phase: 'after', direction: 'up', count,
            outcome, algorithmProgress: advanced, reason: scope.reason });
          return advanced;
        };
        const distance = Math.max(40, Math.min(120, Math.floor(scroller.clientHeight * 0.2)));
        for (const step of [distance, -distance]) {
          if (!checkState(scope)) return finishProbe(false, control.stopped ? 'stopped' : 'partial');
          const before = scroller.scrollTop;
          const windowBefore = articles(scope).map(article => messageId(article, scope)).join('\0');
          scope.scrollContext = { ...scope.scrollContext, scrollSeq: (scope.scrollContext.scrollSeq || 0) + 1,
            method: legacy ? 'wheel' : 'native', delta: step, scrollTopBefore: before };
          scope.scrollStartedAt = now();
          if (legacy) {
            scope.scrollAttempts.wheel++;
            scroller.dispatchEvent(new WheelEvent('wheel', { deltaY: step, deltaMode: 0, bubbles: true, cancelable: true }));
          } else {
            scope.scrollAttempts.native++;
            scroller.scrollBy({ top: step, behavior: 'instant' });
          }
          await settle();
          if (!checkState(scope)) return finishProbe(false, control.stopped ? 'stopped' : 'partial');
          collect(scope);
          // Native lists can retain the legacy CSS class. A wheel event has no
          // browser default when dispatched by script, so physically leave and
          // re-enter the edge if the virtual window did not change at all.
          if (legacy && scroller.scrollTop === before &&
              articles(scope).map(article => messageId(article, scope)).join('\0') === windowBefore &&
              scroller.scrollHeight > scroller.clientHeight + 1 &&
              typeof scroller.scrollBy === 'function') {
            scope.nativeUsed = true;
            scope.scrollAttempts.native++;
            scope.scrollContext = { ...scope.scrollContext, scrollSeq: scope.scrollContext.scrollSeq + 1,
              method: 'fallback', scrollTopBefore: scroller.scrollTop };
            scope.scrollStartedAt = now();
            scroller.scrollBy({ top: step, behavior: 'instant' });
            await settle();
            if (!checkState(scope)) return finishProbe(false, control.stopped ? 'stopped' : 'partial');
            collect(scope);
          }
        }
        // The deliberate step away from the edge is not history progress.
        // Check only after returning, against the frontier from before probing.
        const advanced = observedProgress();
        return finishProbe(advanced, advanced ? 'success' : 'empty');
      }
      while (true) {
        await waitWhilePaused();
        if (!checkState(scope)) break;
        collect(scope);
        if (scope === main) {
          // Thread work consumes the global budget, but is not a stalled main pass.
          const pausedAt = now();
          scope.observationPaused = true;
          try { await collectVisibleThreads(); }
          finally { scope.observationPaused = false; lastProgressAt += now() - pausedAt; }
          await waitWhilePaused();
          if (threadNavigationFailed || !checkState(scope)) {
            scope[stopField] = control.stopped ? 'user-stopped' : limitReached ? 'limit' : 'thread-close-failed';
            return endPass(false);
          }
        }
        let advanced = observedProgress();
        if (advanced) { lastProgressAt = now(); edgeRetries = 0; }
        const delta = direction * (recovery
          ? Math.max(40, Math.min(120, Math.floor(scroller.clientHeight * 0.2)))
          : Math.max(100, Math.floor(scroller.clientHeight * 0.65)));
        let scrollTopBefore = scroller.scrollTop;
        let messagesBefore = scope.messages.size;
        scope.scrollContext = { ...scope.scrollContext, scrollSeq: (scope.scrollContext.scrollSeq || 0) + 1,
          method: legacy ? 'wheel' : 'native', delta, scrollTopBefore };
        scope.scrollStartedAt = now();
        record('collector.scroll', { ...diagnosticState(scope), phase: 'before', direction: loggedDirection,
          method: legacy ? 'wheel' : 'native', scrollTopBefore, delta });
        if (legacy) {
          scope.scrollAttempts.wheel++;
          scroller.dispatchEvent(new WheelEvent('wheel', { deltaY: delta, deltaMode: 0, bubbles: true, cancelable: true }));
        } else {
          scope.scrollAttempts.native++;
          scroller.scrollBy({ top: delta, behavior: 'instant' });
        }
        await settle();
        if (!checkState(scope)) {
          record('collector.scroll', { ...diagnosticState(scope), phase: 'after', direction: loggedDirection,
            method: legacy ? 'wheel' : 'native', scrollTopBefore, scrollTopAfter: scroller.scrollTop,
            reason: scope.reason, algorithmProgress: false, newMessages: 0 });
          break;
        }
        collect(scope);
        let stepAdvanced = observedProgress();
        record('collector.scroll', { ...diagnosticState(scope), phase: 'after', direction: loggedDirection,
          method: legacy ? 'wheel' : 'native', scrollTopBefore, scrollTopAfter: scroller.scrollTop,
          algorithmProgress: stepAdvanced, newMessages: scope.messages.size - messagesBefore });
        // Some Telemost versions retain InfiniteList's class names but use
        // native scrolling. An unhandled synthetic wheel has no default scroll.
        // Keep each rendered window before trying the second mechanism.
        if (legacy && !stepAdvanced && scroller.scrollHeight > scroller.clientHeight + 1 &&
            typeof scroller.scrollBy === 'function') {
          scope.nativeUsed = true;
          scope.scrollAttempts.native++;
          scrollTopBefore = scroller.scrollTop;
          messagesBefore = scope.messages.size;
          scope.scrollContext = { ...scope.scrollContext, scrollSeq: scope.scrollContext.scrollSeq + 1,
            method: 'fallback', delta, scrollTopBefore };
          scope.scrollStartedAt = now();
          record('collector.scroll', { ...diagnosticState(scope), phase: 'before', direction: loggedDirection,
            method: 'fallback', scrollTopBefore, delta });
          scroller.scrollBy({ top: delta, behavior: 'instant' });
          await settle();
          if (!checkState(scope)) {
            record('collector.scroll', { ...diagnosticState(scope), phase: 'after', direction: loggedDirection,
              method: 'fallback', scrollTopBefore, scrollTopAfter: scroller.scrollTop,
              reason: scope.reason, algorithmProgress: false, newMessages: 0 });
            break;
          }
          collect(scope);
          stepAdvanced = observedProgress();
          record('collector.scroll', { ...diagnosticState(scope), phase: 'after', direction: loggedDirection,
            method: 'fallback', scrollTopBefore, scrollTopAfter: scroller.scrollTop,
            algorithmProgress: stepAdvanced, newMessages: scope.messages.size - messagesBefore });
        }
        advanced = stepAdvanced || advanced;
        if (advanced) { lastProgressAt = now(); edgeRetries = 0; }
        let loading = Boolean(conversation.querySelector('[aria-busy="true"], [role="progressbar"]'));
        scope[edgeField] = physicalEdge(scope, direction);
        let evidence = boundaryEvidence(scope, direction);
        if (scope === main && direction < 0 && !advanced && !loading && !evidence && scope[edgeField] &&
            edgeRetries < 3 && now() - lastProgressAt >= edgeRetryDelayMs &&
            now() - lastEdgeRetryAt >= edgeRetryDelayMs && now() - lastProgressAt < noProgressTimeoutMs) {
          advanced = await probeTopEdge();
          if (!checkState(scope)) break;
          if (advanced) { lastProgressAt = now(); edgeRetries = 0; }
          loading = Boolean(conversation.querySelector('[aria-busy="true"], [role="progressbar"]'));
          scope[edgeField] = physicalEdge(scope, direction);
          evidence = boundaryEvidence(scope, direction);
        }
        stable = !advanced && !loading && evidence ? stable + 1 : 0;
        record('collector.scroll', { ...diagnosticState(scope), phase: 'finish', direction: loggedDirection,
          algorithmProgress: advanced, loading, stableCount: stable, evidence: evidence || 'none',
          atEdge: scope[edgeField], noProgressMs: now() - lastProgressAt });
        if (stable >= stableRounds) {
          scope[evidenceField] = evidence;
          scope[stopField] = direction < 0 ? 'confirmed-start' : 'confirmed-end';
          if (scope === main) await collectVisibleThreads();
          return endPass(true);
        }
        if (now() - lastProgressAt >= noProgressTimeoutMs) {
          scope.reason = 'no-progress';
          scope[stopField] = 'no-progress';
          return endPass(false);
        }
      }
      scope[stopField] = control.stopped ? 'user-stopped' : limitReached ? 'limit' : scope.reason;
      return endPass(false);
    }
    function coverageFor(scope) {
      const expected = scope.knownTotal || scope.expectedReplies || Array.from(scope.seenPositions).reduce((highest, position) => Math.max(highest, position), 0);
      const positionGapCount = scope.seenPositions.size > 0 && expected > 0
        ? Math.max(0, expected - Array.from(scope.seenPositions).filter(n => n <= expected).length) : 0;
      const positionGaps = positionGapCount > 0;
      const unstableIds = Array.from(scope.messages.keys()).some(id => id.startsWith('unidentified-'));
      return { startReached: scope.startReached, endReached: scope.endReached,
        complete: scope.startReached && scope.endReached && !['limit', 'user-stopped'].includes(scope.reason) && !positionGaps && !unstableIds,
        reason: scope.reason, hasGaps: false, positionGaps, positionGapCount, unstableIds,
        startEvidence: scope.startEvidence, endEvidence: scope.endEvidence,
        upwardStopReason: scope.upwardStopReason, downwardStopReason: scope.downwardStopReason,
        firstPosition: scope.seenPositions.size ? Array.from(scope.seenPositions).reduce((a, b) => Math.min(a, b), Infinity) : null,
        lastPosition: Array.from(scope.seenPositions).reduce((a, b) => Math.max(a, b), 0) || null,
        expectedTotal: scope.knownTotal || scope.expectedReplies || null,
        stoppedAtTopEdge: scope.stoppedAtTopEdge ?? null, stoppedAtBottomEdge: scope.stoppedAtBottomEdge ?? null,
        scrollAttempts: { ...scope.scrollAttempts } };
    }
    async function recoverThread(scope) {
      await waitWhilePaused();
      const replyCount = () => Array.from(scope.messages.keys()).filter(id => id !== scope.rootId).length;
      if (!scope.expectedReplies || replyCount() >= scope.expectedReplies) return;
      let pass = 0;
      // Reaching the two edges does not mean every intermediate window was
      // collected. Revisit a shortfall with overlapping, smaller scroll steps.
      // Stop after a round without new replies, or at most two recovery rounds.
      for (let round = 0; round < 2 && replyCount() < scope.expectedReplies; round++) {
        const beforeRound = replyCount();
        for (const direction of [-1, 1]) {
          await waitWhilePaused();
          if (replyCount() >= scope.expectedReplies || !checkState(scope)) return;
          const before = replyCount();
          const fields = { scope: 'thread', threadRef: reference(scope.rootId), count: ++pass,
            direction: direction < 0 ? 'up' : 'down', expectedReplies: scope.expectedReplies };
          record('collector.thread-recovery', { ...fields, phase: 'before', collectedReplies: before,
            newMessages: 0, outcome: 'started', reason: 'missing-replies' });
          try {
            const reached = await traverse(scope, direction, true);
            if (direction < 0) scope.startReached = scope.startReached || reached;
            else scope.endReached = scope.endReached || reached;
          } finally {
            const collectedReplies = replyCount();
            record('collector.thread-recovery', { ...fields, phase: 'after', collectedReplies,
              newMessages: collectedReplies - before,
              outcome: control.stopped ? 'stopped' : limitReached ? 'partial'
                : collectedReplies >= scope.expectedReplies ? 'success' : 'partial',
              reason: control.stopped ? 'user-stopped' : limitReached ? 'limit'
                : collectedReplies >= scope.expectedReplies ? 'completed'
                : collectedReplies === before ? 'no-progress' : 'missing-replies' });
          }
        }
        if (replyCount() === beforeRound) return;
      }
    }
    function sortedMessages(scope) {
      const messages = Array.from(scope.messages.values());
      // Select one ordering scheme for the entire scope. Comparing ID for one
      // pair and local position for another can produce a non-transitive order.
      if (messages.every(message => /^\d+$/.test(message.id))) {
        return messages.sort((a, b) => {
          const left = a.id.replace(/^0+(?=\d)/, ''), right = b.id.replace(/^0+(?=\d)/, '');
          return left.length - right.length || left.localeCompare(right);
        });
      }
      if (messages.every(message => Number.isFinite(message.timestampMs))) {
        return messages.sort((a, b) => a.timestampMs - b.timestampMs);
      }
      if (messages.every(message => message.order > 0)) return messages.sort((a, b) => a.order - b.order);
      return messages;
    }
    function threadContents() { return allContents().filter(isThread); }
    async function closeThread(content, cleanup = false, rootId = '') {
      await waitWhilePaused();
      checkChat();
      // Do not close a different thread that the user opened during a pause.
      if (control.wasPaused && rootId) {
        const identity = threadIdentity(content);
        const scope = threads.get(rootId)?.scope;
        if (identity.id ? identity.id !== rootId :
            ['parent-id-conflict', 'parent-ambiguous'].includes(identity.threadOpenReason) ||
            !scope || scope.content !== content || !knownThreadWindow(scope)) return false;
      }
      record('collector.thread-close', { ...navigationState(rootId), phase: 'before' });
      const closed = (result, reason) => {
        record('collector.thread-close', { ...navigationState(rootId), phase: 'after',
          outcome: result ? 'success' : control.stopped ? 'stopped' : 'error', reason, stopped: control.stopped });
        return result;
      };
      if (control.stopped && !cleanup) return closed(false, 'user-stopped');
      const panel = panelFor(content);
      const button = Array.from(panel.querySelectorAll('[data-test-tag="thread-header-close"], [data-test-tag="chat-header-back"]')).find(visible);
      if (!button) return closed(false, 'unavailable');
      button.click();
      if (control.stopped) return closed(true, 'user-stopped');
      const until = now() + threadOpenTimeoutMs;
      while (now() < until && !control.stopped) {
        await waitWhilePaused();
        if (control.stopped) break;
        checkChat();
        if (!content.isConnected || !visible(content) || !isThread(content)) return closed(true, 'completed');
        if (!withinBudget()) return closed(false, 'limit');
        await sleep(Math.min(delayMs, remainingBudget()));
      }
      return closed(control.stopped, control.stopped ? 'user-stopped' : 'timeout');
    }
    async function collectVisibleThreads() {
      // Opening a panel can remount the main virtual window. Resolve the next
      // button from the current DOM after every discussion, never a stale snapshot.
      while (!control.stopped) {
        await waitWhilePaused();
        if (control.stopped) break;
        checkChat();
        collect(main);
        const current = articles(main);
        for (const article of current) {
          const previous = threads.get(messageId(article, main));
          const badge = article.querySelector('.yamb-message-thread-data .yamb-message-footer-badge');
          const count = badge && /^(\d+)\s+(?:ответ|repl)/i.exec(renderedText(badge));
          if (previous && count) previous.expectedReplies = Math.max(previous.expectedReplies, Number(count[1]));
        }
        const article = current.find(node => !threads.has(messageId(node, main)) &&
          node.querySelector('.yamb-message-thread-data .yamb-message-footer-badge'));
        if (!article) break;
        const badge = article.querySelector('.yamb-message-thread-data .yamb-message-footer-badge');
        if (!badge) continue;
        const rootId = messageId(article, main);
        const count = /^(\d+)\s+(?:ответ|repl)/i.exec(renderedText(badge));
        const expectedReplies = count ? Number(count[1]) : 0;
        const entry = { rootId, expectedReplies, collectedReplies: 0,
          openDiagnostics: { threadOpenReason: 'panel-missing', threadPanelCount: 0, parentCandidateCount: 0, parentIdSource: 'none',
            parentSearchAttempts: 0, parentSearchReason: 'not-needed' },
          coverage: { startReached: false, endReached: false, complete: false, reason: 'not-opened' } };
        threads.set(rootId, entry);
        record('collector.thread-open', { ...navigationState(rootId), phase: 'start', expectedReplies });
        if (rootId.startsWith('unidentified-')) { entry.coverage.reason = 'not-opened'; continue; }
        if (!withinBudget() || threadNavigationFailed) { entry.coverage.reason = limitReached ? 'limit' : 'not-opened'; continue; }
        let opened = null;
        try {
          if (!badge.isConnected) {
            entry.coverage.reason = 'open-failed';
            entry.openDiagnostics.threadOpenReason = 'unavailable';
            record('collector.thread-open', { ...navigationState(rootId), ...entry.openDiagnostics,
              phase: 'after', reason: 'unavailable', outcome: 'error' });
            continue;
          }
          record('collector.thread-open', { ...navigationState(rootId), phase: 'before', expectedReplies });
          const panelsBeforeClick = new Set(threadContents());
          badge.click();
          const until = now() + threadOpenTimeoutMs;
          let parentSearch = null;
          let searchBlocked = false;
          const parentDeadline = () => parentSearch ? parentSearch.deadline : until;
          const blockSearch = reason => {
            searchBlocked = true;
            entry.openDiagnostics.parentSearchReason = reason;
          };
          const waitForParent = () => sleep(Math.max(0, Math.min(delayMs, parentDeadline() - now(),
            remainingBudget())));
          function searchPanelUnchanged() {
            checkChat();
            if (control.stopped) { blockSearch('user-stopped'); return false; }
            if (!withinBudget()) { blockSearch('limit'); return false; }
            if (now() >= parentDeadline()) { blockSearch('timeout'); return false; }
            const panels = threadContents();
            if (panels.length !== 1 || panels[0] !== parentSearch.scope.content ||
                !parentSearch.scope.scroller.isConnected ||
                createScope(panels[0], rootId, expectedReplies).scroller !== parentSearch.scope.scroller) {
              blockSearch('panel-changed');
              return false;
            }
            const identity = threadIdentity(panels[0]);
            if (identity.id === rootId) return false;
            if (identity.threadOpenReason !== 'parent-missing') {
              blockSearch('identity-rejected');
              return false;
            }
            return true;
          }
          async function searchForParent() {
            if (!searchPanelUnchanged()) return;
            const scope = parentSearch.scope;
            const step = -Math.max(100, Math.floor(scope.scroller.clientHeight * 0.65));
            entry.openDiagnostics.parentSearchAttempts++;
            entry.openDiagnostics.parentSearchReason = 'searching';
            if (scope.legacy) {
              scope.scroller.dispatchEvent(new WheelEvent('wheel', { deltaY: step, deltaMode: 0, bubbles: true, cancelable: true }));
            } else scope.scroller.scrollBy({ top: step, behavior: 'instant' });
            await waitForParent();
            if (!searchPanelUnchanged()) return;
            let advanced = parentSearch.progressed();
            // Some native lists retain the legacy class and ignore synthetic
            // wheel events. Move only the same newly opened panel in that case.
            if (!advanced && scope.legacy && scope.scroller.scrollHeight > scope.scroller.clientHeight + 1 &&
                typeof scope.scroller.scrollBy === 'function') {
              scope.nativeUsed = true;
              scope.scroller.scrollBy({ top: step, behavior: 'instant' });
              await waitForParent();
              if (!searchPanelUnchanged()) return;
              advanced = parentSearch.progressed();
            }
            parentSearch.stableAttempts = advanced ? 0 : parentSearch.stableAttempts + 1;
            if (parentSearch.stableAttempts >= 3) blockSearch('no-progress');
          }
          while (now() < parentDeadline() && !control.stopped && withinBudget()) {
            await waitWhilePaused();
            if (control.stopped || !withinBudget()) break;
            checkChat();
            const panels = threadContents();
            const identities = panels.map(content => ({ content, identity: threadIdentity(content) }));
            const matching = identities.filter(({ identity }) => identity.id === rootId);
            const observed = matching[0]?.identity || identities[0]?.identity;
            entry.openDiagnostics = { ...entry.openDiagnostics, threadPanelCount: panels.length,
              parentCandidateCount: observed?.parentCandidateCount || 0, parentIdSource: observed?.parentIdSource || 'none',
              observedParentRef: reference(observed?.id),
              threadOpenReason: matching.length > 1 ? 'panel-ambiguous' : matching.length === 1 ? 'matched'
                : observed?.id ? 'parent-mismatch' : observed?.threadOpenReason || 'panel-missing' };
            if (matching.length === 1) {
              opened = matching[0].content;
              entry.openDiagnostics.parentSearchReason = entry.openDiagnostics.parentSearchAttempts ? 'matched' : 'not-needed';
              break;
            }
            // A delayed history batch may advance the frontier after scrolling
            // was paused. Resume only that pause, with the original deadline.
            if (searchBlocked && entry.openDiagnostics.parentSearchReason === 'no-progress' &&
                searchPanelUnchanged() && parentSearch.progressed()) {
              searchBlocked = false;
              parentSearch.stableAttempts = 0;
              entry.openDiagnostics.parentSearchReason = 'searching';
            }
            if (!searchBlocked) {
              if (parentSearch && (panels.length !== 1 || panels[0] !== parentSearch.scope.content)) blockSearch('panel-changed');
              else if (panels.length > 1 || observed && observed.threadOpenReason !== 'parent-missing') blockSearch('identity-rejected');
              else if (panels.length === 1 && !panelsBeforeClick.has(panels[0])) {
                if (!parentSearch) {
                  const scope = createScope(panels[0], rootId, expectedReplies);
                  if (!scope.scroller || scope.scroller === main.scroller || scope.conversation === main.conversation ||
                      typeof scope.scroller.contains === 'function' && !scope.scroller.contains(panels[0])) blockSearch('unavailable');
                  else {
                    parentSearch = { scope, progressed: progressTracker(scope, -1), stableAttempts: 0,
                      deadline: now() + threadParentSearchTimeoutMs };
                    parentSearch.progressed();
                  }
                }
                if (!searchBlocked) { await searchForParent(); continue; }
              }
            }
            await waitForParent();
          }
          if (!opened) {
            entry.coverage.reason = control.stopped ? 'user-stopped' : limitReached ? 'limit' : 'open-failed';
            if (control.stopped) entry.openDiagnostics.parentSearchReason = 'user-stopped';
            else if (limitReached) entry.openDiagnostics.parentSearchReason = 'limit';
            else if (entry.openDiagnostics.parentSearchReason === 'searching') entry.openDiagnostics.parentSearchReason = 'timeout';
            record('collector.thread-open', { ...navigationState(rootId), ...entry.openDiagnostics, phase: 'after',
              reason: control.stopped ? 'user-stopped' : limitReached ? 'limit' : 'timeout',
              outcome: control.stopped ? 'stopped' : 'error' });
            continue;
          }
          record('collector.thread-open', { ...navigationState(rootId), ...entry.openDiagnostics,
            phase: 'after', expectedReplies, outcome: 'success' });
          const scope = createScope(opened, rootId, expectedReplies);
          scope.resumeSeq = control.resumeSeq;
          entry.scope = scope;
          if (!scope.scroller) {
            entry.coverage.reason = 'no-scroller';
            record('collector.error', { scope: 'thread', threadRef: reference(rootId), reason: 'no-scroller' });
            continue;
          }
          record('collector.container', diagnosticState(scope));
          await waitWhilePaused();
          if (checkState(scope)) collect(scope);
          scope.startReached = await traverse(scope, -1);
          if (!control.stopped && !limitReached) scope.endReached = await traverse(scope, 1);
          if (!control.stopped && !limitReached) await recoverThread(scope);
          await waitWhilePaused();
          if (checkState(scope)) collect(scope);
          entry.coverage = coverageFor(scope);
        } catch (error) {
          if (error.chatChanged) throw error;
          record('collector.error', { scope: 'thread', threadRef: reference(rootId),
            reason: error.diagnosticReason || 'thread-error', errorCode: errorCode(error) });
          entry.coverage = { ...entry.coverage, complete: false, reason: 'thread-error' };
        } finally {
          if (entry.scope) {
            entry.collectedReplies = Array.from(entry.scope.messages.keys()).filter(id => id !== rootId).length;
            scopeAudit(entry.scope);
          }
          // Close even after the global deadline; never leave a hidden main list scrolling.
          // On Stop, only close the discussion opened by this iteration. A
          // different panel may have been opened by the user in the meantime.
          const pending = threadContents().filter(content => {
            if (!control.stopped) return true;
            return threadIdentity(content).id === rootId;
          });
          for (const content of pending) {
            if (!await closeThread(content, true, rootId) && !control.stopped) {
              threadNavigationFailed = true;
              main.reason = 'thread-close-failed';
              entry.coverage.complete = false;
              entry.coverage.reason = 'close-failed';
              break;
            }
          }
        }
      }
    }
    try {
      await waitWhilePaused();
      checkChat();
      for (const content of threadContents()) {
        if (control.stopped) break;
        if (!await closeThread(content) && !control.stopped) return finish(
          { detected: true, error: 'Не удалось закрыть открытый тред. Закройте его и повторите выгрузку.' },
          { outcome: 'error', reason: 'thread-close-failed', elapsedMs: now() - startedAt });
      }
      if (!control.paused) collect(main);
      main.startReached = await traverse(main, -1);
      if (!control.stopped && !limitReached && !threadNavigationFailed) main.endReached = await traverse(main, 1);
      await waitWhilePaused();
      checkChat();
      if (!control.paused) collect(main);
      let coverage = coverageFor(main);
      const result = sortedMessages(main);
      const byId = new Map(result.map(message => [message.id, message]));
      for (const entry of threads.values()) {
        if (entry.collectedReplies < entry.expectedReplies) {
          entry.coverage.complete = false;
          if (entry.coverage.reason === 'stable-boundaries') entry.coverage.reason = 'missing-replies';
        }
        entry.coverage = classifyCoverage(entry.coverage, { scope: 'thread',
          expectedReplies: entry.expectedReplies, collectedReplies: entry.collectedReplies });
        record('collector.thread-finish', { scope: 'thread', threadRef: reference(entry.rootId), ...entry.openDiagnostics,
          expectedReplies: entry.expectedReplies, collectedReplies: entry.collectedReplies,
          complete: entry.coverage.complete, startReached: entry.coverage.startReached,
          endReached: entry.coverage.endReached, reason: entry.coverage.reason, coverageStatus: entry.coverage.status,
          statusReason: entry.coverage.statusReason, positionGaps: entry.coverage.positionGaps,
          positionGapCount: entry.coverage.positionGapCount,
          outcome: entry.coverage.statusReason === 'user-stopped' || entry.coverage.reason === 'user-stopped'
            ? 'stopped' : entry.coverage.complete ? 'success' : entry.coverage.status });
        if (!entry.scope) continue;
        for (const message of sortedMessages(entry.scope)) {
          if (message.id === entry.rootId) continue;
          if (byId.has(message.id)) {
            const previous = byId.get(message.id);
            if (!previous.threadRootId) previous.threadRootId = message.threadRootId;
          } else { result.push(message); byId.set(message.id, message); }
        }
      }
      const combinedReplies = new Map();
      for (const message of result) if (message.threadRootId) {
        combinedReplies.set(message.threadRootId, (combinedReplies.get(message.threadRootId) || 0) + 1);
      }
      for (const entry of threads.values()) if (entry.scope) {
        scopeAudit(entry.scope, 'combined', { exportedReplies: combinedReplies.get(entry.rootId) || 0 });
      }
      scopeAudit(main);
      result.forEach((message, index) => { message.order = index; });
      const contentUnavailableCount = result.filter(message => message.contentUnavailable === true).length;
      if (contentUnavailableCount) {
        warnings.add(`Не удалось прочитать содержимое сообщений: ${contentUnavailableCount}. Эти записи отмечены в выгрузке.`);
      }
      if (result.some(message => message.attachmentLinks.some(link => !link.url))) {
        warnings.add('Для части вложений интерфейс не предоставил ссылку; сохранено название.');
      }
      const threadsSummary = { discovered: threads.size,
        collected: Array.from(threads.values()).filter(entry => entry.collectedReplies > 0).length,
        complete: Array.from(threads.values()).every(entry => entry.coverage.complete),
        status: Array.from(threads.values()).some(entry => entry.coverage.status === 'partial') ? 'partial'
          : Array.from(threads.values()).some(entry => entry.coverage.status === 'unverified') ? 'unverified' : 'complete' };
      coverage.complete = coverage.complete && threadsSummary.complete && !control.stopped && !limitReached && !threadNavigationFailed;
      if (control.stopped) coverage.reason = 'user-stopped';
      else if (limitReached) coverage.reason = 'limit';
      else if (threadsSummary.status === 'partial' && coverage.reason === 'stable-boundaries') coverage.reason = 'threads-incomplete';
      coverage = classifyCoverage(coverage, { threadsSummary, threads: Array.from(threads.values()) });
      if (coverage.status === 'partial') warnings.add(coverage.reason === 'user-stopped'
        ? 'Выгрузка остановлена пользователем. Сохранена только собранная часть истории.'
        : coverage.reason === 'limit'
        ? 'Достигнут общий предел времени выгрузки. Сохранена только собранная часть истории.'
        : 'Выгрузка завершилась с ограничениями. Сохранена собранная часть истории.');
      if (hasThreadCollectionIssues({ threadsSummary, threads: Array.from(threads.values()) })) {
        warnings.add('Часть ответов в тредах не удалось загрузить. Подробности — в сведениях о тредах.');
      }
      return finish({ detected: true, chatTitle, messages: result, coverage,
        metadata: { chatTitle, exportedAt: new Date().toISOString(), timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone, coverage, warnings: Array.from(warnings),
          contentUnavailableCount, threadsSummary, threads: Array.from(threads.values(), ({ scope, ...entry }) => entry) } },
      { ...diagnosticState(main), outcome: control.stopped ? 'stopped' : coverage.complete ? 'success' : coverage.status,
        reason: coverage.reason, startReached: coverage.startReached, endReached: coverage.endReached,
        statusReason: coverage.statusReason, positionGaps: coverage.positionGaps, positionGapCount: coverage.positionGapCount,
        complete: coverage.complete, coverageStatus: coverage.status, contentUnavailableCount, totalMessages: result.length, threadCount: threads.size });
    } catch (error) {
      record('collector.error', { reason: error.diagnosticReason || 'unavailable', errorCode: errorCode(error),
        elapsedMs: now() - startedAt });
      return finish({ error: error.message, detected: true }, { outcome: 'error',
        reason: error.diagnosticReason || 'unavailable', elapsedMs: now() - startedAt });
    } finally {
      control.wake?.();
      control.resumeWake?.();
      if (controls.active === control) controls.active = null;
      if (runId) remember(controls.finished, runId);
      root.__chatDownloaderRunning = false;
    }
  }

  root.ChatExtractor = { run, cancel, setPaused };
})(globalThis);
