(function (root) {
  'use strict';

  // Keep cancellation tokens outside the injected function so a second inspect
  // injection cannot detach an already running collector from its Stop button.
  const controls = root.__chatDownloaderControls || (root.__chatDownloaderControls = {
    active: null, pending: new Set(), finished: new Set()
  });
  function remember(set, id) {
    set.add(id);
    if (set.size > 100) set.delete(set.values().next().value);
  }
  function cancel(runId) {
    if (typeof runId !== 'string' || !runId || controls.finished.has(runId)) return false;
    if (controls.active?.id === runId) {
      controls.active.stopped = true;
      controls.active.record?.('collector.cancel', { stopped: true, reason: 'user-stopped' });
      controls.active.wake?.();
    } else remember(controls.pending, runId);
    return true;
  }

  function classifyCoverage(coverage, metadata = {}) {
    try {
      const classified = root.ChatExport?.classifyCoverage(coverage, metadata);
      if (classified && ['complete', 'partial', 'unverified'].includes(classified.status) &&
          classified.complete === (classified.status === 'complete')) return classified;
    } catch {}
    // A missing optional helper must not discard already collected messages or
    // turn an unconfirmed boundary into a claim that messages are missing.
    const interrupted = new Set(['limit', 'user-stopped', 'gaps', 'missing-replies',
      'not-opened', 'open-failed', 'thread-error', 'close-failed', 'thread-close-failed', 'no-scroller']);
    const threadEntries = Array.isArray(metadata.threads) ? metadata.threads : [];
    const partial = Boolean(coverage.hasGaps || coverage.unstableIds ||
      [coverage.reason, coverage.upwardStopReason, coverage.downwardStopReason].some(reason => interrupted.has(reason)) ||
      metadata.scope === 'thread' && metadata.expectedReplies > metadata.collectedReplies ||
      threadEntries.some(entry => entry.coverage?.status === 'partial'));
    const complete = !partial && coverage.complete === true && coverage.startReached === true &&
      coverage.endReached === true && metadata.threadsSummary?.complete !== false &&
      threadEntries.every(entry => entry.coverage?.complete === true);
    return { ...coverage, status: partial ? 'partial' : complete ? 'complete' : 'unverified', complete };
  }

  async function run(options = {}) {
    let recorder = null;
    try {
      if (options.mode !== 'inspect') recorder = root.ChatDiagnostics?.createRecorder({
        runId: options.runId, version: options.version, source: 'collector'
      }) || null;
    } catch {}
    const record = (event, fields) => { try { recorder?.record(event, fields); } catch {} };
    const reference = value => { try { return value ? root.ChatDiagnostics?.ref(value) : undefined; } catch { return undefined; } };
    const errorCode = error => { try { return root.ChatDiagnostics?.errorCode(error); } catch { return undefined; } };
    async function finish(result, fields) {
      record('collector.finish', fields);
      try { await recorder?.flush(); } catch {}
      try { if (recorder) result.diagnostics = recorder.snapshot(); } catch {}
      return result;
    }
    const warnings = new Set();
    const trim = value => (value || '').trim();
    const visible = node => node && node.getClientRects().length > 0 &&
      getComputedStyle(node).visibility !== 'hidden';
    const panelFor = content => content.closest('.yamb-chat') || content.closest('.yamb-conversation') || content.parentElement;
    const isThread = content => Boolean(panelFor(content).querySelector('.yamb-thread-header-controls-container'));
    const allContents = () => Array.from(document.querySelectorAll('.yamb-conversation__content')).filter(visible);
    const roots = Array.from(document.querySelectorAll('.yamb-conversation__content')).filter(content =>
      !isThread(content) && (visible(content) ||
        panelFor(content).classList?.contains('yamb-chat_thread-openned') && allContents().some(isThread)));
    if (!roots.length) return finish({ detected: false, error: 'Откройте основную переписку и дождитесь загрузки сообщений.' },
      { outcome: 'error', reason: 'no-root' });
    if (roots.length > 1) return finish({ detected: false, error: 'Открыто несколько переписок. Оставьте один основной чат и повторите выгрузку.' },
      { outcome: 'error', reason: 'ambiguous' });
    function createScope(content, rootId = '', expectedReplies = 0) {
      const conversation = content.closest('.yamb-conversation') || content.parentElement;
      const legacy = conversation.querySelector('.ui-InfiniteList-ScrollContainer[data-scroll-container="true"]') ||
        conversation.querySelector('.ui-InfiniteList[data-scroll-container="true"]');
      let scroller = legacy;
      if (!scroller) {
        for (let node = content; node && node !== document.body; node = node.parentElement) {
          if (node.matches('.ui-virtual-list__scroller, .ui-scroll-area__container') ||
              /auto|scroll/.test(getComputedStyle(node).overflowY)) { scroller = node; break; }
        }
      }
      return { content, conversation, panel: panelFor(content), legacy, scroller, rootId, expectedReplies,
        messages: new Map(), seenPositions: new Set(), knownTotal: 0, reason: 'stable-boundaries',
        startReached: false, endReached: false, startEvidence: '', endEvidence: '',
        upwardStopReason: 'not-started', downwardStopReason: 'not-started', nativeUsed: !legacy,
        scrollAttempts: { wheel: 0, native: 0 } };
    }
    const main = createScope(roots[0]);
    if (!main.scroller) return finish({ detected: false, error: 'Не найден контейнер прокрутки переписки.' },
      { outcome: 'error', reason: 'no-scroller' });
    const titleNode = document.querySelector('.yamb-chat-header__title, .yamb-conversation-header__title');
    const chatTitle = trim(titleNode && titleNode.textContent) || document.title.replace(/\s*[—–]\s*\d+.*$/, '');
    if (options.mode === 'inspect') return { detected: true, chatTitle, adapter: main.legacy ? 'infinite-list' : 'native-scroll' };
    if (root.__chatDownloaderRunning) return finish({ error: 'В этой вкладке уже идёт выгрузка.' },
      { outcome: 'error', reason: 'busy' });
    root.__chatDownloaderRunning = true;
    const runId = typeof options.runId === 'string' ? options.runId : '';
    const control = { id: runId, stopped: controls.pending.delete(runId), wake: null, record };
    controls.active = control;
    const sleep = ms => new Promise(resolve => {
      if (control.stopped) { resolve(); return; }
      let timer;
      let settled = false;
      const done = () => {
        if (settled) return;
        settled = true;
        if (typeof clearTimeout === 'function') clearTimeout(timer);
        if (control.wake === done) control.wake = null;
        resolve();
      };
      control.wake = done;
      timer = setTimeout(done, ms);
    });

    const startedAt = Date.now();
    const originalURL = location.href;
    const delayMs = Math.max(20, options.delayMs || 300);
    const stableRounds = Math.max(2, options.stableRounds || 12);
    const maxDurationMs = options.maxDurationMs || 2 * 60 * 60 * 1000;
    const noProgressTimeoutMs = options.noProgressTimeoutMs || 60 * 1000;
    const threadOpenTimeoutMs = options.threadOpenTimeoutMs || 15000;
    const edgeRetryDelayMs = Math.max(20, options.edgeRetryDelayMs || 3000);
    const threads = new Map();
    const anonymousNodes = new WeakMap();
    let anonymousIndex = 0;
    let limitReached = false;
    let threadNavigationFailed = false;

    record('collector.start', { delayMs, stableRounds, maxDurationMs, noProgressTimeoutMs, threadOpenTimeoutMs, edgeRetryDelayMs,
      stopped: control.stopped, hidden: document.hidden === true });
    if (control.stopped) record('collector.cancel', { stopped: true, reason: 'user-stopped' });

    const articles = scope => Array.from(scope.content.querySelectorAll('article.message'));
    function diagnosticState(scope) {
      if (!recorder) return {};
      try { return { scope: scope.rootId ? 'thread' : 'main', threadRef: reference(scope.rootId),
        adapter: scope.legacy ? 'infinite-list' : 'native-scroll', nativeUsed: scope.nativeUsed,
        scrollTop: scope.scroller.scrollTop, scrollHeight: scope.scroller.scrollHeight,
        clientHeight: scope.scroller.clientHeight, visible: visible(scope.content),
        connected: Boolean(scope.content.isConnected && scope.scroller.isConnected), hidden: document.hidden === true,
        elapsedMs: Date.now() - startedAt, messageCount: scope.messages.size,
        oldestTimestampMs: scope.oldestTimestampMs, newestTimestampMs: scope.newestTimestampMs,
        seenPositionCount: scope.seenPositions.size, minPosition: scope.diagnosticMinPosition,
        maxPosition: scope.diagnosticMaxPosition, expectedTotal: scope.knownTotal || scope.expectedReplies || 0,
        wheelAttempts: scope.scrollAttempts.wheel, nativeAttempts: scope.scrollAttempts.native,
        ...scope.lastDiagnosticSnapshot }; } catch { return {}; }
    }
    function navigationState(rootId) {
      if (!recorder) return {};
      try {
        const list = articles(main);
        return { ...diagnosticState(main), threadRef: reference(rootId),
          firstPosition: Number(list[0]?.getAttribute('aria-posinset')) || 0,
          lastPosition: Number(list[list.length - 1]?.getAttribute('aria-posinset')) || 0,
          // Opening or closing a thread can remount the main window before the
          // next collection snapshot. Do not reuse its previous endpoint IDs.
          firstRef: undefined, lastRef: undefined };
      } catch { return {}; }
    }
    function idSource(article) {
      if (article.getAttribute('data-message-id')) return 'explicit';
      const bases = trim(article.getAttribute('aria-labelledby')).split(/\s+/)
        .map(label => /^(\d+)_(?:h|fr|c|i|fo)$/.exec(label)).filter(Boolean).map(match => match[1]);
      if (bases.length && bases.every(base => base === bases[0])) return 'label';
      if (article.id) return 'element';
      if (Number(article.getAttribute('aria-posinset')) > 0) return 'position';
      return 'anonymous';
    }
    record('collector.container', diagnosticState(main));
    function messageId(article, scope = main) {
      const explicit = article.getAttribute('data-message-id');
      if (explicit) return explicit;
      const labels = trim(article.getAttribute('aria-labelledby')).split(/\s+/);
      const bases = labels.map(label => /^(\d+)_(?:h|fr|c|i|fo)$/.exec(label)).filter(Boolean).map(match => match[1]);
      if (bases.length && bases.every(base => base === bases[0])) return bases[0];
      if (article.id) return article.id;
      const position = article.getAttribute('aria-posinset');
      const prefix = scope.rootId ? `thread-${scope.rootId}-` : '';
      if (position && Number(position) > 0) {
        warnings.add('Идентификаторы части сообщений восстановлены по позиции в истории.');
        return `${prefix}position-${position}`;
      }
      warnings.add('У части сообщений нет устойчивого ID; возможны повторы после перерисовки страницы.');
      if (!anonymousNodes.has(article)) anonymousNodes.set(article, `unidentified-${prefix}${++anonymousIndex}`);
      return anonymousNodes.get(article);
    }
    function renderedText(node) {
      if (!node) return '';
      // innerText preserves paragraphs and line breaks in copyable rich text.
      return trim(node.innerText || node.textContent);
    }
    function safeAttachmentURL(value) {
      if (!value) return '';
      try {
        const url = new URL(value, location.href);
        return /^https?:$/.test(url.protocol) && !url.username && !url.password ? url.href : '';
      } catch { return ''; }
    }
    function attachmentURL(node) {
      const anchor = node.matches('a[href]') ? node : node.querySelector('a[href]');
      const direct = safeAttachmentURL(anchor && anchor.getAttribute('href'));
      if (direct) return direct;
      const media = node.matches('img, video, audio, source') ? node : node.querySelector('video, audio, source, img');
      const source = safeAttachmentURL(media && (media.currentSrc || media.getAttribute('src')));
      // Download the original rather than a thumbnail when its storage ID is available.
      const thumbnail = node.matches('[data-lightbox-gallery-thumbnail]') ? node
        : node.querySelector('[data-lightbox-gallery-thumbnail]');
      const fileId = thumbnail && thumbnail.getAttribute('data-lightbox-gallery-thumbnail');
      if (/^disk\/[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(fileId || '')) {
        let origin = '';
        for (const link of document.querySelectorAll('.yamb-message-file a[href], a.yamb-message-file[href]')) {
          const value = safeAttachmentURL(link.getAttribute('href'));
          if (!value) continue;
          const url = new URL(value);
          if (/^files\.messenger\.yandex\.(ru|net|com)$/.test(url.hostname) &&
              url.pathname.startsWith('/file_shortterm/')) { origin = url.origin; break; }
        }
        if (!origin && /^(?:(?:telemost|messenger)(?:\.360)?\.)?yandex\.ru$/.test(new URL(location.href).hostname)) {
          origin = 'https://files.messenger.yandex.ru';
        }
        if (origin) return `${origin}/file_shortterm/${fileId}?attach=true`;
      }
      return source;
    }
    function exactTimestamp(article, datetime) {
      const body = article.querySelector('.yamb-message-content[data-timestamp]');
      const raw = body && body.getAttribute('data-timestamp');
      let milliseconds = null;
      if (/^\d{16}$/.test(raw || '')) milliseconds = Number(raw.slice(0, -3));
      else if (/^\d{13}$/.test(raw || '')) milliseconds = Number(raw);
      // System messages may have no body. Their accessible IDs use the same
      // microsecond timestamp as the message body in Messenger.
      if (milliseconds === null && !datetime) {
        const labels = trim(article.getAttribute('aria-labelledby')).split(/\s+/);
        const bases = labels.map(label => /^(\d{16})_(?:h|fr|c|i|fo)$/.exec(label)).filter(Boolean).map(match => match[1]);
        if (bases.length && bases.every(base => base === bases[0])) milliseconds = Number(bases[0].slice(0, -3));
      }
      return milliseconds !== null && milliseconds >= 946684800000 && milliseconds < 4102444800000 ? milliseconds : null;
    }
    function parseArticle(article, scope) {
      const row = article.querySelector('.yamb-message-row');
      const system = article.querySelector('.yamb-message-system');
      // A date separator can precede a NORMAL message within the same article.
      if (!row && system && /^(?:сегодня|вчера|today|yesterday|\d{1,2}\s+[а-яa-z]+(?:\s+\d{4})?)$/i.test(renderedText(system))) return null;
      const id = messageId(article, scope);
      const own = Boolean(article.querySelector('.yamb-message-row_own'));
      const senderNode = article.querySelector('.yamb-message-user');
      const sender = trim(senderNode && senderNode.getAttribute('aria-label')) ||
        renderedText(article.querySelector('.yamb-message-user__name')) || '';
      const reply = article.querySelector('.yamb-message-reply');
      const textNodes = Array.from(article.querySelectorAll('[data-copyable="true"]'))
        .filter(node => !node.closest('.yamb-message-reply, .yamb-message-system'));
      const outerTextNodes = textNodes.filter(node => !textNodes.some(other => other !== node && other.contains(node)));
      let text = outerTextNodes.map(renderedText).filter(Boolean).join('\n');
      if (!text) {
        const textBlock = article.querySelector('.yamb-message-text');
        if (textBlock) {
          // Older variants put the clock inside this wrapper.
          const plain = textBlock.querySelector('.text');
          text = renderedText(plain) || Array.from(textBlock.childNodes)
            .filter(node => node.nodeType === 3).map(node => trim(node.textContent)).join('\n');
        }
      }
      const attachments = [];
      const attachmentLinks = [];
      function addAttachment(node, name) {
        const url = attachmentURL(node);
        attachments.push(name);
        attachmentLinks.push({ name, url });
      }
      article.querySelectorAll('.yamb-message-file').forEach(file => {
        if (file.closest('.yamb-message-reply')) return;
        const name = renderedText(file.querySelector('.yamb-message-file__name')) || 'Файл';
        const size = renderedText(file.querySelector('.yamb-message-file__size'));
        addAttachment(file, size ? `${name} (${size})` : name);
      });
      const attachmentTypes = [
        ['.yamb-message-image, .yamb-gallery-image', 'Изображение'],
        ['.yamb-message-video', 'Видео'],
        ['.yamb-message-voice', 'Голосовое сообщение'],
        ['.yamb-message-audio', 'Аудио'],
        ['.yamb-message-sticker', 'Стикер']
      ];
      attachmentTypes.forEach(([selector, label]) => {
        article.querySelectorAll(selector).forEach(node => {
          // A gallery wrapper is not another attachment alongside its images.
          if (!node.closest('.yamb-message-reply') && !node.querySelector(selector)) addAttachment(node, label);
        });
      });
      const timeNode = article.querySelector('.yamb-message-info__time');
      const time = trim(timeNode && (timeNode.getAttribute('aria-label') || timeNode.textContent));
      const datetime = timeNode && timeNode.getAttribute('datetime');
      const timestampMs = exactTimestamp(article, datetime);
      const date = datetime ? datetime.slice(0, 10) : (time.match(/^\d{1,2}:\d{2}\s+(.+)$/) || [])[1] ||
        (row && system ? renderedText(system) : '');
      const questionText = renderedText(reply && reply.querySelector('.yamb-message-reply__description'));
      const questionAuthor = renderedText(reply && reply.querySelector('.yamb-message-reply__title'));
      const replyToId = reply && (reply.getAttribute('data-reply-to-id') || reply.getAttribute('data-message-id')) || '';
      if (!row && system) text = renderedText(system);
      if (!text && !attachments.length && row) {
        text = '[Сообщение без доступного текста]';
        warnings.add('Встречены сообщения, содержимое которых интерфейс не предоставил в текстовом виде.');
      }
      if (!text && !attachments.length) return null;
      return { id, threadRootId: id === scope.rootId ? '' : scope.rootId, time, date, datetime: datetime || '', timestampMs, sender, isOwnMessage: own, message: text, replyToId,
        questionText, questionAuthor, attachments, attachmentLinks, type: !row && system ? 'Системное' : reply ? 'Ответ' : 'Сообщение',
        order: Number(article.getAttribute('aria-posinset')) || 0 };
    }
    function collect(scope) {
      const list = articles(scope);
      const diagnostic = recorder ? { articleCount: list.length, visibleCount: 0, newMessages: 0, newPositions: 0,
        parsedCount: 0, skippedCount: 0, duplicateCount: 0, idCollisionCount: 0, idPositionChangedCount: 0,
        firstPosition: Number(list[0]?.getAttribute('aria-posinset')) || 0,
        lastPosition: Number(list[list.length - 1]?.getAttribute('aria-posinset')) || 0,
        idExplicitCount: 0, idLabelCount: 0, idElementCount: 0, idPositionCount: 0, idAnonymousCount: 0 } : null;
      const windowIds = diagnostic ? new Set() : null;
      for (const article of list) {
        const position = Number(article.getAttribute('aria-posinset'));
        if (diagnostic) {
          if (typeof article.getClientRects === 'function' && visible(article)) diagnostic.visibleCount++;
          if (Number.isInteger(position) && position > 0) {
            if (!scope.seenPositions.has(position)) diagnostic.newPositions++;
            scope.diagnosticMinPosition = Math.min(scope.diagnosticMinPosition ?? position, position);
            scope.diagnosticMaxPosition = Math.max(scope.diagnosticMaxPosition ?? position, position);
          }
          const source = idSource(article);
          const key = { explicit: 'idExplicitCount', label: 'idLabelCount', element: 'idElementCount',
            position: 'idPositionCount', anonymous: 'idAnonymousCount' }[source];
          diagnostic[key]++;
        }
        if (Number.isInteger(position) && position > 0) scope.seenPositions.add(position);
        const total = Number(article.getAttribute('aria-setsize'));
        if (Number.isInteger(total) && total > 0) scope.knownTotal = Math.max(scope.knownTotal, total);
        const message = parseArticle(article, scope);
        if (!message) { if (diagnostic) diagnostic.skippedCount++; continue; }
        if (Number.isFinite(message.timestampMs)) {
          scope.oldestTimestampMs = Math.min(scope.oldestTimestampMs ?? message.timestampMs, message.timestampMs);
          scope.newestTimestampMs = Math.max(scope.newestTimestampMs ?? message.timestampMs, message.timestampMs);
        }
        const previous = scope.messages.get(message.id);
        if (diagnostic) {
          diagnostic.parsedCount++;
          if (previous) diagnostic.duplicateCount++;
          else diagnostic.newMessages++;
          if (windowIds.has(message.id)) diagnostic.idCollisionCount++;
          windowIds.add(message.id);
          if (previous && previous.order !== message.order) diagnostic.idPositionChangedCount++;
          if (diagnostic.firstRef === undefined) diagnostic.firstRef = reference(message.id);
          diagnostic.lastRef = reference(message.id);
        }
        scope.messages.set(message.id, previous ? { ...message, sender: message.sender || previous.sender,
          date: message.date || previous.date, datetime: message.datetime || previous.datetime,
          timestampMs: message.timestampMs ?? previous.timestampMs,
          attachments: message.attachments.length ? message.attachments : previous.attachments,
          attachmentLinks: message.attachmentLinks.length ? message.attachmentLinks.map((link, index) => ({ ...link,
            url: link.url || previous.attachmentLinks?.[index]?.name === link.name && previous.attachmentLinks[index].url || '' }))
            : previous.attachmentLinks } : message);
      }
      if (diagnostic) {
        scope.lastDiagnosticSnapshot = diagnostic;
        record('collector.snapshot', diagnosticState(scope));
      }
    }
    function checkChat() {
      if (location.href !== originalURL || !main.content.isConnected || !main.scroller.isConnected) {
        const error = new Error('Во время выгрузки чат изменился. Откройте нужную переписку и повторите выгрузку.');
        error.chatChanged = true;
        error.diagnosticReason = 'chat-changed';
        throw error;
      }
    }
    function withinBudget() {
      if (Date.now() - startedAt >= maxDurationMs) limitReached = true;
      return !limitReached;
    }
    function checkState(scope) {
      checkChat();
      if (control.stopped) { scope.reason = 'user-stopped'; return false; }
      if (!withinBudget()) { scope.reason = 'limit'; return false; }
      if (!scope.content.isConnected || !scope.scroller.isConnected || !visible(scope.content)) {
        const error = new Error('Панель переписки закрылась во время выгрузки.');
        error.diagnosticReason = 'panel-closed';
        throw error;
      }
      if (scope.rootId) {
        const parent = scope.conversation.querySelector('.ui-InfiniteList-Header article.message');
        if (parent && messageId(parent, main) !== scope.rootId) {
          const error = new Error('Открыто другое обсуждение.');
          error.diagnosticReason = 'thread-changed';
          throw error;
        }
      }
      return true;
    }
    function progressTracker(scope, direction) {
      const { scroller, legacy } = scope;
      // Each pass needs its own frontier: the downward pass revisits messages
      // already collected on the way up. Oscillating between old windows does
      // not extend this frontier and must not keep the collector alive.
      const visitedIds = new Set();
      let bestPosition = null;
      let bestNumericId = null;
      let bestOffset = scroller.scrollTop;
      let knownScrollRange = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
      let initialized = false;
      const compareIds = (a, b) => a.length - b.length || a.localeCompare(b);
      const farther = (comparison) => direction < 0 ? comparison < 0 : comparison > 0;
      return () => {
        let position = null;
        let numericId = null;
        let hasNewId = false;
        for (const article of articles(scope)) {
          const value = Number(article.getAttribute('aria-posinset'));
          if (Number.isInteger(value) && value > 0 &&
              (position === null || farther(value - position))) position = value;
          const id = messageId(article, scope);
          // Anonymous IDs change on remount; they are not evidence of progress.
          if (id.startsWith('unidentified-')) continue;
          if (!visitedIds.has(id)) hasNewId = true;
          visitedIds.add(id);
          if (/^\d+$/.test(id)) {
            const normalized = id.replace(/^0+(?=\d)/, '');
            if (numericId === null || farther(compareIds(normalized, numericId))) numericId = normalized;
          }
        }
        const positionAdvanced = position !== null &&
          (bestPosition === null || farther(position - bestPosition));
        const idAdvanced = numericId !== null &&
          (bestNumericId === null || farther(compareIds(numericId, bestNumericId)));
        if (positionAdvanced) bestPosition = position;
        if (idAdvanced) bestNumericId = numericId;
        // Positions can restart at 1 when another older history batch is loaded.
        // The directional frontier of stable numeric IDs is independent of that
        // local numbering; observing a new older ID is still real progress.
        let advanced = positionAdvanced || idAdvanced || position === null && numericId === null && hasNewId;
        // A native list can keep the same articles mounted while the viewport
        // advances through them. Only a new directional scroll extreme counts.
        // Layout growth alone must not keep extending the progress deadline.
        // Extend the native range only when history itself has advanced.
        if (advanced) knownScrollRange = Math.max(knownScrollRange, scroller.scrollHeight - scroller.clientHeight);
        const offset = Math.min(scroller.scrollTop, knownScrollRange);
        if (scope.nativeUsed && farther(offset - bestOffset)) {
          bestOffset = offset;
          advanced = true;
        }
        if (!initialized) {
          initialized = true;
          return false;
        }
        return advanced;
      };
    }
    function boundaryEvidence(scope, direction) {
      const list = articles(scope);
      if (!list.length) return '';
      const firstPosition = Number(list[0].getAttribute('aria-posinset'));
      const last = list[list.length - 1];
      const lastPosition = Number(last.getAttribute('aria-posinset'));
      const total = Number(last.getAttribute('aria-setsize'));
      // A physical scroll edge only bounds the loaded fragment. It does not
      // prove that the service has supplied its oldest or newest message.
      if (direction < 0 && scope.rootId && scope.expectedReplies > 0 && firstPosition === 1) return 'first-position';
      if (direction < 0 && !scope.rootId) {
        // A local position of 1 is only the start of the currently loaded batch.
        // Accept a creation marker only as an actual system item, never text
        // from an ordinary message or its quoted reply.
        const first = list[0];
        const system = first.querySelector('.yamb-message-system');
        if (system && !first.querySelector('.yamb-message-row') &&
            /^(?:чат создан|создан чат|групповой чат создан|создан групповой чат|chat created|group chat created)[.!]?$/i.test(renderedText(system))) {
          return 'chat-created-event';
        }
      }
      if (direction > 0 && total > 0 && lastPosition >= total) return 'total-count';
      if (direction > 0 && scope.expectedReplies > 0 && lastPosition >= scope.expectedReplies) return 'thread-reply-count';
      return '';
    }
    function physicalEdge(scope, direction) {
      const scroller = scope.scroller;
      return direction < 0 ? scroller.scrollTop <= 1
        : scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 1;
    }
    async function settle() {
      await sleep(Math.min(delayMs, Math.max(0, maxDurationMs - (Date.now() - startedAt))));
    }
    async function traverse(scope, direction) {
      const { scroller, legacy, conversation } = scope;
      const loggedDirection = direction < 0 ? 'up' : 'down';
      let stable = 0;
      let edgeRetries = 0;
      let lastEdgeRetryAt = 0;
      const stopField = direction < 0 ? 'upwardStopReason' : 'downwardStopReason';
      const evidenceField = direction < 0 ? 'startEvidence' : 'endEvidence';
      const edgeField = direction < 0 ? 'stoppedAtTopEdge' : 'stoppedAtBottomEdge';
      scope[stopField] = 'running';
      record('collector.pass-start', { ...diagnosticState(scope), direction: loggedDirection });
      const endPass = result => {
        record('collector.pass-end', { ...diagnosticState(scope), direction: loggedDirection,
          reason: scope[stopField], evidence: scope[evidenceField] || 'none', atEdge: physicalEdge(scope, direction),
          stableCount: stable, startReached: scope.startReached || direction < 0 && result,
          endReached: scope.endReached || direction > 0 && result });
        return result;
      };
      const progressed = progressTracker(scope, direction);
      progressed();
      let lastProgressAt = Date.now();
      async function probeTopEdge() {
        const count = ++edgeRetries;
        lastEdgeRetryAt = Date.now();
        record('collector.edge-probe', { ...diagnosticState(scope), phase: 'before', direction: 'up', count, outcome: 'started' });
        const finishProbe = (advanced, outcome) => {
          record('collector.edge-probe', { ...diagnosticState(scope), phase: 'after', direction: 'up', count,
            outcome, algorithmProgress: advanced, reason: scope.reason });
          return advanced;
        };
        const distance = Math.max(40, Math.min(120, Math.floor(scroller.clientHeight * 0.2)));
        for (const step of [distance, -distance]) {
          if (!checkState(scope)) return finishProbe(false, control.stopped ? 'stopped' : 'partial');
          const before = scroller.scrollTop;
          const windowBefore = articles(scope).map(article => messageId(article, scope)).join('\0');
          if (legacy) {
            scope.scrollAttempts.wheel++;
            scroller.dispatchEvent(new WheelEvent('wheel', { deltaY: step, deltaMode: 0, bubbles: true, cancelable: true }));
          } else {
            scope.scrollAttempts.native++;
            scroller.scrollBy({ top: step, behavior: 'instant' });
          }
          await settle();
          if (!checkState(scope)) return finishProbe(false, control.stopped ? 'stopped' : 'partial');
          collect(scope);
          // Native lists can retain the legacy CSS class. A wheel event has no
          // browser default when dispatched by script, so physically leave and
          // re-enter the edge if the virtual window did not change at all.
          if (legacy && scroller.scrollTop === before &&
              articles(scope).map(article => messageId(article, scope)).join('\0') === windowBefore &&
              scroller.scrollHeight > scroller.clientHeight + 1 &&
              typeof scroller.scrollBy === 'function') {
            scope.nativeUsed = true;
            scope.scrollAttempts.native++;
            scroller.scrollBy({ top: step, behavior: 'instant' });
            await settle();
            if (!checkState(scope)) return finishProbe(false, control.stopped ? 'stopped' : 'partial');
            collect(scope);
          }
        }
        // The deliberate step away from the edge is not history progress.
        // Check only after returning, against the frontier from before probing.
        const advanced = progressed();
        return finishProbe(advanced, advanced ? 'success' : 'empty');
      }
      while (checkState(scope)) {
        collect(scope);
        if (scope === main) {
          // Thread work consumes the global budget, but is not a stalled main pass.
          const pausedAt = Date.now();
          await collectVisibleThreads();
          lastProgressAt += Date.now() - pausedAt;
          if (threadNavigationFailed || !checkState(scope)) {
            scope[stopField] = control.stopped ? 'user-stopped' : limitReached ? 'limit' : 'thread-close-failed';
            return endPass(false);
          }
        }
        let advanced = progressed();
        if (advanced) { lastProgressAt = Date.now(); edgeRetries = 0; }
        const delta = direction * Math.max(100, Math.floor(scroller.clientHeight * 0.65));
        let scrollTopBefore = scroller.scrollTop;
        let messagesBefore = scope.messages.size;
        record('collector.scroll', { ...diagnosticState(scope), phase: 'before', direction: loggedDirection,
          method: legacy ? 'wheel' : 'native', scrollTopBefore, delta });
        if (legacy) {
          scope.scrollAttempts.wheel++;
          scroller.dispatchEvent(new WheelEvent('wheel', { deltaY: delta, deltaMode: 0, bubbles: true, cancelable: true }));
        } else {
          scope.scrollAttempts.native++;
          scroller.scrollBy({ top: delta, behavior: 'instant' });
        }
        await settle();
        if (!checkState(scope)) {
          record('collector.scroll', { ...diagnosticState(scope), phase: 'after', direction: loggedDirection,
            method: legacy ? 'wheel' : 'native', scrollTopBefore, scrollTopAfter: scroller.scrollTop,
            reason: scope.reason, algorithmProgress: false, newMessages: 0 });
          break;
        }
        collect(scope);
        let stepAdvanced = progressed();
        record('collector.scroll', { ...diagnosticState(scope), phase: 'after', direction: loggedDirection,
          method: legacy ? 'wheel' : 'native', scrollTopBefore, scrollTopAfter: scroller.scrollTop,
          algorithmProgress: stepAdvanced, newMessages: scope.messages.size - messagesBefore });
        // Some Telemost versions retain InfiniteList's class names but use
        // native scrolling. An unhandled synthetic wheel has no default scroll.
        // Keep each rendered window before trying the second mechanism.
        if (legacy && !stepAdvanced && scroller.scrollHeight > scroller.clientHeight + 1 &&
            typeof scroller.scrollBy === 'function') {
          scope.nativeUsed = true;
          scope.scrollAttempts.native++;
          scrollTopBefore = scroller.scrollTop;
          messagesBefore = scope.messages.size;
          record('collector.scroll', { ...diagnosticState(scope), phase: 'before', direction: loggedDirection,
            method: 'fallback', scrollTopBefore, delta });
          scroller.scrollBy({ top: delta, behavior: 'instant' });
          await settle();
          if (!checkState(scope)) {
            record('collector.scroll', { ...diagnosticState(scope), phase: 'after', direction: loggedDirection,
              method: 'fallback', scrollTopBefore, scrollTopAfter: scroller.scrollTop,
              reason: scope.reason, algorithmProgress: false, newMessages: 0 });
            break;
          }
          collect(scope);
          stepAdvanced = progressed();
          record('collector.scroll', { ...diagnosticState(scope), phase: 'after', direction: loggedDirection,
            method: 'fallback', scrollTopBefore, scrollTopAfter: scroller.scrollTop,
            algorithmProgress: stepAdvanced, newMessages: scope.messages.size - messagesBefore });
        }
        advanced = stepAdvanced || advanced;
        if (advanced) { lastProgressAt = Date.now(); edgeRetries = 0; }
        let loading = Boolean(conversation.querySelector('[aria-busy="true"], [role="progressbar"]'));
        scope[edgeField] = physicalEdge(scope, direction);
        let evidence = boundaryEvidence(scope, direction);
        if (scope === main && direction < 0 && !advanced && !loading && !evidence && scope[edgeField] &&
            edgeRetries < 3 && Date.now() - lastProgressAt >= edgeRetryDelayMs &&
            Date.now() - lastEdgeRetryAt >= edgeRetryDelayMs && Date.now() - lastProgressAt < noProgressTimeoutMs) {
          advanced = await probeTopEdge();
          if (!checkState(scope)) break;
          if (advanced) { lastProgressAt = Date.now(); edgeRetries = 0; }
          loading = Boolean(conversation.querySelector('[aria-busy="true"], [role="progressbar"]'));
          scope[edgeField] = physicalEdge(scope, direction);
          evidence = boundaryEvidence(scope, direction);
        }
        stable = !advanced && !loading && evidence ? stable + 1 : 0;
        record('collector.scroll', { ...diagnosticState(scope), phase: 'finish', direction: loggedDirection,
          algorithmProgress: advanced, loading, stableCount: stable, evidence: evidence || 'none',
          atEdge: scope[edgeField], noProgressMs: Date.now() - lastProgressAt });
        if (stable >= stableRounds) {
          scope[evidenceField] = evidence;
          scope[stopField] = direction < 0 ? 'confirmed-start' : 'confirmed-end';
          if (scope === main) await collectVisibleThreads();
          return endPass(true);
        }
        if (Date.now() - lastProgressAt >= noProgressTimeoutMs) {
          scope.reason = 'no-progress';
          scope[stopField] = 'no-progress';
          return endPass(false);
        }
      }
      scope[stopField] = control.stopped ? 'user-stopped' : limitReached ? 'limit' : scope.reason;
      return endPass(false);
    }
    function coverageFor(scope) {
      const expected = scope.knownTotal || scope.expectedReplies || Array.from(scope.seenPositions).reduce((highest, position) => Math.max(highest, position), 0);
      const hasGaps = scope.seenPositions.size > 0 && expected > 0 &&
        Array.from(scope.seenPositions).filter(n => n <= expected).length < expected;
      const unstableIds = Array.from(scope.messages.keys()).some(id => id.startsWith('unidentified-'));
      if (hasGaps && scope.reason === 'stable-boundaries') scope.reason = 'gaps';
      return { startReached: scope.startReached, endReached: scope.endReached,
        complete: scope.startReached && scope.endReached && !['limit', 'user-stopped'].includes(scope.reason) && !hasGaps && !unstableIds,
        reason: scope.reason, hasGaps, unstableIds, startEvidence: scope.startEvidence, endEvidence: scope.endEvidence,
        upwardStopReason: scope.upwardStopReason, downwardStopReason: scope.downwardStopReason,
        firstPosition: scope.seenPositions.size ? Array.from(scope.seenPositions).reduce((a, b) => Math.min(a, b), Infinity) : null,
        lastPosition: Array.from(scope.seenPositions).reduce((a, b) => Math.max(a, b), 0) || null,
        expectedTotal: scope.knownTotal || scope.expectedReplies || null,
        stoppedAtTopEdge: scope.stoppedAtTopEdge ?? null, stoppedAtBottomEdge: scope.stoppedAtBottomEdge ?? null,
        scrollAttempts: { ...scope.scrollAttempts } };
    }
    function sortedMessages(scope) {
      const messages = Array.from(scope.messages.values());
      // Select one ordering scheme for the entire scope. Comparing ID for one
      // pair and local position for another can produce a non-transitive order.
      if (messages.every(message => /^\d+$/.test(message.id))) {
        return messages.sort((a, b) => {
          const left = a.id.replace(/^0+(?=\d)/, ''), right = b.id.replace(/^0+(?=\d)/, '');
          return left.length - right.length || left.localeCompare(right);
        });
      }
      if (messages.every(message => Number.isFinite(message.timestampMs))) {
        return messages.sort((a, b) => a.timestampMs - b.timestampMs);
      }
      if (messages.every(message => message.order > 0)) return messages.sort((a, b) => a.order - b.order);
      return messages;
    }
    function threadContents() { return allContents().filter(isThread); }
    async function closeThread(content, cleanup = false, rootId = '') {
      record('collector.thread-close', { ...navigationState(rootId), phase: 'before' });
      const closed = (result, reason) => {
        record('collector.thread-close', { ...navigationState(rootId), phase: 'after',
          outcome: result ? 'success' : control.stopped ? 'stopped' : 'error', reason, stopped: control.stopped });
        return result;
      };
      if (control.stopped && !cleanup) return closed(false, 'user-stopped');
      const panel = panelFor(content);
      const button = Array.from(panel.querySelectorAll('[data-test-tag="thread-header-close"], [data-test-tag="chat-header-back"]')).find(visible);
      if (!button) return closed(false, 'unavailable');
      button.click();
      if (control.stopped) return closed(true, 'user-stopped');
      const until = Date.now() + threadOpenTimeoutMs;
      while (Date.now() < until && !control.stopped) {
        checkChat();
        if (!content.isConnected || !visible(content) || !isThread(content)) return closed(true, 'completed');
        if (!withinBudget()) return closed(false, 'limit');
        await sleep(Math.min(delayMs, Math.max(0, maxDurationMs - (Date.now() - startedAt))));
      }
      return closed(control.stopped, control.stopped ? 'user-stopped' : 'timeout');
    }
    async function collectVisibleThreads() {
      // Opening a panel can remount the main virtual window. Resolve the next
      // button from the current DOM after every discussion, never a stale snapshot.
      while (!control.stopped) {
        collect(main);
        const current = articles(main);
        for (const article of current) {
          const previous = threads.get(messageId(article, main));
          const badge = article.querySelector('.yamb-message-thread-data .yamb-message-footer-badge');
          const count = badge && /^(\d+)\s+(?:ответ|repl)/i.exec(renderedText(badge));
          if (previous && count) previous.expectedReplies = Math.max(previous.expectedReplies, Number(count[1]));
        }
        const article = current.find(node => !threads.has(messageId(node, main)) &&
          node.querySelector('.yamb-message-thread-data .yamb-message-footer-badge'));
        if (!article) break;
        const badge = article.querySelector('.yamb-message-thread-data .yamb-message-footer-badge');
        if (!badge) continue;
        const rootId = messageId(article, main);
        const count = /^(\d+)\s+(?:ответ|repl)/i.exec(renderedText(badge));
        const expectedReplies = count ? Number(count[1]) : 0;
        const entry = { rootId, expectedReplies, collectedReplies: 0,
          coverage: { startReached: false, endReached: false, complete: false, reason: 'not-opened' } };
        threads.set(rootId, entry);
        record('collector.thread-open', { ...navigationState(rootId), phase: 'start', expectedReplies });
        if (rootId.startsWith('unidentified-')) { entry.coverage.reason = 'not-opened'; continue; }
        if (!withinBudget() || threadNavigationFailed) { entry.coverage.reason = limitReached ? 'limit' : 'not-opened'; continue; }
        let opened = null;
        try {
          if (!badge.isConnected) {
            entry.coverage.reason = 'open-failed';
            record('collector.thread-open', { ...navigationState(rootId), phase: 'after', reason: 'unavailable', outcome: 'error' });
            continue;
          }
          record('collector.thread-open', { ...navigationState(rootId), phase: 'before', expectedReplies });
          badge.click();
          const until = Date.now() + threadOpenTimeoutMs;
          while (Date.now() < until && !control.stopped && withinBudget()) {
            checkChat();
            const panels = threadContents();
            const matching = panels.find(content => {
              const parent = (content.closest('.yamb-conversation') || content.parentElement).querySelector('.ui-InfiniteList-Header article.message');
              return parent && messageId(parent, main) === rootId;
            });
            if (matching) { opened = matching; break; }
            await sleep(Math.min(delayMs, Math.max(0, maxDurationMs - (Date.now() - startedAt))));
          }
          if (!opened) {
            entry.coverage.reason = control.stopped ? 'user-stopped' : limitReached ? 'limit' : 'open-failed';
            record('collector.thread-open', { ...navigationState(rootId), phase: 'after',
              reason: control.stopped ? 'user-stopped' : limitReached ? 'limit' : 'timeout',
              outcome: control.stopped ? 'stopped' : 'error' });
            continue;
          }
          record('collector.thread-open', { ...navigationState(rootId), phase: 'after', expectedReplies, outcome: 'success' });
          const scope = createScope(opened, rootId, expectedReplies);
          entry.scope = scope;
          if (!scope.scroller) {
            entry.coverage.reason = 'no-scroller';
            record('collector.error', { scope: 'thread', threadRef: reference(rootId), reason: 'no-scroller' });
            continue;
          }
          record('collector.container', diagnosticState(scope));
          collect(scope);
          scope.startReached = await traverse(scope, -1);
          if (!control.stopped && !limitReached) scope.endReached = await traverse(scope, 1);
          collect(scope);
          entry.coverage = coverageFor(scope);
        } catch (error) {
          if (error.chatChanged) throw error;
          record('collector.error', { scope: 'thread', threadRef: reference(rootId),
            reason: error.diagnosticReason || 'thread-error', errorCode: errorCode(error) });
          entry.coverage = { ...entry.coverage, complete: false, reason: 'thread-error' };
        } finally {
          if (entry.scope) entry.collectedReplies = Array.from(entry.scope.messages.keys()).filter(id => id !== rootId).length;
          // Close even after the global deadline; never leave a hidden main list scrolling.
          // On Stop, only close the discussion opened by this iteration. A
          // different panel may have been opened by the user in the meantime.
          const pending = threadContents().filter(content => {
            if (!control.stopped || content === opened) return true;
            const parent = (content.closest('.yamb-conversation') || content.parentElement)
              .querySelector('.ui-InfiniteList-Header article.message');
            return parent && messageId(parent, main) === rootId;
          });
          for (const content of pending) {
            if (!await closeThread(content, true, rootId) && !control.stopped) {
              threadNavigationFailed = true;
              main.reason = 'thread-close-failed';
              entry.coverage.complete = false;
              entry.coverage.reason = 'close-failed';
              break;
            }
          }
        }
      }
    }
    try {
      for (const content of threadContents()) {
        if (control.stopped) break;
        if (!await closeThread(content) && !control.stopped) return finish(
          { detected: true, error: 'Не удалось закрыть открытый тред. Закройте его и повторите выгрузку.' },
          { outcome: 'error', reason: 'thread-close-failed', elapsedMs: Date.now() - startedAt });
      }
      collect(main);
      main.startReached = await traverse(main, -1);
      if (!control.stopped && !limitReached && !threadNavigationFailed) main.endReached = await traverse(main, 1);
      checkChat();
      collect(main);
      let coverage = coverageFor(main);
      const result = sortedMessages(main);
      const byId = new Map(result.map(message => [message.id, message]));
      for (const entry of threads.values()) {
        if (entry.collectedReplies < entry.expectedReplies) {
          entry.coverage.complete = false;
          if (entry.coverage.reason === 'stable-boundaries') entry.coverage.reason = 'missing-replies';
        }
        entry.coverage = classifyCoverage(entry.coverage, { scope: 'thread',
          expectedReplies: entry.expectedReplies, collectedReplies: entry.collectedReplies });
        record('collector.thread-finish', { scope: 'thread', threadRef: reference(entry.rootId),
          expectedReplies: entry.expectedReplies, collectedReplies: entry.collectedReplies,
          complete: entry.coverage.complete, startReached: entry.coverage.startReached,
          endReached: entry.coverage.endReached, reason: entry.coverage.reason, coverageStatus: entry.coverage.status,
          outcome: entry.coverage.statusReason === 'user-stopped' || entry.coverage.reason === 'user-stopped'
            ? 'stopped' : entry.coverage.complete ? 'success' : entry.coverage.status });
        if (!entry.scope) continue;
        for (const message of sortedMessages(entry.scope)) {
          if (message.id === entry.rootId) continue;
          if (byId.has(message.id)) {
            const previous = byId.get(message.id);
            if (!previous.threadRootId) previous.threadRootId = message.threadRootId;
          } else { result.push(message); byId.set(message.id, message); }
        }
      }
      result.forEach((message, index) => { message.order = index; });
      if (result.some(message => message.attachmentLinks.some(link => !link.url))) {
        warnings.add('Для части вложений интерфейс не предоставил ссылку; сохранено название.');
      }
      const threadsSummary = { discovered: threads.size,
        collected: Array.from(threads.values()).filter(entry => entry.collectedReplies > 0).length,
        complete: Array.from(threads.values()).every(entry => entry.coverage.complete),
        status: Array.from(threads.values()).some(entry => entry.coverage.status === 'partial') ? 'partial'
          : Array.from(threads.values()).some(entry => entry.coverage.status === 'unverified') ? 'unverified' : 'complete' };
      coverage.complete = coverage.complete && threadsSummary.complete && !control.stopped && !limitReached && !threadNavigationFailed;
      if (control.stopped) coverage.reason = 'user-stopped';
      else if (limitReached) coverage.reason = 'limit';
      else if (threadsSummary.status === 'partial' && coverage.reason === 'stable-boundaries') coverage.reason = 'threads-incomplete';
      coverage = classifyCoverage(coverage, { threadsSummary, threads: Array.from(threads.values()) });
      if (coverage.status === 'unverified') warnings.add('Полнота истории автоматически не подтверждена.');
      else if (coverage.status === 'partial') warnings.add(coverage.reason === 'user-stopped'
        ? 'Выгрузка остановлена пользователем. Сохранена только собранная часть истории.'
        : coverage.reason === 'limit'
        ? 'Достигнут общий предел времени выгрузки. Сохранена только собранная часть истории.'
        : 'Выгрузка завершилась с ограничениями. Сохранена собранная часть истории.');
      if (!coverage.startReached) warnings.add('Интерфейс не предоставил явного подтверждения начала чата.');
      if (threadsSummary.status === 'partial') warnings.add('Часть ответов в тредах не удалось загрузить. Подробности — в сведениях о тредах.');
      warnings.add('Файлы и медиа представлены ссылками. Для открытия может требоваться доступ к чату; временные ссылки могут истечь.');
      return finish({ detected: true, chatTitle, messages: result, coverage,
        metadata: { chatTitle, exportedAt: new Date().toISOString(), timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone, coverage, warnings: Array.from(warnings),
          threadsSummary, threads: Array.from(threads.values(), ({ scope, ...entry }) => entry) } },
      { ...diagnosticState(main), outcome: control.stopped ? 'stopped' : coverage.complete ? 'success' : coverage.status,
        reason: coverage.reason, startReached: coverage.startReached, endReached: coverage.endReached,
        complete: coverage.complete, coverageStatus: coverage.status, totalMessages: result.length, threadCount: threads.size });
    } catch (error) {
      record('collector.error', { reason: error.diagnosticReason || 'unavailable', errorCode: errorCode(error),
        elapsedMs: Date.now() - startedAt });
      return finish({ error: error.message, detected: true }, { outcome: 'error',
        reason: error.diagnosticReason || 'unavailable', elapsedMs: Date.now() - startedAt });
    } finally {
      control.wake?.();
      if (controls.active === control) controls.active = null;
      if (runId) remember(controls.finished, runId);
      root.__chatDownloaderRunning = false;
    }
  }

  root.ChatExtractor = { run, cancel };
})(globalThis);
