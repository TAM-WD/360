(function (root) {
  'use strict';

  async function run(options = {}) {
    const warnings = new Set();
    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
    const trim = value => (value || '').trim();
    const visible = node => node && node.getClientRects().length > 0 &&
      getComputedStyle(node).visibility !== 'hidden';
    const panelFor = content => content.closest('.yamb-chat') || content.closest('.yamb-conversation') || content.parentElement;
    const isThread = content => Boolean(panelFor(content).querySelector('.yamb-thread-header-controls-container'));
    const allContents = () => Array.from(document.querySelectorAll('.yamb-conversation__content')).filter(visible);
    const roots = Array.from(document.querySelectorAll('.yamb-conversation__content')).filter(content =>
      !isThread(content) && (visible(content) ||
        panelFor(content).classList?.contains('yamb-chat_thread-openned') && allContents().some(isThread)));
    if (!roots.length) return { detected: false, error: 'Откройте основную переписку и дождитесь загрузки сообщений.' };
    if (roots.length > 1) return { detected: false, error: 'Открыто несколько переписок. Оставьте один основной чат и повторите выгрузку.' };
    function createScope(content, rootId = '', expectedReplies = 0) {
      const conversation = content.closest('.yamb-conversation') || content.parentElement;
      const legacy = conversation.querySelector('.ui-InfiniteList-ScrollContainer[data-scroll-container="true"]') ||
        conversation.querySelector('.ui-InfiniteList[data-scroll-container="true"]');
      let scroller = legacy;
      if (!scroller) {
        for (let node = content; node && node !== document.body; node = node.parentElement) {
          if (node.matches('.ui-virtual-list__scroller, .ui-scroll-area__container') ||
              /auto|scroll/.test(getComputedStyle(node).overflowY)) { scroller = node; break; }
        }
      }
      return { content, conversation, panel: panelFor(content), legacy, scroller, rootId, expectedReplies,
        messages: new Map(), seenPositions: new Set(), knownTotal: 0, reason: 'stable-boundaries',
        startReached: false, endReached: false, startEvidence: '', endEvidence: '',
        upwardStopReason: 'not-started', downwardStopReason: 'not-started', nativeUsed: !legacy,
        scrollAttempts: { wheel: 0, native: 0 } };
    }
    const main = createScope(roots[0]);
    if (!main.scroller) return { detected: false, error: 'Не найден контейнер прокрутки переписки.' };
    const titleNode = document.querySelector('.yamb-chat-header__title, .yamb-conversation-header__title');
    const chatTitle = trim(titleNode && titleNode.textContent) || document.title.replace(/\s*[—–]\s*\d+.*$/, '');
    if (options.mode === 'inspect') return { detected: true, chatTitle, adapter: main.legacy ? 'infinite-list' : 'native-scroll' };
    if (root.__chatDownloaderRunning) return { error: 'В этой вкладке уже идёт выгрузка.' };
    root.__chatDownloaderRunning = true;

    const startedAt = Date.now();
    const originalURL = location.href;
    const delayMs = Math.max(20, options.delayMs || 300);
    const stableRounds = Math.max(2, options.stableRounds || 12);
    const maxDurationMs = options.maxDurationMs || 2 * 60 * 60 * 1000;
    const noProgressTimeoutMs = options.noProgressTimeoutMs || 60 * 1000;
    const threadOpenTimeoutMs = options.threadOpenTimeoutMs || 15000;
    const threads = new Map();
    const anonymousNodes = new WeakMap();
    let anonymousIndex = 0;
    let limitReached = false;
    let threadNavigationFailed = false;

    const articles = scope => Array.from(scope.content.querySelectorAll('article.message'));
    function messageId(article, scope = main) {
      const explicit = article.getAttribute('data-message-id');
      if (explicit) return explicit;
      const labels = trim(article.getAttribute('aria-labelledby')).split(/\s+/);
      const bases = labels.map(label => /^(\d+)_(?:h|fr|c|i|fo)$/.exec(label)).filter(Boolean).map(match => match[1]);
      if (bases.length && bases.every(base => base === bases[0])) return bases[0];
      if (article.id) return article.id;
      const position = article.getAttribute('aria-posinset');
      const prefix = scope.rootId ? `thread-${scope.rootId}-` : '';
      if (position && Number(position) > 0) {
        warnings.add('Идентификаторы части сообщений восстановлены по позиции в истории.');
        return `${prefix}position-${position}`;
      }
      warnings.add('У части сообщений нет устойчивого ID; возможны повторы после перерисовки страницы.');
      if (!anonymousNodes.has(article)) anonymousNodes.set(article, `unidentified-${prefix}${++anonymousIndex}`);
      return anonymousNodes.get(article);
    }
    function renderedText(node) {
      if (!node) return '';
      // innerText preserves paragraphs and line breaks in copyable rich text.
      return trim(node.innerText || node.textContent);
    }
    function parseArticle(article, scope) {
      const row = article.querySelector('.yamb-message-row');
      const system = article.querySelector('.yamb-message-system');
      // A date separator can precede a NORMAL message within the same article.
      if (!row && system && /^(?:сегодня|вчера|today|yesterday|\d{1,2}\s+[а-яa-z]+(?:\s+\d{4})?)$/i.test(renderedText(system))) return null;
      const id = messageId(article, scope);
      const own = Boolean(article.querySelector('.yamb-message-row_own'));
      const senderNode = article.querySelector('.yamb-message-user');
      const sender = trim(senderNode && senderNode.getAttribute('aria-label')) ||
        renderedText(article.querySelector('.yamb-message-user__name')) || '';
      const reply = article.querySelector('.yamb-message-reply');
      const textNodes = Array.from(article.querySelectorAll('[data-copyable="true"]'))
        .filter(node => !node.closest('.yamb-message-reply, .yamb-message-system'));
      const outerTextNodes = textNodes.filter(node => !textNodes.some(other => other !== node && other.contains(node)));
      let text = outerTextNodes.map(renderedText).filter(Boolean).join('\n');
      if (!text) {
        const textBlock = article.querySelector('.yamb-message-text');
        if (textBlock) {
          // Older variants put the clock inside this wrapper.
          const plain = textBlock.querySelector('.text');
          text = renderedText(plain) || Array.from(textBlock.childNodes)
            .filter(node => node.nodeType === 3).map(node => trim(node.textContent)).join('\n');
        }
      }
      const attachments = [];
      article.querySelectorAll('.yamb-message-file').forEach(file => {
        if (file.closest('.yamb-message-reply')) return;
        const name = renderedText(file.querySelector('.yamb-message-file__name')) || 'Файл';
        const size = renderedText(file.querySelector('.yamb-message-file__size'));
        attachments.push(size ? `${name} (${size})` : name);
      });
      const attachmentTypes = [
        ['.yamb-message-image', 'Изображение'],
        ['.yamb-gallery-image', 'Изображение'],
        ['.yamb-message-video', 'Видео'],
        ['.yamb-message-voice', 'Голосовое сообщение'],
        ['.yamb-message-audio', 'Аудио'],
        ['.yamb-message-sticker', 'Стикер']
      ];
      attachmentTypes.forEach(([selector, label]) => {
        article.querySelectorAll(selector).forEach(node => {
          if (!node.closest('.yamb-message-reply')) attachments.push(label);
        });
      });
      // Links to authenticated media are deliberately not stored; only visible descriptions.
      const timeNode = article.querySelector('.yamb-message-info__time');
      const time = trim(timeNode && (timeNode.getAttribute('aria-label') || timeNode.textContent));
      const datetime = timeNode && timeNode.getAttribute('datetime');
      const date = datetime ? datetime.slice(0, 10) : (time.match(/^\d{1,2}:\d{2}\s+(.+)$/) || [])[1] ||
        (row && system ? renderedText(system) : '');
      const questionText = renderedText(reply && reply.querySelector('.yamb-message-reply__description'));
      const questionAuthor = renderedText(reply && reply.querySelector('.yamb-message-reply__title'));
      const replyToId = reply && (reply.getAttribute('data-reply-to-id') || reply.getAttribute('data-message-id')) || '';
      if (!row && system) text = renderedText(system);
      if (!text && !attachments.length && row) {
        text = '[Сообщение без доступного текста]';
        warnings.add('Встречены сообщения, содержимое которых интерфейс не предоставил в текстовом виде.');
      }
      if (!text && !attachments.length) return null;
      return { id, threadRootId: id === scope.rootId ? '' : scope.rootId, time, date, sender, isOwnMessage: own, message: text, replyToId,
        questionText, questionAuthor, attachments, type: !row && system ? 'Системное' : reply ? 'Ответ' : 'Сообщение',
        order: Number(article.getAttribute('aria-posinset')) || 0 };
    }
    function collect(scope) {
      for (const article of articles(scope)) {
        const position = Number(article.getAttribute('aria-posinset'));
        if (Number.isInteger(position) && position > 0) scope.seenPositions.add(position);
        const total = Number(article.getAttribute('aria-setsize'));
        if (Number.isInteger(total) && total > 0) scope.knownTotal = Math.max(scope.knownTotal, total);
        const message = parseArticle(article, scope);
        if (!message) continue;
        const previous = scope.messages.get(message.id);
        scope.messages.set(message.id, previous ? { ...message, sender: message.sender || previous.sender,
          date: message.date || previous.date } : message);
      }
    }
    function checkChat() {
      if (location.href !== originalURL || !main.content.isConnected || !main.scroller.isConnected) {
        const error = new Error('Во время выгрузки чат изменился. Откройте нужную переписку и повторите выгрузку.');
        error.chatChanged = true;
        throw error;
      }
    }
    function withinBudget() {
      if (Date.now() - startedAt >= maxDurationMs) limitReached = true;
      return !limitReached;
    }
    function checkState(scope) {
      checkChat();
      if (!withinBudget()) { scope.reason = 'limit'; return false; }
      if (!scope.content.isConnected || !scope.scroller.isConnected || !visible(scope.content)) {
        throw new Error('Панель переписки закрылась во время выгрузки.');
      }
      if (scope.rootId) {
        const parent = scope.conversation.querySelector('.ui-InfiniteList-Header article.message');
        if (parent && messageId(parent, main) !== scope.rootId) throw new Error('Открыто другое обсуждение.');
      }
      return true;
    }
    function progressTracker(scope, direction) {
      const { scroller, legacy } = scope;
      // Each pass needs its own frontier: the downward pass revisits messages
      // already collected on the way up. Oscillating between old windows does
      // not extend this frontier and must not keep the collector alive.
      const visitedIds = new Set();
      let bestPosition = null;
      let bestNumericId = null;
      let bestOffset = scroller.scrollTop;
      let knownScrollRange = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
      let initialized = false;
      const compareIds = (a, b) => a.length - b.length || a.localeCompare(b);
      const farther = (comparison) => direction < 0 ? comparison < 0 : comparison > 0;
      return () => {
        let position = null;
        let numericId = null;
        let hasNewId = false;
        for (const article of articles(scope)) {
          const value = Number(article.getAttribute('aria-posinset'));
          if (Number.isInteger(value) && value > 0 &&
              (position === null || farther(value - position))) position = value;
          const id = messageId(article, scope);
          // Anonymous IDs change on remount; they are not evidence of progress.
          if (id.startsWith('unidentified-')) continue;
          if (!visitedIds.has(id)) hasNewId = true;
          visitedIds.add(id);
          if (/^\d+$/.test(id)) {
            const normalized = id.replace(/^0+(?=\d)/, '');
            if (numericId === null || farther(compareIds(normalized, numericId))) numericId = normalized;
          }
        }
        const positionAdvanced = position !== null &&
          (bestPosition === null || farther(position - bestPosition));
        const idAdvanced = numericId !== null &&
          (bestNumericId === null || farther(compareIds(numericId, bestNumericId)));
        if (positionAdvanced) bestPosition = position;
        if (idAdvanced) bestNumericId = numericId;
        let advanced = position !== null ? positionAdvanced : numericId !== null ? idAdvanced : hasNewId;
        // A native list can keep the same articles mounted while the viewport
        // advances through them. Only a new directional scroll extreme counts.
        // Layout growth alone must not keep extending the progress deadline.
        // Extend the native range only when history itself has advanced.
        if (advanced) knownScrollRange = Math.max(knownScrollRange, scroller.scrollHeight - scroller.clientHeight);
        const offset = Math.min(scroller.scrollTop, knownScrollRange);
        if (scope.nativeUsed && farther(offset - bestOffset)) {
          bestOffset = offset;
          advanced = true;
        }
        if (!initialized) {
          initialized = true;
          return false;
        }
        return advanced;
      };
    }
    function boundaryEvidence(scope, direction) {
      const list = articles(scope);
      if (!list.length) return '';
      const firstPosition = Number(list[0].getAttribute('aria-posinset'));
      const last = list[list.length - 1];
      const lastPosition = Number(last.getAttribute('aria-posinset'));
      const total = Number(last.getAttribute('aria-setsize'));
      // A physical scroll edge only bounds the loaded fragment. It does not
      // prove that the service has supplied its oldest or newest message.
      if (direction < 0 && firstPosition === 1) return 'first-position';
      if (direction > 0 && total > 0 && lastPosition >= total) return 'total-count';
      if (direction > 0 && scope.expectedReplies > 0 && lastPosition >= scope.expectedReplies) return 'thread-reply-count';
      return '';
    }
    function physicalEdge(scope, direction) {
      const scroller = scope.scroller;
      return direction < 0 ? scroller.scrollTop <= 1
        : scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 1;
    }
    async function settle() {
      await sleep(Math.min(delayMs, Math.max(0, maxDurationMs - (Date.now() - startedAt))));
    }
    async function traverse(scope, direction) {
      const { scroller, legacy, conversation } = scope;
      let stable = 0;
      const stopField = direction < 0 ? 'upwardStopReason' : 'downwardStopReason';
      const evidenceField = direction < 0 ? 'startEvidence' : 'endEvidence';
      const edgeField = direction < 0 ? 'stoppedAtTopEdge' : 'stoppedAtBottomEdge';
      scope[stopField] = 'running';
      const progressed = progressTracker(scope, direction);
      progressed();
      let lastProgressAt = Date.now();
      while (checkState(scope)) {
        collect(scope);
        if (scope === main) {
          // Thread work consumes the global budget, but is not a stalled main pass.
          const pausedAt = Date.now();
          await collectVisibleThreads();
          lastProgressAt += Date.now() - pausedAt;
          if (threadNavigationFailed || !checkState(scope)) {
            scope[stopField] = limitReached ? 'limit' : 'thread-close-failed';
            return false;
          }
        }
        let advanced = progressed();
        if (advanced) lastProgressAt = Date.now();
        const delta = direction * Math.max(100, Math.floor(scroller.clientHeight * 0.65));
        if (legacy) {
          scope.scrollAttempts.wheel++;
          scroller.dispatchEvent(new WheelEvent('wheel', { deltaY: delta, deltaMode: 0, bubbles: true, cancelable: true }));
        } else {
          scope.scrollAttempts.native++;
          scroller.scrollBy({ top: delta, behavior: 'instant' });
        }
        await settle();
        if (!checkState(scope)) break;
        collect(scope);
        let stepAdvanced = progressed();
        // Some Telemost versions retain InfiniteList's class names but use
        // native scrolling. An unhandled synthetic wheel has no default scroll.
        // Keep each rendered window before trying the second mechanism.
        if (legacy && !stepAdvanced && scroller.scrollHeight > scroller.clientHeight + 1 &&
            typeof scroller.scrollBy === 'function') {
          scope.nativeUsed = true;
          scope.scrollAttempts.native++;
          scroller.scrollBy({ top: delta, behavior: 'instant' });
          await settle();
          if (!checkState(scope)) break;
          collect(scope);
          stepAdvanced = progressed();
        }
        advanced = stepAdvanced || advanced;
        if (advanced) lastProgressAt = Date.now();
        const loading = Boolean(conversation.querySelector('[aria-busy="true"], [role="progressbar"]'));
        scope[edgeField] = physicalEdge(scope, direction);
        const evidence = boundaryEvidence(scope, direction);
        stable = !advanced && !loading && evidence ? stable + 1 : 0;
        if (stable >= stableRounds) {
          scope[evidenceField] = evidence;
          scope[stopField] = direction < 0 ? 'confirmed-start' : 'confirmed-end';
          if (scope === main) await collectVisibleThreads();
          return true;
        }
        if (Date.now() - lastProgressAt >= noProgressTimeoutMs) {
          scope.reason = 'no-progress';
          scope[stopField] = 'no-progress';
          return false;
        }
      }
      scope[stopField] = limitReached ? 'limit' : scope.reason;
      return false;
    }
    function coverageFor(scope) {
      const expected = scope.knownTotal || scope.expectedReplies || Array.from(scope.seenPositions).reduce((highest, position) => Math.max(highest, position), 0);
      const hasGaps = expected > 0 && Array.from(scope.seenPositions).filter(n => n <= expected).length < expected;
      const unstableIds = Array.from(scope.messages.keys()).some(id => id.startsWith('unidentified-'));
      if (hasGaps && scope.reason === 'stable-boundaries') scope.reason = 'gaps';
      return { startReached: scope.startReached, endReached: scope.endReached,
        complete: scope.startReached && scope.endReached && scope.reason !== 'limit' && !hasGaps && !unstableIds,
        reason: scope.reason, startEvidence: scope.startEvidence, endEvidence: scope.endEvidence,
        upwardStopReason: scope.upwardStopReason, downwardStopReason: scope.downwardStopReason,
        firstPosition: scope.seenPositions.size ? Array.from(scope.seenPositions).reduce((a, b) => Math.min(a, b), Infinity) : null,
        lastPosition: Array.from(scope.seenPositions).reduce((a, b) => Math.max(a, b), 0) || null,
        expectedTotal: scope.knownTotal || scope.expectedReplies || null,
        stoppedAtTopEdge: scope.stoppedAtTopEdge ?? null, stoppedAtBottomEdge: scope.stoppedAtBottomEdge ?? null,
        scrollAttempts: { ...scope.scrollAttempts } };
    }
    function sortedMessages(scope) {
      return Array.from(scope.messages.values()).sort((a, b) => {
        if (a.order && b.order) return a.order - b.order;
        if (/^\d+$/.test(a.id) && /^\d+$/.test(b.id)) return a.id.length - b.id.length || a.id.localeCompare(b.id);
        return 0;
      });
    }
    function threadContents() { return allContents().filter(isThread); }
    async function closeThread(content) {
      const panel = panelFor(content);
      const button = Array.from(panel.querySelectorAll('[data-test-tag="thread-header-close"], [data-test-tag="chat-header-back"]')).find(visible);
      if (!button) return false;
      button.click();
      const until = Date.now() + threadOpenTimeoutMs;
      while (Date.now() < until) {
        checkChat();
        if (!content.isConnected || !visible(content) || !isThread(content)) return true;
        if (!withinBudget()) return false;
        await sleep(Math.min(delayMs, Math.max(0, maxDurationMs - (Date.now() - startedAt))));
      }
      return false;
    }
    async function collectVisibleThreads() {
      // Opening a panel can remount the main virtual window. Resolve the next
      // button from the current DOM after every discussion, never a stale snapshot.
      while (true) {
        collect(main);
        const current = articles(main);
        for (const article of current) {
          const previous = threads.get(messageId(article, main));
          const badge = article.querySelector('.yamb-message-thread-data .yamb-message-footer-badge');
          const count = badge && /^(\d+)\s+(?:ответ|repl)/i.exec(renderedText(badge));
          if (previous && count) previous.expectedReplies = Math.max(previous.expectedReplies, Number(count[1]));
        }
        const article = current.find(node => !threads.has(messageId(node, main)) &&
          node.querySelector('.yamb-message-thread-data .yamb-message-footer-badge'));
        if (!article) break;
        const badge = article.querySelector('.yamb-message-thread-data .yamb-message-footer-badge');
        if (!badge) continue;
        const rootId = messageId(article, main);
        const count = /^(\d+)\s+(?:ответ|repl)/i.exec(renderedText(badge));
        const expectedReplies = count ? Number(count[1]) : 0;
        const entry = { rootId, expectedReplies, collectedReplies: 0,
          coverage: { startReached: false, endReached: false, complete: false, reason: 'not-opened' } };
        threads.set(rootId, entry);
        if (rootId.startsWith('unidentified-')) { entry.coverage.reason = 'not-opened'; continue; }
        if (!withinBudget() || threadNavigationFailed) { entry.coverage.reason = limitReached ? 'limit' : 'not-opened'; continue; }
        let opened = null;
        try {
          if (!badge.isConnected) { entry.coverage.reason = 'open-failed'; continue; }
          badge.click();
          const until = Date.now() + threadOpenTimeoutMs;
          while (Date.now() < until && withinBudget()) {
            checkChat();
            const panels = threadContents();
            const matching = panels.find(content => {
              const parent = (content.closest('.yamb-conversation') || content.parentElement).querySelector('.ui-InfiniteList-Header article.message');
              return parent && messageId(parent, main) === rootId;
            });
            if (matching) { opened = matching; break; }
            await sleep(Math.min(delayMs, Math.max(0, maxDurationMs - (Date.now() - startedAt))));
          }
          if (!opened) { entry.coverage.reason = limitReached ? 'limit' : 'open-failed'; continue; }
          const scope = createScope(opened, rootId, expectedReplies);
          entry.scope = scope;
          if (!scope.scroller) { entry.coverage.reason = 'no-scroller'; continue; }
          collect(scope);
          scope.startReached = await traverse(scope, -1);
          if (!limitReached) scope.endReached = await traverse(scope, 1);
          collect(scope);
          entry.coverage = coverageFor(scope);
        } catch (error) {
          if (error.chatChanged) throw error;
          entry.coverage = { ...entry.coverage, complete: false, reason: 'thread-error' };
        } finally {
          if (entry.scope) entry.collectedReplies = Array.from(entry.scope.messages.keys()).filter(id => id !== rootId).length;
          // Close even after the global deadline; never leave a hidden main list scrolling.
          const pending = threadContents();
          for (const content of pending) {
            if (!await closeThread(content)) {
              threadNavigationFailed = true;
              main.reason = 'thread-close-failed';
              entry.coverage.complete = false;
              entry.coverage.reason = 'close-failed';
              break;
            }
          }
        }
      }
    }
    try {
      for (const content of threadContents()) {
        if (!await closeThread(content)) return { detected: true, error: 'Не удалось закрыть открытый тред. Закройте его и повторите выгрузку.' };
      }
      collect(main);
      main.startReached = await traverse(main, -1);
      if (!limitReached && !threadNavigationFailed) main.endReached = await traverse(main, 1);
      collect(main);
      const coverage = coverageFor(main);
      const result = sortedMessages(main);
      const byId = new Map(result.map(message => [message.id, message]));
      for (const entry of threads.values()) {
        if (entry.collectedReplies < entry.expectedReplies) {
          entry.coverage.complete = false;
          if (entry.coverage.reason === 'stable-boundaries') entry.coverage.reason = 'missing-replies';
        }
        if (!entry.scope) continue;
        for (const message of sortedMessages(entry.scope)) {
          if (message.id === entry.rootId) continue;
          if (byId.has(message.id)) {
            const previous = byId.get(message.id);
            if (!previous.threadRootId) previous.threadRootId = message.threadRootId;
          } else { result.push(message); byId.set(message.id, message); }
        }
      }
      result.forEach((message, index) => { message.order = index; });
      const threadsSummary = { discovered: threads.size,
        collected: Array.from(threads.values()).filter(entry => entry.collectedReplies > 0).length,
        complete: Array.from(threads.values()).every(entry => entry.coverage.complete) };
      coverage.complete = coverage.complete && threadsSummary.complete && !limitReached && !threadNavigationFailed;
      if (limitReached) coverage.reason = 'limit';
      else if (!threadsSummary.complete && coverage.reason === 'stable-boundaries') coverage.reason = 'threads-incomplete';
      if (!coverage.complete) warnings.add(coverage.reason === 'limit'
        ? 'Достигнут общий предел времени выгрузки. Сохранена только собранная часть истории.'
        : coverage.reason === 'no-progress'
          ? 'Продвижение по истории прекратилось. Сохранена только собранная часть истории.'
          : 'Сохранена доступная история. Полнота переписки и тредов не подтверждена.');
      if (!coverage.startReached) warnings.add('Начало чата не подтверждено: первое сообщение истории не найдено.');
      if (!threadsSummary.complete) warnings.add('Часть ответов в тредах не удалось загрузить. Подробности — в сведениях о тредах.');
      warnings.add('Содержимое файлов и медиа не скачивается.');
      return { detected: true, chatTitle, messages: result, coverage,
        metadata: { chatTitle, exportedAt: new Date().toISOString(), coverage, warnings: Array.from(warnings),
          threadsSummary, threads: Array.from(threads.values(), ({ scope, ...entry }) => entry) } };
    } catch (error) {
      return { error: error.message, detected: true };
    } finally {
      root.__chatDownloaderRunning = false;
    }
  }

  root.ChatExtractor = { run };
})(globalThis);
