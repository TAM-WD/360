"use strict";

const SUPPORTED_HOSTS = new Set([
  'telemost.yandex.ru', 'telemost.360.yandex.ru', 'messenger.yandex.ru', 'messenger.360.yandex.ru',
  'telemost.yandex.com', 'telemost.360.yandex.com', 'messenger.yandex.com', 'messenger.360.yandex.com',
  'messenger.yandex-team.ru', 'telemost.yandex-team.ru'
]);
const sourceTabId = Number(new URLSearchParams(location.search).get('tabId'));
const button = document.getElementById('exportBtn');
const status = document.getElementById('status');
const stopExportButton = document.getElementById('stopExportBtn');
let exportRun = null;
let pendingOrigins = [];
const attachmentsPanel = document.getElementById('attachmentsPanel');
const downloadButton = document.getElementById('downloadAttachmentsBtn');
const showAttachmentsButton = document.getElementById('showAttachmentsBtn');
const attachmentStatus = document.getElementById('attachmentStatus');
const attachmentProgress = document.getElementById('attachmentProgress');
const attachmentHint = document.getElementById('attachmentHint');
const stopAttachmentsButton = document.getElementById('stopAttachmentsBtn');
let attachmentJob = null;
let attachmentState = null;
let attachmentTimer = null;
let attachmentRequestPending = false;
let downloadAttempt = null;
let attachmentStopPending = false;
let attachmentRevision = 0;
const logButton = document.getElementById('downloadLogBtn');
const logSelect = document.getElementById('logRunSelect');
const logStatus = document.getElementById('logStatus');
let diagnosticRecorder = null;
let diagnosticRuns = [];
const localDiagnostics = new Map();
const collectorDiagnostics = new Map();

function newRunId() {
  return globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function recordDiagnostic(event, fields = {}, recorder = diagnosticRecorder) {
  try { recorder?.record(event, fields); } catch { /* Diagnostics must not interrupt an export. */ }
}

function diagnosticError(error) {
  return globalThis.ChatDiagnostics?.errorCode(error) || 'unknown';
}

function updateLogChoices() {
  if (!globalThis.ChatDiagnostics) return;
  const selected = logSelect.value;
  const logs = [...diagnosticRuns];
  for (const [runId, recorder] of localDiagnostics) {
    if (!logs.some(log => log.runId === runId)) logs.push(recorder.snapshot());
  }
  logs.sort((a, b) => String(b.startedAt).localeCompare(String(a.startedAt)));
  const choices = logs.slice(0, 3);
  logSelect.replaceChildren(...choices.map(log => {
    const option = document.createElement('option');
    option.value = log.runId;
    option.textContent = `${new Date(log.startedAt).toLocaleString('ru-RU')} · ${log.version} · ${log.runId.slice(-6)}`;
    return option;
  }));
  if (choices.some(log => log.runId === selected)) logSelect.value = selected;
  logSelect.hidden = choices.length < 2;
  logButton.disabled = !choices.length;
}

function beginDiagnostics(runId) {
  if (!globalThis.ChatDiagnostics) return null;
  try {
    const recorder = ChatDiagnostics.createRecorder({ runId, version: chrome.runtime.getManifest().version, source: 'popup' });
    diagnosticRecorder = recorder;
    localDiagnostics.set(runId, recorder);
    while (localDiagnostics.size > 3) {
      const oldest = localDiagnostics.keys().next().value;
      localDiagnostics.delete(oldest);
      collectorDiagnostics.delete(oldest);
    }
    updateLogChoices();
    logSelect.value = runId;
    logStatus.textContent = 'Журнал записывается локально. Его можно скачать во время работы или после завершения.';
    const agent = globalThis.navigator?.userAgent || '';
    const browser = /Edg\/([\d.]+)/.exec(agent) || /Chrome\/([\d.]+)/.exec(agent) || /Firefox\/([\d.]+)/.exec(agent);
    const family = agent.includes('Edg/') ? 'Edge' : agent.includes('Chrome/') ? 'Chrome' : 'Firefox';
    const platform = /Windows/.test(agent) ? 'Win' : /Macintosh|Mac OS/.test(agent) ? 'Mac' : /Linux/.test(agent) ? 'Linux' : 'Other';
    recordDiagnostic('export-start', { phase: 'detect', browser: browser ? `${family}/${browser[1]}` : 'Other', platform }, recorder);
    return recorder;
  } catch { logStatus.textContent = 'Не удалось начать запись журнала.'; return null; }
}

async function logRequest(message) {
  let timer;
  try {
    return await Promise.race([chrome.runtime.sendMessage(message),
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('diagnostics-timeout')), 1500); })]);
  } finally { clearTimeout(timer); }
}

async function refreshLogList() {
  if (!globalThis.ChatDiagnostics) return;
  try {
    const response = await logRequest({ type: 'diagnostics:list' });
    if (!response?.ok || !Array.isArray(response.logs)) throw new Error('diagnostics-unavailable');
    diagnosticRuns = response.logs;
    updateLogChoices();
  } catch {
    updateLogChoices();
    logStatus.textContent = 'Хранилище журнала недоступно. Доступная часть текущего лога остаётся в этом окне.';
  }
}

logButton.addEventListener('click', async () => {
  const runId = logSelect.value;
  if (!runId || !globalThis.ChatDiagnostics) return;
  logButton.disabled = true;
  try {
    const recorder = localDiagnostics.get(runId);
    if (recorder) recordDiagnostic('log-download', { phase: 'log' }, recorder);
    await recorder?.flush();
    let log = null;
    try {
      const response = await logRequest({ type: 'diagnostics:get', runId });
      if (response?.ok && response.log) log = ChatDiagnostics.sanitizeSnapshot(response.log);
    } catch { /* Keep the locally captured fragment downloadable. */ }
    const snapshots = [recorder?.snapshot(), collectorDiagnostics.get(runId)].filter(Boolean)
      .map(snapshot => ChatDiagnostics.sanitizeSnapshot(snapshot));
    const localSnapshots = snapshots.filter(snapshot => !log || snapshot.transportErrors > 0 ||
      snapshot.unsentEvents > 0 || snapshot.unacknowledgedDroppedEvents > 0 || snapshot.discardedByStore);
    if (!log && !localSnapshots.length) throw new Error('diagnostics-unavailable');
    const report = { format: 'chat-downloader-diagnostics', schemaVersion: 1, savedAt: new Date().toISOString(),
      log, localSnapshots, storageUnavailable: !log };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `chat_downloader_log_${runId}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    logStatus.textContent = !log || localSnapshots.length
      ? 'Лог скачан с доступными локальными фрагментами. В файле отмечены ограничения записи.'
      : 'Лог скачан. Его можно передать для диагностики.';
  } catch {
    logStatus.textContent = 'Не удалось скачать лог. Повторите попытку в этом окне.';
  } finally { logButton.disabled = false; }
});

function resetAttachments() {
  clearTimeout(attachmentTimer);
  attachmentJob = null;
  attachmentState = null;
  downloadAttempt = null;
  attachmentStopPending = false;
  attachmentRevision++;
  stopAttachmentsButton.hidden = true;
  stopAttachmentsButton.disabled = false;
  stopAttachmentsButton.textContent = 'Стоп';
  attachmentsPanel.hidden = true;
  showAttachmentsButton.hidden = true;
  attachmentProgress.hidden = true;
  document.getElementById('attachmentDetails').hidden = true;
  document.getElementById('attachmentFailures').textContent = '';
  attachmentStatus.textContent = '';
  attachmentHint.textContent = '';
}

function prepareAttachments(job) {
  attachmentJob = job;
  if (!job.files.length) return;
  attachmentsPanel.hidden = false;
  downloadButton.disabled = false;
  downloadButton.textContent = `Скачать вложения (${job.files.length})`;
  attachmentStatus.textContent = `Файлы из выгруженных сообщений и тредов: ${job.files.length}.`;
  attachmentHint.textContent = 'Вложения сохранятся в отдельную подпапку «Загрузок». Браузер запросит разрешение при первом скачивании.';
}

function renderAttachmentState(state) {
  if (!attachmentJob || state?.id !== attachmentJob.id) return;
  attachmentState = state;
  const counts = [`Скачано: ${state.completed} из ${state.total}.`];
  if (state.stopped) counts.unshift(state.done ? 'Скачивание остановлено.' : 'Останавливаю скачивание…');
  if (state.cancelled) counts.push(`Отменено: ${state.cancelled}.`);
  if (state.failed) counts.push(`Не удалось: ${state.failed}.`);
  if (state.missing) counts.push(`Без ссылки: ${state.missing}.`);
  if (!state.done) counts.push(`Загружаются: ${state.active}. Ожидают: ${state.queued}.`);
  attachmentStatus.textContent = `${counts.join(' ')}\nПапка в «Загрузках»: ${state.folder}`;
  attachmentProgress.max = state.total;
  attachmentProgress.value = state.completed + state.failed + state.missing + (state.cancelled || 0);
  attachmentProgress.hidden = state.done;
  showAttachmentsButton.hidden = state.firstDownloadId == null;
  const needsPermission = state.permissionRequired && !state.done;
  const remaining = state.failed + (state.cancelled || 0);
  downloadButton.disabled = attachmentRequestPending || attachmentStopPending || !needsPermission && (!state.done || !remaining);
  downloadButton.textContent = needsPermission ? state.stopped ? 'Разрешить остановку' : 'Разрешить скачивание'
    : !state.done ? state.stopped ? 'Останавливаю скачивание…' : 'Скачивание вложений…'
    : state.cancelled ? `Скачать оставшиеся (${remaining})`
    : state.failed ? `Повторить неудачные (${state.failed})` : state.stopped ? 'Скачивание остановлено' : 'Скачивание завершено';
  stopAttachmentsButton.hidden = state.done;
  stopAttachmentsButton.disabled = attachmentStopPending || Boolean(state.stopped && !state.stopError);
  stopAttachmentsButton.textContent = stopAttachmentsButton.disabled ? 'Останавливаю…' : 'Стоп';
  attachmentHint.textContent = state.stopError || (needsPermission ? 'Разрешение на скачивание отозвано. Нажмите кнопку, чтобы продолжить.' : state.done
    ? state.missing ? 'У части вложений нет ссылки на скачивание. Список — выше.' : ''
    : 'Можно закрыть это окно: скачивание продолжится. Если браузер ожидает подтверждения, проверьте список загрузок.');
  const failures = state.failures || [];
  document.getElementById('attachmentDetails').hidden = !failures.length;
  document.getElementById('attachmentFailures').textContent = failures.map(file => `${file.name}: ${file.reason}`).join('\n');
  button.disabled = attachmentRequestPending || attachmentStopPending || !state.done;
}

async function refreshAttachments() {
  const id = attachmentJob?.id;
  const revision = attachmentRevision;
  if (!id) return;
  try {
    const response = await chrome.runtime.sendMessage({ type: 'attachments:status', id });
    if (attachmentJob?.id !== id || revision !== attachmentRevision) return;
    if (!response?.ok || !response.status) throw new Error('Не удалось получить состояние скачивания. Проверьте список загрузок браузера.');
    renderAttachmentState(response.status);
    if (!response.status.done) attachmentTimer = setTimeout(refreshAttachments, 1000);
  } catch {
    if (attachmentJob?.id !== id || revision !== attachmentRevision) return;
    attachmentHint.textContent = 'Не удалось обновить состояние. Проверьте список загрузок браузера; повторная проверка выполняется автоматически.';
    attachmentTimer = setTimeout(refreshAttachments, 5000);
  }
}

downloadButton.addEventListener('click', async () => {
  if (!attachmentJob || attachmentRequestPending || attachmentStopPending || attachmentState && !attachmentState.done && !attachmentState.permissionRequired) return;
  const attempt = { stopped: false, sent: false };
  recordDiagnostic('attachment-request', { phase: 'attachments', outcome: 'started' });
  attachmentRevision++;
  downloadAttempt = attempt;
  attachmentRequestPending = true;
  downloadButton.disabled = true;
  button.disabled = true;
  stopAttachmentsButton.hidden = false;
  stopAttachmentsButton.disabled = false;
  stopAttachmentsButton.textContent = 'Стоп';
  try {
    // Request directly from the click so Chrome retains the user gesture.
    const granted = !attachmentJob.files.some(file => file.url) ||
      await chrome.permissions.request({ permissions: ['downloads'] });
    recordDiagnostic('permission-result', { phase: 'attachments', outcome: granted ? 'granted' : 'denied' });
    if (attempt.stopped) {
      attachmentStatus.textContent = 'Скачивание остановлено до запуска. Новые файлы не загружались.';
      downloadButton.disabled = false;
      button.disabled = false;
      stopAttachmentsButton.hidden = true;
      return;
    }
    if (!granted) throw new Error('Разрешение на скачивание не предоставлено. Нажмите кнопку, чтобы попробовать снова.');
    attempt.sent = true;
    const response = await chrome.runtime.sendMessage(attachmentState?.stopped && !attachmentState.done
      ? { type: 'attachments:stop', id: attachmentJob.id }
      : attachmentState?.failed || attachmentState?.cancelled
        ? { type: 'attachments:retry', id: attachmentJob.id }
        : { type: 'attachments:start', job: attachmentJob });
    if (!response?.ok) throw new Error(response?.error || 'Не удалось начать скачивание вложений.');
    attachmentRequestPending = false;
    // A stop reply may arrive before the older start reply.
    if (!attempt.stopped) renderAttachmentState(response.status);
    else if (attachmentState) renderAttachmentState(attachmentState);
    clearTimeout(attachmentTimer);
    if (!attachmentState?.done) attachmentTimer = setTimeout(refreshAttachments, 1000);
  } catch (error) {
    recordDiagnostic('attachment-ui-error', { phase: 'attachments', errorCode: diagnosticError(error) });
    attachmentStatus.textContent = error.message || 'Не удалось начать скачивание вложений.';
    downloadButton.disabled = false;
    button.disabled = false;
    if (!attachmentState || attachmentState.done) stopAttachmentsButton.hidden = true;
  } finally {
    attachmentRequestPending = false;
    if (downloadAttempt === attempt) downloadAttempt = null;
  }
});

stopAttachmentsButton.addEventListener('click', async () => {
  if (!attachmentJob || attachmentStopPending) return;
  const id = attachmentJob.id;
  recordDiagnostic('attachment-stop-requested', { phase: 'attachments' });
  attachmentRevision++;
  if (downloadAttempt) downloadAttempt.stopped = true;
  stopAttachmentsButton.disabled = true;
  stopAttachmentsButton.textContent = 'Останавливаю…';
  if (downloadAttempt && !downloadAttempt.sent) {
    attachmentStatus.textContent = 'Запрошена остановка. Новые загрузки не будут запущены.';
    return;
  }
  attachmentStopPending = true;
  downloadButton.disabled = true;
  clearTimeout(attachmentTimer);
  try {
    const response = await chrome.runtime.sendMessage({ type: 'attachments:stop', id });
    if (!response?.ok) throw new Error(response?.error || 'Не удалось остановить скачивание. Повторите попытку.');
    if (attachmentJob?.id !== id) return;
    attachmentStopPending = false;
    renderAttachmentState(response.status);
    if (!response.status.done) attachmentTimer = setTimeout(refreshAttachments, 1000);
  } catch (error) {
    if (attachmentJob?.id !== id) return;
    recordDiagnostic('attachment-ui-error', { phase: 'attachments', errorCode: diagnosticError(error) });
    attachmentHint.textContent = error.message || 'Не удалось остановить скачивание. Проверьте загрузки браузера.';
    stopAttachmentsButton.disabled = false;
    stopAttachmentsButton.textContent = 'Стоп';
    attachmentTimer = setTimeout(refreshAttachments, 1000);
  } finally {
    attachmentStopPending = false;
  }
});

showAttachmentsButton.addEventListener('click', async () => {
  if (!attachmentJob) return;
  try {
    const response = await chrome.runtime.sendMessage({ type: 'attachments:show', id: attachmentJob.id });
    if (!response?.ok) throw new Error(response?.error);
  } catch {
    attachmentHint.textContent = 'Не удалось открыть папку. Найдите сохранённые файлы в списке загрузок браузера.';
  }
});

function supportedURL(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && (SUPPORTED_HOSTS.has(url.hostname) ||
      ['yandex.ru', 'yandex.com'].includes(url.hostname) && /^\/chat(?:\/|$)/.test(url.pathname));
  } catch { return false; }
}

function setStatus(message, type = 'info') {
  status.style.display = 'block';
  status.className = type;
  status.textContent = message;
}

async function getSourceTab() {
  const tab = sourceTabId ? await chrome.tabs.get(sourceTabId)
    : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (!tab || !supportedURL(tab.url)) throw new Error('Откройте переписку в Яндекс Мессенджере или Телемосте.');
  return tab;
}

async function detectChat(tabId, recorder) {
  // Isolate inaccessible third-party frames instead of failing an allFrames injection.
  const frames = await chrome.webNavigation.getAllFrames({ tabId }) || [{ frameId: 0 }];
  const inspected = [];
  const inaccessibleOrigins = new Set();
  let injectionError = '';
  for (const frame of frames) {
    if (frame.frameId !== 0 && !supportedURL(frame.url)) continue;
    const target = { tabId, frameIds: [frame.frameId] };
    try {
      await chrome.scripting.executeScript({ target, files: ['diagnostics.js', 'export-model.js', 'chat-extractor.js'] });
      const result = await chrome.scripting.executeScript({
        target,
        func: async () => ({ ...await globalThis.ChatExtractor.run({ mode: 'inspect' }), url: location.href })
      });
      inspected.push(...result);
      recordDiagnostic('frame-inspected', { phase: 'detect', frameId: frame.frameId,
        outcome: result.some(item => item.result?.detected) ? 'success' : 'empty' }, recorder);
    } catch (error) {
      recordDiagnostic('frame-inaccessible', { phase: 'detect', frameId: frame.frameId, errorCode: diagnosticError(error) }, recorder);
      injectionError = error.message;
      if (frame.frameId !== 0 && supportedURL(frame.url)) inaccessibleOrigins.add(`${new URL(frame.url).origin}/*`);
    }
  }
  const found = inspected.filter(item => item.result && item.result.detected);
  if (found.length > 1) throw new Error('На странице открыто несколько чатов. Оставьте одну переписку и повторите выгрузку.');
  if (found.length) return found[0];
  pendingOrigins = [];
  for (const origin of inaccessibleOrigins) {
    if (!await chrome.permissions.contains({ origins: [origin] })) pendingOrigins.push(origin);
  }
  if (pendingOrigins.length) {
    button.textContent = 'Разрешить доступ к встроенному чату';
    throw new Error('Чат встроен с другого адреса. Нажмите кнопку, чтобы разрешить выгрузку из этого чата.');
  }
  throw new Error(inaccessibleOrigins.size ? 'Встроенный чат недоступен для расширения. Откройте его в отдельной вкладке.'
    : inspected.find(item => item.result?.error)?.result.error || injectionError || 'Чат не найден. Откройте переписку и дождитесь загрузки сообщений.');
}

function filename() {
  const now = new Date();
  const pad = value => String(value).padStart(2, '0');
  return `chat_export_${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}.xlsx`;
}

stopExportButton.addEventListener('click', async () => {
  const run = exportRun;
  if (!run || run.stopRequested) return;
  run.stopRequested = true;
  recordDiagnostic('export-stop-requested', { phase: run.phase }, run.recorder);
  stopExportButton.disabled = true;
  stopExportButton.textContent = 'Останавливаю…';
  setStatus('Останавливаю экспорт. Уже собранные сообщения будут сохранены.');
  if (!run.target) return;
  try {
    const results = await chrome.scripting.executeScript({ target: run.target,
      func: id => globalThis.ChatExtractor?.cancel(id) === true, args: [run.id] });
    if (!results[0]?.result && exportRun === run) throw new Error('Не удалось передать команду остановки. Повторите попытку.');
  } catch (error) {
    if (exportRun !== run) return;
    recordDiagnostic('export-stop-error', { phase: run.phase, errorCode: diagnosticError(error) }, run.recorder);
    run.stopRequested = false;
    stopExportButton.disabled = false;
    stopExportButton.textContent = 'Стоп';
    setStatus('Не удалось остановить экспорт. Проверьте, что вкладка с чатом открыта, и нажмите «Стоп» ещё раз.', 'error');
  }
});

async function exportChat() {
  if (exportRun) return;
  const run = { id: newRunId(), stopRequested: false, target: null, phase: 'detect', sourceValid: false };
  run.recorder = beginDiagnostics(run.id);
  exportRun = run;
  button.disabled = true;
  stopExportButton.hidden = false;
  stopExportButton.disabled = false;
  stopExportButton.textContent = 'Стоп';
  resetAttachments();
  document.getElementById('warningBox').style.display = 'block';
  document.getElementById('statsContainer').style.display = 'none';
  try {
    const tab = await getSourceTab();
    run.sourceValid = true;
    recordDiagnostic('source-detected', { phase: 'detect', host: new URL(tab.url).hostname }, run.recorder);
    if (run.stopRequested) { setStatus('Экспорт остановлен. Сообщения ещё не собраны.'); return; }
    setStatus('Поиск открытой переписки…');
    const frame = await detectChat(tab.id, run.recorder);
    if (run.stopRequested) { setStatus('Экспорт остановлен. Сообщения ещё не собраны.'); return; }
    run.target = { tabId: tab.id, frameIds: [frame.frameId] };
    run.phase = 'collect';
    recordDiagnostic('collect-start', { phase: 'collect', frameId: frame.frameId }, run.recorder);
    setStatus('Собираю историю и ответы в тредах. Не закрывайте вкладку с чатом и это окно; можно переключиться в другое приложение.');
    const results = await chrome.scripting.executeScript({
      target: run.target,
      func: (expectedURL, runId, version) => !expectedURL || location.href === expectedURL
        ? globalThis.ChatExtractor.run({ mode: 'collect', runId, version })
        : { error: 'Чат изменился перед началом выгрузки. Повторите выгрузку в нужной переписке.' },
      args: [frame.result.url, run.id, chrome.runtime.getManifest().version]
    });
    const result = results[0]?.result;
    if (result?.diagnostics && globalThis.ChatDiagnostics) {
      collectorDiagnostics.set(run.id, ChatDiagnostics.sanitizeSnapshot(result.diagnostics));
    }
    if (!result) throw new Error('Страница не вернула результат. Проверьте, что вкладка с чатом открыта.');
    if (result.error) throw new Error(result.error);
    if (!result.messages.length) {
      recordDiagnostic('export-empty', { phase: 'collect', reason: result.coverage?.reason }, run.recorder);
      if (result.coverage?.reason === 'user-stopped') { setStatus('Экспорт остановлен. Сообщения ещё не собраны.'); return; }
      throw new Error('В открытой переписке не найдено сообщений.');
    }
    const coverage = ChatExport.classifyCoverage(result.coverage, result.metadata);
    const startConfirmed = coverage.startReached === true;
    recordDiagnostic('collect-finished', { phase: 'collect', messageCount: result.messages.length,
      complete: coverage.complete, startReached: coverage.startReached, endReached: coverage.endReached,
      reason: coverage.reason, coverageStatus: coverage.status }, run.recorder);
    run.phase = 'workbook';
    const data = ChatExport.buildExportData(result.messages, {
      ...result.metadata, coverage, version: chrome.runtime.getManifest().version
    });
    const exportFilename = filename();
    const job = AttachmentDownloads.createJob(data.messages, exportFilename);
    job.diagnosticRunId = run.id;
    XLSX.writeFile(ChatExport.buildWorkbook(data, XLSX), exportFilename);
    recordDiagnostic('export-saved', { phase: 'workbook', outcome: coverage.status === 'complete' ? 'success' : coverage.status,
      coverageStatus: coverage.status,
      messageCount: data.stats.messages, threadCount: data.threadGroups.length, attachmentCount: data.stats.attachments }, run.recorder);
    document.getElementById('warningBox').style.display = 'none';
    prepareAttachments(job);
    document.getElementById('statsContainer').style.display = 'block';
    document.getElementById('messagesCount').textContent = data.stats.messages;
    document.getElementById('plainMessagesCount').textContent = data.stats.questions;
    document.getElementById('answersCount').textContent = data.stats.answers;
    document.getElementById('threadsCount').textContent = data.stats.threads;
    document.getElementById('threadRepliesCount').textContent = data.stats.threadReplies;
    document.getElementById('systemCount').textContent = data.stats.system;
    document.getElementById('attachmentsCount').textContent = data.stats.attachments;
    const beginning = startConfirmed ? 'Начало чата подтверждено.' : 'Начало чата не подтверждено.';
    const stopDetails = [];
    if (coverage.statusReason === 'user-stopped') stopDetails.push('Экспорт остановлен пользователем.');
    if (coverage.statusReason === 'limit') {
      stopDetails.push('Достигнут общий предел времени выгрузки.');
    }
    if (coverage.status === 'complete') {
      setStatus(`Выгрузка завершена. Сохранено сообщений: ${data.stats.messages}. ${beginning} История чата собрана.`, 'success');
    } else if (coverage.status === 'unverified') {
      setStatus(`Выгрузка завершена. Сохранено сообщений: ${data.stats.messages}. ${beginning} Полнота истории автоматически не подтверждена. Подробности — на листе «Статистика».`, 'success');
    } else {
      if (!stopDetails.length) stopDetails.push('Есть ограничения сбора сообщений или тредов.');
      setStatus(`Сохранено сообщений: ${data.stats.messages}. ${beginning} ${stopDetails.join(' ')} Сохранена собранная часть истории. Подробности — на листе «Статистика».`, 'info');
    }
  } catch (error) {
    recordDiagnostic('export-error', { phase: run.phase, errorCode: diagnosticError(error) }, run.recorder);
    setStatus(error.message || 'Не удалось выгрузить переписку.', 'error');
  } finally {
    if (run.recorder) void run.recorder.flush().then(refreshLogList).catch(() => {});
    if (exportRun === run) exportRun = null;
    stopExportButton.hidden = true;
    if (run.stopRequested) document.getElementById('warningBox').style.display = 'none';
    button.disabled = !run.sourceValid;
    if (!pendingOrigins.length) button.textContent = 'Начать новую выгрузку';
  }
}

button.addEventListener('click', async () => {
  if (!sourceTabId) {
    button.disabled = true;
    try {
      const tab = await getSourceTab();
      // A browser-action popup closes on blur. This window keeps the result alive.
      await chrome.windows.create({ url: `${chrome.runtime.getURL('popup.html')}?tabId=${tab.id}`,
        type: 'popup', width: 430, height: 650 });
      window.close();
    } catch (error) {
      setStatus(error.message, 'error');
      button.disabled = false;
    }
    return;
  }
  if (pendingOrigins.length) {
    try {
      const granted = await chrome.permissions.request({ origins: pendingOrigins });
      recordDiagnostic('permission-result', { phase: 'permissions', outcome: granted ? 'granted' : 'denied' });
      if (!granted) { setStatus('Доступ к встроенному чату не предоставлен.', 'error'); return; }
      pendingOrigins = [];
    } catch (error) { setStatus(error.message, 'error'); return; }
  }
  await exportChat();
});

window.addEventListener('DOMContentLoaded', async () => {
  document.getElementById('version').textContent = chrome.runtime.getManifest().version;
  document.getElementById('warningBox').style.display = 'block';
  void refreshLogList();
  try {
    if (sourceTabId) await exportChat();
    else {
      await getSourceTab();
      setStatus('Откройте нужную переписку и начните выгрузку. Для сбора истории откроется отдельное окно.');
    }
  } catch (error) {
    button.disabled = true;
    setStatus(error.message, 'error');
  }
});
