"use strict";

const SUPPORTED_HOSTS = new Set([
  'telemost.yandex.ru', 'telemost.360.yandex.ru', 'messenger.yandex.ru', 'messenger.360.yandex.ru',
  'telemost.yandex.com', 'telemost.360.yandex.com', 'messenger.yandex.com', 'messenger.360.yandex.com',
  'messenger.yandex-team.ru', 'telemost.yandex-team.ru'
]);
const sourceTabId = Number(new URLSearchParams(location.search).get('tabId'));
const button = document.getElementById('exportBtn');
const status = document.getElementById('status');
let pendingOrigins = [];
const attachmentsPanel = document.getElementById('attachmentsPanel');
const downloadButton = document.getElementById('downloadAttachmentsBtn');
const showAttachmentsButton = document.getElementById('showAttachmentsBtn');
const attachmentStatus = document.getElementById('attachmentStatus');
const attachmentProgress = document.getElementById('attachmentProgress');
const attachmentHint = document.getElementById('attachmentHint');
let attachmentJob = null;
let attachmentState = null;
let attachmentTimer = null;
let attachmentRequestPending = false;

function resetAttachments() {
  clearTimeout(attachmentTimer);
  attachmentJob = null;
  attachmentState = null;
  attachmentsPanel.hidden = true;
  showAttachmentsButton.hidden = true;
  attachmentProgress.hidden = true;
  document.getElementById('attachmentDetails').hidden = true;
  document.getElementById('attachmentFailures').textContent = '';
  attachmentStatus.textContent = '';
  attachmentHint.textContent = '';
}

function prepareAttachments(job) {
  attachmentJob = job;
  if (!job.files.length) return;
  attachmentsPanel.hidden = false;
  downloadButton.disabled = false;
  downloadButton.textContent = `Скачать вложения (${job.files.length})`;
  attachmentStatus.textContent = `Файлы из выгруженных сообщений и тредов: ${job.files.length}.`;
  attachmentHint.textContent = 'Вложения сохранятся в отдельную подпапку «Загрузок». Браузер запросит разрешение при первом скачивании.';
}

function renderAttachmentState(state) {
  if (!attachmentJob || state?.id !== attachmentJob.id) return;
  attachmentState = state;
  const counts = [`Скачано: ${state.completed} из ${state.total}.`];
  if (state.failed) counts.push(`Не удалось: ${state.failed}.`);
  if (state.missing) counts.push(`Без ссылки: ${state.missing}.`);
  if (!state.done) counts.push(`Загружаются: ${state.active}. Ожидают: ${state.queued}.`);
  attachmentStatus.textContent = `${counts.join(' ')}\nПапка в «Загрузках»: ${state.folder}`;
  attachmentProgress.max = state.total;
  attachmentProgress.value = state.completed + state.failed + state.missing;
  attachmentProgress.hidden = state.done;
  showAttachmentsButton.hidden = state.firstDownloadId == null;
  const needsPermission = state.permissionRequired && !state.done;
  downloadButton.disabled = attachmentRequestPending || !needsPermission && (!state.done || !state.failed);
  downloadButton.textContent = needsPermission ? 'Разрешить скачивание' : !state.done ? 'Скачивание вложений…'
    : state.failed ? `Повторить неудачные (${state.failed})` : 'Скачивание завершено';
  attachmentHint.textContent = needsPermission ? 'Разрешение на скачивание отозвано. Нажмите кнопку, чтобы продолжить.' : state.done
    ? state.missing ? 'У части вложений нет ссылки на скачивание. Список — выше.' : ''
    : 'Можно закрыть это окно: скачивание продолжится. Если браузер ожидает подтверждения, проверьте список загрузок.';
  const failures = state.failures || [];
  document.getElementById('attachmentDetails').hidden = !failures.length;
  document.getElementById('attachmentFailures').textContent = failures.map(file => `${file.name}: ${file.reason}`).join('\n');
  button.disabled = attachmentRequestPending || !state.done;
}

async function refreshAttachments() {
  const id = attachmentJob?.id;
  if (!id) return;
  try {
    const response = await chrome.runtime.sendMessage({ type: 'attachments:status', id });
    if (attachmentJob?.id !== id) return;
    if (!response?.ok || !response.status) throw new Error('Не удалось получить состояние скачивания. Проверьте список загрузок браузера.');
    renderAttachmentState(response.status);
    if (!response.status.done) attachmentTimer = setTimeout(refreshAttachments, 1000);
  } catch {
    if (attachmentJob?.id !== id) return;
    attachmentHint.textContent = 'Не удалось обновить состояние. Проверьте список загрузок браузера; повторная проверка выполняется автоматически.';
    attachmentTimer = setTimeout(refreshAttachments, 5000);
  }
}

downloadButton.addEventListener('click', async () => {
  if (!attachmentJob || attachmentRequestPending || attachmentState && !attachmentState.done && !attachmentState.permissionRequired) return;
  attachmentRequestPending = true;
  downloadButton.disabled = true;
  button.disabled = true;
  try {
    // Request directly from the click so Chrome retains the user gesture.
    const granted = !attachmentJob.files.some(file => file.url) ||
      await chrome.permissions.request({ permissions: ['downloads'] });
    if (!granted) throw new Error('Разрешение на скачивание не предоставлено. Нажмите кнопку, чтобы попробовать снова.');
    const response = await chrome.runtime.sendMessage(attachmentState?.failed
      ? { type: 'attachments:retry', id: attachmentJob.id }
      : { type: 'attachments:start', job: attachmentJob });
    if (!response?.ok) throw new Error(response?.error || 'Не удалось начать скачивание вложений.');
    attachmentRequestPending = false;
    renderAttachmentState(response.status);
    clearTimeout(attachmentTimer);
    if (!response.status?.done) attachmentTimer = setTimeout(refreshAttachments, 1000);
  } catch (error) {
    attachmentStatus.textContent = error.message || 'Не удалось начать скачивание вложений.';
    downloadButton.disabled = false;
    button.disabled = false;
  } finally {
    attachmentRequestPending = false;
  }
});

showAttachmentsButton.addEventListener('click', async () => {
  if (!attachmentJob) return;
  try {
    const response = await chrome.runtime.sendMessage({ type: 'attachments:show', id: attachmentJob.id });
    if (!response?.ok) throw new Error(response?.error);
  } catch {
    attachmentHint.textContent = 'Не удалось открыть папку. Найдите сохранённые файлы в списке загрузок браузера.';
  }
});

function supportedURL(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && (SUPPORTED_HOSTS.has(url.hostname) ||
      ['yandex.ru', 'yandex.com'].includes(url.hostname) && /^\/chat(?:\/|$)/.test(url.pathname));
  } catch { return false; }
}

function setStatus(message, type = 'info') {
  status.style.display = 'block';
  status.className = type;
  status.textContent = message;
}

async function getSourceTab() {
  const tab = sourceTabId ? await chrome.tabs.get(sourceTabId)
    : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (!tab || !supportedURL(tab.url)) throw new Error('Откройте переписку в Яндекс Мессенджере или Телемосте.');
  return tab;
}

async function detectChat(tabId) {
  // Isolate inaccessible third-party frames instead of failing an allFrames injection.
  const frames = await chrome.webNavigation.getAllFrames({ tabId }) || [{ frameId: 0 }];
  const inspected = [];
  const inaccessibleOrigins = new Set();
  let injectionError = '';
  for (const frame of frames) {
    if (frame.frameId !== 0 && !supportedURL(frame.url)) continue;
    const target = { tabId, frameIds: [frame.frameId] };
    try {
      await chrome.scripting.executeScript({ target, files: ['chat-extractor.js'] });
      const result = await chrome.scripting.executeScript({
        target,
        func: async () => ({ ...await globalThis.ChatExtractor.run({ mode: 'inspect' }), url: location.href })
      });
      inspected.push(...result);
    } catch (error) {
      injectionError = error.message;
      if (frame.frameId !== 0 && supportedURL(frame.url)) inaccessibleOrigins.add(`${new URL(frame.url).origin}/*`);
    }
  }
  const found = inspected.filter(item => item.result && item.result.detected);
  if (found.length > 1) throw new Error('На странице открыто несколько чатов. Оставьте одну переписку и повторите выгрузку.');
  if (found.length) return found[0];
  pendingOrigins = [];
  for (const origin of inaccessibleOrigins) {
    if (!await chrome.permissions.contains({ origins: [origin] })) pendingOrigins.push(origin);
  }
  if (pendingOrigins.length) {
    button.textContent = 'Разрешить доступ к встроенному чату';
    throw new Error('Чат встроен с другого адреса. Нажмите кнопку, чтобы разрешить выгрузку из этого чата.');
  }
  throw new Error(inaccessibleOrigins.size ? 'Встроенный чат недоступен для расширения. Откройте его в отдельной вкладке.'
    : inspected.find(item => item.result?.error)?.result.error || injectionError || 'Чат не найден. Откройте переписку и дождитесь загрузки сообщений.');
}

function filename() {
  const now = new Date();
  const pad = value => String(value).padStart(2, '0');
  return `chat_export_${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}.xlsx`;
}

async function exportChat() {
  button.disabled = true;
  resetAttachments();
  document.getElementById('warningBox').style.display = 'block';
  document.getElementById('statsContainer').style.display = 'none';
  try {
    const tab = await getSourceTab();
    setStatus('Поиск открытой переписки…');
    const frame = await detectChat(tab.id);
    setStatus('Собираю историю и ответы в тредах. Не закрывайте вкладку с чатом и это окно; можно переключиться в другое приложение.');
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id, frameIds: [frame.frameId] },
      func: expectedURL => !expectedURL || location.href === expectedURL
        ? globalThis.ChatExtractor.run({ mode: 'collect' })
        : { error: 'Чат изменился перед началом выгрузки. Повторите выгрузку в нужной переписке.' },
      args: [frame.result.url]
    });
    const result = results[0]?.result;
    if (!result) throw new Error('Страница не вернула результат. Проверьте, что вкладка с чатом открыта.');
    if (result.error) throw new Error(result.error);
    if (!result.messages.length) throw new Error('В открытой переписке не найдено сообщений.');
    const coverage = { ...result.coverage };
    const startConfirmed = coverage.startReached === true && Boolean(coverage.startEvidence);
    coverage.startReached = startConfirmed;
    coverage.complete = coverage.complete === true && startConfirmed && coverage.endReached === true;
    const data = ChatExport.buildExportData(result.messages, {
      ...result.metadata, coverage, version: chrome.runtime.getManifest().version
    });
    const exportFilename = filename();
    const job = AttachmentDownloads.createJob(data.messages, exportFilename);
    XLSX.writeFile(ChatExport.buildWorkbook(data, XLSX), exportFilename);
    document.getElementById('warningBox').style.display = 'none';
    prepareAttachments(job);
    document.getElementById('statsContainer').style.display = 'block';
    document.getElementById('messagesCount').textContent = data.stats.messages;
    document.getElementById('plainMessagesCount').textContent = data.stats.questions;
    document.getElementById('answersCount').textContent = data.stats.answers;
    document.getElementById('threadsCount').textContent = data.stats.threads;
    document.getElementById('threadRepliesCount').textContent = data.stats.threadReplies;
    document.getElementById('systemCount').textContent = data.stats.system;
    document.getElementById('attachmentsCount').textContent = data.stats.attachments;
    const beginning = startConfirmed ? 'Начало чата подтверждено.' : 'Начало чата не подтверждено.';
    const stopDetails = [];
    if (coverage.upwardStopReason === 'no-progress') stopDetails.push('Загрузка старых сообщений остановилась: нет продвижения вверх.');
    if (coverage.downwardStopReason === 'no-progress') stopDetails.push('Загрузка новых сообщений остановилась: нет продвижения вниз.');
    if (coverage.reason === 'limit' || coverage.upwardStopReason === 'limit' || coverage.downwardStopReason === 'limit') {
      stopDetails.push('Достигнут общий предел времени выгрузки.');
    }
    setStatus(coverage.complete
      ? `Сохранено сообщений: ${data.stats.messages}. ${beginning} История чата собрана.`
      : `Сохранено сообщений: ${data.stats.messages}. ${beginning} ${stopDetails.join(' ')} Выгружена доступная часть истории. Подробности — на листе «Статистика».`.replace(/ +/g, ' '),
    coverage.complete ? 'success' : 'info');
  } catch (error) {
    setStatus(error.message || 'Не удалось выгрузить переписку.', 'error');
  } finally {
    button.disabled = false;
    if (!pendingOrigins.length) button.textContent = 'Начать новую выгрузку';
  }
}

button.addEventListener('click', async () => {
  if (!sourceTabId) {
    button.disabled = true;
    try {
      const tab = await getSourceTab();
      // A browser-action popup closes on blur. This window keeps the result alive.
      await chrome.windows.create({ url: `${chrome.runtime.getURL('popup.html')}?tabId=${tab.id}`,
        type: 'popup', width: 430, height: 650 });
      window.close();
    } catch (error) {
      setStatus(error.message, 'error');
      button.disabled = false;
    }
    return;
  }
  if (pendingOrigins.length) {
    try {
      const granted = await chrome.permissions.request({ origins: pendingOrigins });
      if (!granted) { setStatus('Доступ к встроенному чату не предоставлен.', 'error'); return; }
      pendingOrigins = [];
    } catch (error) { setStatus(error.message, 'error'); return; }
  }
  await exportChat();
});

window.addEventListener('DOMContentLoaded', async () => {
  document.getElementById('version').textContent = chrome.runtime.getManifest().version;
  document.getElementById('warningBox').style.display = 'block';
  try {
    await getSourceTab();
    if (sourceTabId) await exportChat();
    else setStatus('Откройте нужную переписку и начните выгрузку. Для сбора истории откроется отдельное окно.');
  } catch (error) {
    button.disabled = true;
    setStatus(error.message, 'error');
  }
});
