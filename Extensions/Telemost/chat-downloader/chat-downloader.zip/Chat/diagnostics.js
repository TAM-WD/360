(function (root, factory) {
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.ChatDiagnostics = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (root) {
  'use strict';

  const SCHEMA_VERSION = 1;
  const STORAGE_KEY = 'chatDownloaderDiagnosticsV1';
  const MAX_EVENTS = 3000;
  const MAX_BYTES = 1000000;
  const MAX_EVENT_BYTES = MAX_BYTES - 65536;
  const KEEP_FIRST = 25;
  const MAX_RUNS = 3;
  const MAX_STREAMS = 128;
  const FLUSH_TIMEOUT = 1500;
  const SOURCES = new Set(['popup', 'collector', 'downloads']);
  const EVENTS = new Set([
    'export-start', 'source-detected', 'frame-inspected', 'frame-inaccessible', 'collect-start',
    'collect-finished', 'export-saved', 'export-empty', 'export-error', 'export-stop-requested',
    'export-stop-error', 'permission-result', 'attachment-request', 'attachment-stop-requested',
    'attachment-ui-error', 'log-download',
    'collector.start', 'collector.container', 'collector.snapshot', 'collector.scroll',
    'collector.pass-start', 'collector.pass-end', 'collector.thread-open', 'collector.thread-close',
    'collector.thread-finish', 'collector.cancel', 'collector.error', 'collector.finish',
    'downloads.start', 'downloads.retry', 'downloads.stop', 'downloads.launch', 'downloads.state',
    'downloads.recover', 'downloads.permission', 'downloads.error'
  ]);
  const REASONS = new Set([
    'not-started', 'running', 'confirmed-start', 'confirmed-end', 'stable-boundaries', 'limit',
    'no-progress', 'gaps', 'threads-incomplete', 'missing-replies', 'open-failed', 'not-opened',
    'no-scroller', 'thread-error', 'close-failed', 'thread-close-failed', 'user-stopped',
    'no-root', 'ambiguous', 'busy', 'chat-changed', 'panel-closed', 'thread-changed',
    'unavailable', 'timeout', 'completed', 'missing-download', 'login-page', 'interrupted',
    'unconfirmed-start', 'erased', 'unknown', 'empty'
  ]);
  const ERROR_CODES = new Set([
    'permission-denied', 'tab-unavailable', 'frame-unavailable', 'network-error', 'storage-error',
    'timeout', 'aborted', 'type-error', 'syntax-error', 'error', 'unknown',
    'FILE_FAILED', 'FILE_ACCESS_DENIED', 'FILE_NO_SPACE', 'FILE_NAME_TOO_LONG', 'FILE_TOO_LARGE',
    'FILE_VIRUS_INFECTED', 'FILE_TRANSIENT_ERROR', 'FILE_BLOCKED', 'FILE_SECURITY_CHECK_FAILED',
    'FILE_TOO_SHORT', 'FILE_HASH_MISMATCH', 'FILE_SAME_AS_SOURCE', 'NETWORK_FAILED',
    'NETWORK_TIMEOUT', 'NETWORK_DISCONNECTED', 'NETWORK_SERVER_DOWN', 'NETWORK_INVALID_REQUEST',
    'SERVER_FAILED', 'SERVER_NO_RANGE', 'SERVER_BAD_CONTENT', 'SERVER_UNAUTHORIZED',
    'SERVER_CERT_PROBLEM', 'SERVER_FORBIDDEN', 'SERVER_UNREACHABLE', 'SERVER_CONTENT_LENGTH_MISMATCH',
    'SERVER_CROSS_ORIGIN_REDIRECT', 'USER_CANCELED', 'USER_SHUTDOWN', 'CRASH'
  ]);
  const ENUMS = {
    phase: new Set(['start', 'before', 'after', 'finish', 'error', 'detect', 'collect', 'workbook',
      'attachments', 'permissions', 'log', 'retry', 'stop', 'storage', 'download', 'cancel',
      'recovery', 'filename', 'permission', 'dispatch']),
    reason: REASONS,
    adapter: new Set(['infinite-list', 'native-scroll', 'unknown']),
    direction: new Set(['up', 'down']), scope: new Set(['main', 'thread']),
    idSource: new Set(['explicit', 'label', 'element', 'position', 'anonymous', 'mixed']),
    method: new Set(['wheel', 'native', 'fallback']),
    host: new Set(['telemost.yandex.ru', 'telemost.360.yandex.ru', 'messenger.yandex.ru',
      'messenger.360.yandex.ru', 'telemost.yandex.com', 'telemost.360.yandex.com',
      'messenger.yandex.com', 'messenger.360.yandex.com', 'messenger.yandex-team.ru',
      'telemost.yandex-team.ru', 'yandex.ru', 'yandex.com']),
    platform: new Set(['Win', 'Mac', 'Linux', 'Other']),
    outcome: new Set(['started', 'success', 'empty', 'failed', 'denied', 'granted', 'partial',
      'error', 'stopped', 'accepted', 'restored', 'requested']),
    evidence: new Set(['first-position', 'total-count', 'thread-reply-count', 'none']),
    errorCode: ERROR_CODES,
    state: new Set(['pending', 'starting', 'in_progress', 'complete', 'failed', 'cancelled', 'missing', 'interrupted', 'paused']),
    previousState: new Set(['pending', 'starting', 'in_progress', 'complete', 'failed', 'cancelled', 'missing', 'interrupted', 'paused'])
  };
  const NUMBER_FIELDS = new Set([
    'elapsedMs', 'delayMs', 'stableRounds', 'maxDurationMs', 'noProgressTimeoutMs', 'threadOpenTimeoutMs',
    'visibleCount', 'articleCount', 'newMessages', 'parsedCount', 'skippedCount', 'duplicateCount',
    'messageCount', 'seenPositionCount', 'minPosition', 'maxPosition', 'firstPosition', 'lastPosition',
    'expectedTotal', 'scrollTop', 'scrollHeight', 'clientHeight', 'scrollTopBefore', 'scrollTopAfter',
    'delta', 'stableCount', 'noProgressMs', 'wheelAttempts', 'nativeAttempts', 'expectedReplies',
    'collectedReplies', 'threadCount', 'totalMessages', 'idExplicitCount', 'idLabelCount',
    'idElementCount', 'idPositionCount', 'idAnonymousCount', 'idCollisionCount',
    'idPositionChangedCount', 'collectedPositionCount', 'newPositions', 'frameId', 'count',
    'attachmentCount', 'completed', 'failed', 'cancelled', 'missing', 'active', 'queued', 'total'
  ]);
  const BOOLEAN_FIELDS = new Set(['algorithmProgress', 'loading', 'visible', 'connected', 'atEdge',
    'startReached', 'endReached', 'complete', 'stopped', 'hidden', 'nativeUsed']);
  const REF_FIELDS = new Set(['threadRef', 'firstRef', 'lastRef', 'fileRef']);
  const validRunId = value => typeof value === 'string' && /^[a-z0-9-]{8,80}$/i.test(value);
  const validVersion = value => typeof value === 'string' && /^\d{1,3}(?:\.\d{1,5}){0,3}$/.test(value);
  const validStream = value => typeof value === 'string' && /^[a-f0-9]{16}$/.test(value);
  const natural = value => Number.isSafeInteger(value) && value >= 0 ? value : 0;
  function time(value, fallback = '') {
    return typeof value === 'string' && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(value) &&
      Number.isFinite(Date.parse(value)) ? value : fallback;
  }
  function ref(value) {
    if (value == null || value === '') return '';
    const input = String(value).slice(0, 4096);
    let a = 2166136261, b = 2246822507;
    for (let i = 0; i < input.length; i++) {
      a = Math.imul(a ^ input.charCodeAt(i), 16777619);
      b = Math.imul(b ^ input.charCodeAt(i), 3266489909);
    }
    return `h${(a >>> 0).toString(16).padStart(8, '0')}${(b >>> 0).toString(16).padStart(8, '0')}`;
  }
  function errorCode(error) {
    try {
      if (typeof error === 'string' && ERROR_CODES.has(error)) return error;
      if (ERROR_CODES.has(error?.code)) return error.code;
      const name = String(error?.name || '');
      const message = String(error?.message || '').toLowerCase();
      if (name === 'AbortError') return 'aborted';
      if (name === 'TimeoutError' || /timed? ?out|timeout/.test(message)) return 'timeout';
      if (/no tab|tab.*closed|tab.*not found/.test(message)) return 'tab-unavailable';
      if (/frame.*removed|frame.*not found/.test(message)) return 'frame-unavailable';
      if (/quota|storage/.test(message)) return 'storage-error';
      if (/permission|access|denied|not allowed/.test(message)) return 'permission-denied';
      if (/network|fetch|disconnected/.test(message)) return 'network-error';
      if (name === 'TypeError') return 'type-error';
      if (name === 'SyntaxError') return 'syntax-error';
      return name === 'Error' ? 'error' : 'unknown';
    } catch { return 'unknown'; }
  }
  function fields(input) {
    const output = {};
    if (!input || typeof input !== 'object' || Array.isArray(input)) return output;
    for (const key of Object.keys(input)) {
      let value;
      try { value = input[key]; } catch { continue; }
      if (NUMBER_FIELDS.has(key) && typeof value === 'number' && Number.isFinite(value) && Math.abs(value) <= Number.MAX_SAFE_INTEGER) output[key] = value;
      else if (BOOLEAN_FIELDS.has(key) && typeof value === 'boolean') output[key] = value;
      else if (REF_FIELDS.has(key) && typeof value === 'string' && /^h[a-f0-9]{16}$/.test(value)) output[key] = value;
      else if (Object.hasOwn(ENUMS, key) && ENUMS[key].has(value)) output[key] = value;
      else if (key === 'browser' && typeof value === 'string' && /^(?:(?:Chrome|Edge|Firefox|Safari|Opera|Yandex)\/\d{1,4}(?:\.\d{1,6}){0,3}|Other)$/.test(value)) output[key] = value;
    }
    return output;
  }
  function event(input, source, streamId) {
    if (!input || !EVENTS.has(input.event) || !Number.isSafeInteger(input.seq) || input.seq < 1 || !time(input.at)) return null;
    if (!SOURCES.has(source || input.source) || !validStream(streamId || input.streamId)) return null;
    return { at: input.at, source: source || input.source, streamId: streamId || input.streamId,
      seq: input.seq, event: input.event, fields: fields(input.fields) };
  }
  function buffer(events = []) {
    const result = { events: [], bytes: 2, dropped: 0 };
    for (const item of events) push(result, item);
    return result;
  }
  function push(target, item) {
    target.events.push(item);
    target.bytes += JSON.stringify(item).length + 1;
    while (target.events.length > MAX_EVENTS || target.bytes > MAX_EVENT_BYTES) {
      const index = Math.min(KEEP_FIRST, target.events.length - 1);
      const [removed] = target.events.splice(index, 1);
      target.bytes -= JSON.stringify(removed).length + 1;
      target.dropped++;
    }
  }
  function sanitizeSnapshot(input) {
    const raw = input && typeof input === 'object' ? input : {};
    const retained = buffer();
    let invalidEvents = natural(raw.invalidEvents);
    for (const item of Array.isArray(raw.events) ? raw.events : []) {
      let clean;
      try { clean = event(item); } catch { clean = null; }
      if (clean) push(retained, clean);
      else invalidEvents++;
    }
    const result = { schemaVersion: SCHEMA_VERSION, runId: validRunId(raw.runId) ? raw.runId : '',
      version: validVersion(raw.version) ? raw.version : '', startedAt: time(raw.startedAt), updatedAt: time(raw.updatedAt),
      events: retained.events, eventCount: retained.events.length,
      droppedEvents: natural(raw.droppedEvents) + retained.dropped,
      transportErrors: natural(raw.transportErrors), invalidEvents,
      unsentEvents: natural(raw.unsentEvents), unacknowledgedDroppedEvents: natural(raw.unacknowledgedDroppedEvents),
      missingEvents: natural(raw.missingEvents), discardedByStore: natural(raw.discardedByStore) };
    if (SOURCES.has(raw.source)) result.source = raw.source;
    return result;
  }
  function delay(callback, ms) {
    const timer = setTimeout(callback, ms);
    timer?.unref?.();
    return timer;
  }
  function bounded(promise, ms = FLUSH_TIMEOUT) {
    return new Promise(resolve => {
      const timer = setTimeout(() => resolve(false), ms);
      Promise.resolve(promise).then(value => { clearTimeout(timer); resolve(value); }, () => { clearTimeout(timer); resolve(false); });
    });
  }
  function createRecorder(options = {}) {
    const runId = validRunId(options.runId) ? options.runId : '';
    const version = validVersion(options.version) ? options.version : '';
    const source = SOURCES.has(options.source) ? options.source : 'popup';
    const startedAt = new Date().toISOString();
    const streamId = ref(root.crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`).slice(1);
    const saved = buffer();
    let pending = buffer(), sequence = 0, transportErrors = 0, invalidEvents = 0, discardedByStore = 0;
    let unacknowledgedDroppedEvents = 0, timer = null, inFlight = null;
    const transport = typeof options.transport === 'function' ? options.transport : message => root.chrome?.runtime?.sendMessage(message);
    function arm() {
      if (!timer && pending.events.length) timer = delay(() => { timer = null; void flush(); }, 2000);
    }
    async function send() {
      if (inFlight) return inFlight;
      if (!pending.events.length || !runId) return;
      const batch = pending.events.slice();
      const lastSequence = batch[batch.length - 1].seq;
      inFlight = (async () => {
        let response;
        try {
          response = await bounded(Promise.resolve().then(() => transport({ type: 'diagnostics:append',
            runId, version, source, streamId, startedAt, events: batch,
            stats: { transportErrors, invalidEvents, droppedEvents: saved.dropped, unacknowledgedDroppedEvents } })));
        } catch { response = false; }
        if (response?.ok !== true) { transportErrors++; return; }
        if (response.retained === false) discardedByStore += batch.length;
        pending = buffer(pending.events.filter(item => item.seq > lastSequence));
      })();
      try { await inFlight; } finally { inFlight = null; }
    }
    async function flush() {
      clearTimeout(timer); timer = null;
      const cutoff = sequence;
      const draining = (async () => {
        if (inFlight) await inFlight;
        if (pending.events.some(item => item.seq <= cutoff)) await send();
      })();
      await bounded(draining);
      if (pending.events.some(item => item.seq > cutoff)) arm();
    }
    function record(name, data = {}) {
      try {
        if (!EVENTS.has(name)) { invalidEvents++; return; }
        const item = { at: new Date().toISOString(), source, streamId, seq: sequence + 1, event: name, fields: fields(data) };
        push(saved, item);
        sequence++;
        const droppedBefore = pending.dropped;
        push(pending, item);
        unacknowledgedDroppedEvents += pending.dropped - droppedBefore;
        if (pending.events.length >= 50 && !inFlight) void flush();
        else arm();
      } catch { invalidEvents++; }
    }
    return { record, flush, snapshot: () => sanitizeSnapshot({ runId, version, source, startedAt,
      updatedAt: saved.events[saved.events.length - 1]?.at || startedAt, events: saved.events,
      droppedEvents: saved.dropped, transportErrors, invalidEvents, unsentEvents: pending.events.length,
      unacknowledgedDroppedEvents, discardedByStore }) };
  }

  function installStore(chrome) {
    let serial = Promise.resolve();
    function normalizeLog(raw) {
      const clean = sanitizeSnapshot(raw);
      const streams = {};
      for (const [key, item] of Object.entries(raw?.streams || {}).slice(0, MAX_STREAMS)) {
        const [source, streamId, extra] = key.split(':');
        if (!SOURCES.has(source) || !validStream(streamId) || extra !== undefined) continue;
        streams[key] = { maxSeq: natural(item?.maxSeq), received: natural(item?.received),
          transportErrors: natural(item?.transportErrors), invalidEvents: natural(item?.invalidEvents),
          unacknowledgedDroppedEvents: natural(item?.unacknowledgedDroppedEvents) };
      }
      return { ...clean, streams };
    }
    async function handleInner(message) {
      if (!['diagnostics:append', 'diagnostics:list', 'diagnostics:get'].includes(message?.type)) {
        return { ok: false, error: 'invalid-diagnostic-record' };
      }
      const stored = await chrome.storage.local.get(STORAGE_KEY);
      const raw = stored[STORAGE_KEY] || {};
      const state = { logs: (Array.isArray(raw.logs) ? raw.logs : []).map(normalizeLog).filter(log => log.runId)
        .sort((a, b) => b.startedAt.localeCompare(a.startedAt)).slice(0, MAX_RUNS),
        retiredRunIds: Array.isArray(raw.retiredRunIds) ? raw.retiredRunIds.filter(validRunId).slice(-100) : [] };
      if (message.type === 'diagnostics:list') return { ok: true, logs: state.logs.map(log => {
        const clean = sanitizeSnapshot(log);
        return { runId: clean.runId, version: clean.version, startedAt: clean.startedAt, updatedAt: clean.updatedAt,
          eventCount: clean.eventCount, droppedEvents: clean.droppedEvents, transportErrors: clean.transportErrors,
          missingEvents: clean.missingEvents };
      }).filter(log => log.runId).sort((a, b) => b.startedAt.localeCompare(a.startedAt)) };
      if (message.type === 'diagnostics:get') {
        const log = state.logs.find(item => item.runId === message.runId);
        return { ok: true, log: log ? sanitizeSnapshot(log) : null };
      }
      if (!validRunId(message.runId) || !SOURCES.has(message.source) || !validStream(message.streamId)) {
        return { ok: false, error: 'invalid-diagnostic-record' };
      }
      if (state.retiredRunIds.includes(message.runId)) return { ok: true, retained: false };
      let log = state.logs.find(item => item.runId === message.runId);
      const now = new Date().toISOString();
      if (!log) {
        log = { schemaVersion: SCHEMA_VERSION, runId: message.runId,
          version: validVersion(message.version) ? message.version : '', startedAt: time(message.startedAt, now),
          updatedAt: now, events: [], droppedEvents: 0, streams: {} };
        state.logs.push(log);
      }
      const streamKey = `${message.source}:${message.streamId}`;
      log.streams ||= {};
      if (!log.streams[streamKey] && Object.keys(log.streams).length >= MAX_STREAMS) {
        return { ok: true, retained: false };
      }
      const stream = log.streams[streamKey] || (log.streams[streamKey] = { maxSeq: 0, received: 0 });
      const retained = buffer(log.events.map(item => event(item)).filter(Boolean));
      const items = (Array.isArray(message.events) ? message.events : []).slice(0, MAX_EVENTS)
        .map(item => event(item, message.source, message.streamId)).filter(Boolean).sort((a, b) => a.seq - b.seq);
      for (const item of items) {
        if (item.seq <= stream.maxSeq) continue;
        stream.maxSeq = item.seq; stream.received++;
        push(retained, item);
      }
      log.events = retained.events;
      log.droppedEvents = natural(log.droppedEvents) + retained.dropped;
      for (const key of ['transportErrors', 'invalidEvents', 'unacknowledgedDroppedEvents']) {
        stream[key] = Math.max(natural(stream[key]), natural(message.stats?.[key]));
      }
      const streams = Object.values(log.streams);
      log.transportErrors = streams.reduce((total, item) => total + natural(item.transportErrors), 0);
      log.invalidEvents = streams.reduce((total, item) => total + natural(item.invalidEvents), 0);
      log.unacknowledgedDroppedEvents = streams.reduce((total, item) => total + natural(item.unacknowledgedDroppedEvents), 0);
      log.missingEvents = streams.reduce((total, item) => total + Math.max(0, natural(item.maxSeq) - natural(item.received)), 0);
      log.updatedAt = now;
      state.logs.sort((a, b) => b.startedAt.localeCompare(a.startedAt));
      while (state.logs.length > MAX_RUNS) state.retiredRunIds.push(state.logs.pop().runId);
      state.retiredRunIds = state.retiredRunIds.slice(-100);
      await chrome.storage.local.set({ [STORAGE_KEY]: state });
      return { ok: true, retained: state.logs.some(item => item.runId === message.runId) };
    }
    function handle(message) {
      const operation = serial.then(() => handleInner(message));
      serial = operation.catch(() => {});
      return operation.catch(() => ({ ok: false, error: 'diagnostic-storage-unavailable' }));
    }
    chrome.runtime.onMessage.addListener((message, sender, reply) => {
      if (sender?.id !== chrome.runtime.id || !['diagnostics:append', 'diagnostics:list', 'diagnostics:get'].includes(message?.type)) return;
      handle(message).then(reply);
      return true;
    });
    return { handle };
  }
  return { createRecorder, installStore, sanitizeSnapshot, ref, errorCode,
    limits: Object.freeze({ events: MAX_EVENTS, bytes: MAX_BYTES, keepFirst: KEEP_FIRST, runs: MAX_RUNS }) };
});
