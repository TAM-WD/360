'use strict';

importScripts('attachment-downloads.js');

const STORAGE_KEY = 'attachmentDownloadJob';
const CONCURRENCY = 3;
let job = null;
let loaded = false;
let hydrated = null;
let recovered = false;
let downloadListenersInstalled = false;
let serial = Promise.resolve();

function enqueue(work) {
  const operation = serial.then(work, work);
  serial = operation.catch(() => {});
  return operation;
}

async function permitted() {
  return Boolean(chrome.downloads && await chrome.permissions.contains({ permissions: ['downloads'] }));
}

async function save() {
  await chrome.storage.local.set({ [STORAGE_KEY]: job });
}

function fail(file, reason) {
  file.state = 'failed';
  file.reason = reason;
}

function applyItem(file, item) {
  if (!item) { fail(file, 'Загрузка отсутствует в списке браузера.'); return; }
  file.downloadId = item.id;
  if (item.state === 'complete') {
    let loginPage = false;
    try { loginPage = /^passport\.(?:360\.)?yandex\.(?:ru|com)$/.test(new URL(item.finalUrl).hostname); } catch {}
    if (loginPage) { fail(file, 'Вместо файла открылась страница входа. Войдите в аккаунт и повторите загрузку.'); return; }
    file.state = 'complete';
    file.reason = '';
    file.url = '';
  } else if (item.state === 'interrupted') {
    fail(file, item.error === 'USER_CANCELED' ? 'Загрузка отменена.'
      : item.error === 'SERVER_UNAUTHORIZED' || item.error === 'SERVER_FORBIDDEN'
        ? 'Нет доступа к файлу или ссылка устарела.' : 'Загрузка прервана браузером.');
  } else file.state = 'in_progress';
}

async function reconcile() {
  if (!job || !await permitted()) return;
  for (const file of job.files) {
    if (!['starting', 'in_progress'].includes(file.state)) continue;
    if (Number.isInteger(file.downloadId)) {
      applyItem(file, (await chrome.downloads.search({ id: file.downloadId }))[0]);
    } else {
      const escaped = file.filename.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\//g, '[\\\\/]');
      const matches = await chrome.downloads.search({ filenameRegex: `(?:^|[\\\\/])${escaped}$` });
      // Filename determination may have supplied the ID while search was pending.
      const item = Number.isInteger(file.downloadId)
        ? (await chrome.downloads.search({ id: file.downloadId }))[0]
        : matches.find(item => item.byExtensionId === chrome.runtime.id);
      // A crash can happen between accepting download() and recording its ID.
      // Unknown starts require a manual retry rather than risking a duplicate.
      if (item) applyItem(file, item);
      else fail(file, 'Не удалось подтвердить запуск загрузки. Проверьте список загрузок браузера перед повтором.');
    }
  }
  await save();
}

async function hydrate() {
  if (!loaded) {
    if (!hydrated) hydrated = chrome.storage.local.get(STORAGE_KEY).then(stored => {
      job = stored[STORAGE_KEY] || null;
      loaded = true;
    }).catch(error => { hydrated = null; throw error; });
    await hydrated;
  }
}

async function load() {
  await hydrate();
  if (!recovered) { recovered = true; await reconcile(); }
}

async function pump() {
  if (!job || !await permitted()) return;
  installDownloadListeners();
  let active = job.files.filter(file => ['starting', 'in_progress'].includes(file.state)).length;
  while (active < CONCURRENCY) {
    const file = job.files.find(file => file.state === 'pending');
    if (!file) break;
    file.state = 'starting';
    file.downloadId = null;
    // Persist before starting. A service-worker restart must not lose the queue.
    await save();
    try {
      const id = await chrome.downloads.download({ url: file.url, filename: file.filename,
        conflictAction: 'uniquify', saveAs: false });
      file.downloadId = id;
      const item = (await chrome.downloads.search({ id }))[0];
      applyItem(file, item);
    } catch {
      fail(file, 'Не удалось начать загрузку. Возможно, ссылка недоступна.');
    }
    await save();
    active = job.files.filter(value => ['starting', 'in_progress'].includes(value.state)).length;
  }
}

function installDownloadListeners() {
  if (!chrome.downloads || downloadListenersInstalled) return;
  chrome.downloads.onChanged.addListener(delta => {
    if (!delta.state && !delta.error) return;
    void enqueue(async () => {
      await load();
      const file = job?.files.find(file => file.downloadId === delta.id);
      if (!file || !['starting', 'in_progress'].includes(file.state) || !await permitted()) return;
      applyItem(file, (await chrome.downloads.search({ id: delta.id }))[0]);
      await save();
      await pump();
    });
  });
  chrome.downloads.onErased.addListener(id => {
    void enqueue(async () => {
      await load();
      const file = job?.files.find(file => file.downloadId === id);
      if (file && ['starting', 'in_progress'].includes(file.state)) {
        fail(file, 'Загрузка удалена из списка браузера.');
        await save();
        await pump();
      }
    });
  });
  chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
    if (item.byExtensionId !== chrome.runtime.id) { suggest(); return; }
    // download() may wait for this callback, so it must not enter the serial queue.
    // The event can wake a worker before its saved queue has been read.
    void (async () => {
      await hydrate();
      const file = job?.files.find(file => file.downloadId === item.id) ||
        job?.files.find(file => file.state === 'starting' && file.url === item.url) ||
        job?.files.find(file => file.state === 'failed' && file.reason.startsWith('Не удалось подтвердить запуск') &&
          file.url === item.url);
      if (!file) { suggest(); return; }
      file.downloadId = item.id;
      file.state = 'in_progress';
      file.filename = AttachmentDownloads.determineFilename(file.filename, item);
      await save();
      suggest({ filename: file.filename, conflictAction: 'uniquify' });
    })().catch(() => {
      suggest();
      void chrome.downloads.cancel(item.id).catch(() => {});
    });
    return true;
  });
  downloadListenersInstalled = true;
}

async function handleMessage(message) {
  await load();
  if (message.type === 'attachments:start') {
    if (message.job?.files?.some(file => AttachmentDownloads.validURL(file.url)) && !await permitted()) {
      return { ok: false, error: 'Разрешите скачивание файлов и повторите попытку.' };
    }
    if (job && job.id !== message.job?.id && !AttachmentDownloads.buildStatus(job).done) {
      return { ok: false, error: 'Уже скачиваются вложения другой выгрузки. Дождитесь завершения.' };
    }
    if (!job || job.id !== message.job?.id) {
      job = AttachmentDownloads.acceptJob(message.job);
      await save();
    }
    await pump();
  } else if (message.type === 'attachments:retry') {
    if (!job || message.id !== job.id) return { ok: false, error: 'Эта выгрузка уже недоступна. Создайте новую выгрузку чата.' };
    if (!await permitted()) return { ok: false, error: 'Разрешите скачивание файлов и повторите попытку.' };
    for (const file of job.files) {
      if (file.state === 'failed') { file.state = 'pending'; file.downloadId = null; file.reason = ''; }
    }
    await save();
    await pump();
  } else if (message.type === 'attachments:show') {
    if (!job || message.id !== job.id || !await permitted()) return { ok: false, error: 'Папка этой выгрузки недоступна.' };
    const id = AttachmentDownloads.buildStatus(job).firstDownloadId;
    if (id === null) return { ok: false, error: 'Пока нет скачанных файлов.' };
    await chrome.downloads.show(id);
  } else if (message.type === 'attachments:status') {
    if (message.id && message.id !== job?.id) return { ok: true, status: null };
    await reconcile();
    await pump();
  }
  return { ok: true, status: AttachmentDownloads.buildStatus(job, !await permitted()) };
}

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== chrome.runtime.id || !['attachments:start', 'attachments:status', 'attachments:retry', 'attachments:show'].includes(message?.type)) return;
  enqueue(() => handleMessage(message)).then(reply, () => reply({ ok: false,
    error: 'Не удалось сохранить или обновить очередь вложений. Проверьте загрузки браузера и повторите попытку.' }));
  return true;
});
chrome.permissions.onAdded.addListener(() => {
  installDownloadListeners();
  void enqueue(async () => { await load(); await reconcile(); await pump(); });
});
chrome.runtime.onStartup.addListener(() => { void enqueue(async () => { await load(); await pump(); }); });
installDownloadListeners();
void enqueue(async () => { await load(); await pump(); });
