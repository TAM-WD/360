(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.ChatExport = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const text = value => value == null ? '' : String(value);
  const isReply = message => Boolean(message.replyToId || message.questionText || message.questionAuthor ||
    message.type === 'Ответ' || message.type === 'Ответ в треде');

  const partialReasons = new Set([
    'user-stopped', 'limit', 'running', 'gaps', 'unstable-ids', 'missing-replies',
    'open-failed', 'not-opened', 'no-scroller', 'thread-error', 'close-failed', 'thread-close-failed', 'error'
  ]);
  const count = value => Number.isFinite(value) && value >= 0 ? value : null;
  const threadIssueReasons = new Set(['gaps', 'unstable-ids', 'missing-replies', 'open-failed', 'not-opened',
    'no-scroller', 'thread-error', 'close-failed', 'thread-close-failed', 'error']);

  function hasThreadCollectionIssues(metadata = {}) {
    const threads = (Array.isArray(metadata.threads) ? metadata.threads : []).filter(thread => thread && typeof thread === 'object');
    if (threads.some(thread => {
      const coverage = thread.coverage || {};
      const expected = count(thread.expectedReplies), collected = count(thread.collectedReplies);
      return expected !== null && collected !== null && collected < expected ||
        coverage.hasGaps === true || coverage.unstableIds === true ||
        [coverage.reason, coverage.upwardStopReason, coverage.downwardStopReason].some(reason => threadIssueReasons.has(reason));
    })) return true;
    const summary = metadata.threadsSummary || {};
    const discovered = count(summary.discovered), collected = count(summary.collected);
    return discovered !== null && discovered > threads.length && collected !== null && collected < discovered;
  }

  function threadCoverageSummary(metadata) {
    const threads = (Array.isArray(metadata.threads) ? metadata.threads : []).filter(thread => thread && typeof thread === 'object');
    const coverages = threads.map(thread => classifyCoverage(thread.coverage, { ...thread, scope: 'thread' }));
    const summary = metadata.threadsSummary && typeof metadata.threadsSummary === 'object' ? metadata.threadsSummary : {};
    const discovered = count(summary.discovered);
    const collected = count(summary.collected);
    const missingDetails = discovered !== null && discovered > threads.length;
    // The legacy collected count excludes opened threads with no replies.
    // Detailed outcomes are stronger evidence than that aggregate count.
    const missingThreads = missingDetails && collected !== null && collected < discovered;
    if (missingThreads || coverages.some(coverage => coverage.status === 'partial')) {
      const interrupted = coverages.find(coverage => coverage.statusReason === 'user-stopped') ||
        coverages.find(coverage => coverage.statusReason === 'limit');
      return { status: 'partial', complete: false, statusReason: interrupted?.statusReason || 'threads-incomplete' };
    }
    if (missingDetails || coverages.some(coverage => coverage.status !== 'complete') ||
        !threads.length && summary.complete === false) return { status: 'unverified', complete: false };
    return { status: 'complete', complete: true };
  }

  function classifyCoverage(coverage = {}, metadata = {}) {
    const source = coverage && typeof coverage === 'object' ? coverage : {};
    const scope = metadata.scope === 'thread' ? 'thread' : 'main';
    const startReached = source.startReached === true &&
      (source.startEvidence === 'chat-created-event' || scope === 'thread' && source.startEvidence === 'first-position');
    const endReached = source.endReached === true &&
      (source.endEvidence === 'total-count' || scope === 'thread' && source.endEvidence === 'thread-reply-count');
    const reasons = [source.reason, source.upwardStopReason, source.downwardStopReason];
    const expected = count(metadata.expectedReplies);
    const collected = count(metadata.collectedReplies);
    const missingReplies = scope === 'thread' && expected !== null && collected !== null && collected < expected;
    const positionGaps = source.positionGaps === true || count(source.positionGapCount) > 0;
    const threads = scope === 'main' ? threadCoverageSummary(metadata) : { status: 'complete' };
    const statusReason = reasons.includes('user-stopped') || threads.statusReason === 'user-stopped' ? 'user-stopped'
      : reasons.includes('limit') || threads.statusReason === 'limit' ? 'limit'
      : reasons.find(reason => partialReasons.has(reason)) ||
        (source.hasGaps === true ? 'gaps' : source.unstableIds === true ? 'unstable-ids' :
          missingReplies ? 'missing-replies' : threads.status === 'partial' ? threads.statusReason : '');
    const status = statusReason ? 'partial' : startReached && endReached && !positionGaps && threads.status === 'complete' ? 'complete' : 'unverified';
    // Missing boundary evidence is not evidence that messages are missing.
    // Discontinuous interface positions also do not prove lost messages.
    // Neither a legacy boolean nor a supplied status can bypass these checks.
    return { ...source, startReached, endReached, positionGaps, status, complete: status === 'complete', statusReason };
  }

  function messageType(message) {
    if (message.type === 'Системное') return 'Системное';
    return isReply(message) ? 'Ответ' : 'Сообщение';
  }

  const pad = value => String(value).padStart(2, '0');
  const dateFormatters = new Map();
  function localParts(value, timeZone) {
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) return null;
    try {
      const key = timeZone || '';
      if (!dateFormatters.has(key)) dateFormatters.set(key, new Intl.DateTimeFormat('en-GB', {
        ...(timeZone ? { timeZone } : {}), year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
      }));
      const formatter = dateFormatters.get(key);
      return Object.fromEntries(formatter.formatToParts(date).map(part => [part.type, part.value]));
    } catch { return null; }
  }
  const formattedParts = parts => parts ? `${parts.year}.${parts.month}.${parts.day} ${parts.hour}:${parts.minute}` : '';
  function formatMessageDateTime(message, metadata = {}) {
    if (Number.isFinite(message.timestampMs)) {
      const result = formattedParts(localParts(message.timestampMs, metadata.timeZone));
      if (result) return result;
    }
    if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(text(message.datetime))) {
      const result = formattedParts(localParts(message.datetime, metadata.timeZone));
      if (result) return result;
    }
    const rawDate = text(message.date).trim();
    const rawTime = text(message.time).trim();
    const raw = rawDate && rawTime.includes(rawDate) ? rawTime : [rawDate, rawTime].filter(Boolean).join(' ');
    const clock = /(?:^|\s)(\d{1,2}):(\d{2})(?:\s|$)/.exec(rawTime);
    if (!clock || +clock[1] > 23 || +clock[2] > 59) return raw;
    let year, month, day;
    let match = /(?:^|\s)(\d{4})[-.](\d{2})[-.](\d{2})(?:\s|$)/.exec(raw);
    if (match) [, year, month, day] = match;
    else if ((match = /(?:^|\s)(\d{1,2})[./](\d{1,2})[./](\d{4})(?:\s|$)/.exec(raw))) {
      [, day, month, year] = match;
    } else {
      const months = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
      match = /(?:^|\s)(\d{1,2})\s+([а-яё]+)\s+(\d{4})(?:\s|$)/i.exec(raw);
      if (match && months.includes(match[2].toLowerCase())) {
        day = match[1]; month = months.indexOf(match[2].toLowerCase()) + 1; year = match[3];
      } else if (/\b(?:today|yesterday)\b/i.test(raw) || /(?:^|\s)(?:сегодня|вчера)(?:\s|$)/i.test(raw)) {
        const reference = metadata.exportedAt && localParts(metadata.exportedAt, metadata.timeZone);
        if (reference) {
          const previousDay = /yesterday|вчера/i.test(raw) ? 1 : 0;
          const calendar = new Date(Date.UTC(+reference.year, +reference.month - 1, +reference.day - previousDay));
          year = calendar.getUTCFullYear(); month = calendar.getUTCMonth() + 1; day = calendar.getUTCDate();
        }
      }
    }
    if (!year || !month || !day) return raw;
    const valid = new Date(Date.UTC(+year, +month - 1, +day));
    if (valid.getUTCFullYear() !== +year || valid.getUTCMonth() + 1 !== +month || valid.getUTCDate() !== +day) return raw;
    return `${year}.${pad(month)}.${pad(day)} ${pad(clock[1])}:${clock[2]}`;
  }
  function attachmentURL(value) {
    try {
      const url = new URL(text(value));
      return /^(?:http|https):$/.test(url.protocol) && !url.username && !url.password ? url.href : '';
    } catch { return ''; }
  }
  function normalizeAttachmentLinks(value) {
    return (Array.isArray(value) ? value : []).filter(item => item && typeof item === 'object' && (item.name || item.url)).map(item => ({
      name: text(item && item.name).trim() || 'Вложение', url: attachmentURL(item && item.url)
    }));
  }
  function mergeAttachmentLinks(previous, incoming) {
    const result = previous.map(link => ({ ...link }));
    const used = new Set();
    const countName = (items, name) => items.filter(item => item.name === name).length;
    for (let index = 0; index < incoming.length; index++) {
      const link = incoming[index];
      const available = (item, i) => !used.has(i) && item.name === link.name;
      let target = link.url ? result.findIndex((item, i) => available(item, i) && item.url === link.url) : -1;
      // Match a refreshed URL by its position only when the original slot still
      // identifies the same occurrence. A partial snapshot must not replace a
      // different identically named file whose URL was already collected.
      if (target < 0 && result[index] && available(result[index], index) &&
          (!link.url || !result[index].url || countName(previous, link.name) === countName(incoming, link.name))) target = index;
      if (target < 0 && countName(previous, link.name) === 1 && countName(incoming, link.name) === 1) {
        target = result.findIndex(available);
      }
      if (target < 0 && !link.url) target = result.findIndex(available);
      if (target >= 0) {
        used.add(target);
        if (link.url) result[target].url = link.url;
      } else {
        result.push({ ...link });
        used.add(result.length - 1);
      }
    }
    return result;
  }
  function attachmentEntries(message) {
    const links = message.attachmentLinks.map(link => ({ ...link }));
    // Each original label is represented once; separate identically named files
    // still keep their own URL and their own continuation row.
    const matched = new Set();
    for (const name of message.attachments) {
      const index = links.findIndex((link, i) => !matched.has(i) && link.name === name);
      if (index >= 0) matched.add(index);
      else { links.push({ name, url: '' }); matched.add(links.length - 1); }
    }
    return links;
  }

  function normalizeMessage(source, position, usedIds) {
    let id = text(source.id);
    if (!id) {
      id = `export-message-${position + 1}`;
      while (usedIds.has(id)) id += '-';
    }
    const message = {
      id,
      time: text(source.time),
      date: text(source.date),
      datetime: text(source.datetime),
      timestampMs: Number.isFinite(source.timestampMs) ? source.timestampMs : null,
      sender: text(source.sender).trim() || (source.isOwnMessage ? 'Вы' : 'Неизвестный автор'),
      isOwnMessage: Boolean(source.isOwnMessage),
      message: text(source.message),
      contentUnavailable: source.contentUnavailable === true,
      replyToId: text(source.replyToId),
      threadRootId: text(source.threadRootId) === id ? '' : text(source.threadRootId),
      questionText: text(source.questionText),
      questionAuthor: text(source.questionAuthor).trim(),
      attachments: Array.isArray(source.attachments) ? source.attachments.map(text).filter(Boolean) : [],
      attachmentLinks: normalizeAttachmentLinks(source.attachmentLinks),
      type: text(source.type),
      order: Number.isFinite(source.order) ? source.order : position
    };
    message.type = messageType(message);
    return message;
  }

  function buildExportData(input, metadata = {}) {
    if (!Array.isArray(input)) throw new TypeError('Ожидался массив сообщений');
    const threads = (Array.isArray(metadata.threads) ? metadata.threads : []).filter(thread => thread && typeof thread === 'object')
      .map(thread => ({ ...thread, coverage: classifyCoverage(thread.coverage, { ...thread, scope: 'thread' }) }));
    const threadsState = threadCoverageSummary({ ...metadata, threads });
    metadata = { ...metadata, threads, coverage: classifyCoverage(metadata.coverage, { ...metadata, threads }),
      ...(metadata.threadsSummary ? { threadsSummary: { ...metadata.threadsSummary, ...threadsState } } : {}) };
    const usedIds = new Set(input.map(message => text(message && message.id)).filter(Boolean));
    const byId = new Map();
    input.forEach((source, position) => {
      const message = normalizeMessage(source || {}, position, usedIds);
      usedIds.add(message.id);
      // Repeated DOM snapshots enrich context; identical text is never a duplicate key.
      const previous = byId.get(message.id);
      if (!previous) byId.set(message.id, message);
      else {
        const reply = isReply(previous) || isReply(message);
        if (!message.contentUnavailable && (previous.contentUnavailable || !previous.message)) {
          previous.message = message.message;
          previous.contentUnavailable = false;
          if (message.type === 'Системное') previous.type = 'Системное';
        }
        for (const field of ['threadRootId', 'replyToId', 'questionText', 'questionAuthor', 'datetime', 'date', 'time']) {
          if (!previous[field]) previous[field] = message[field];
        }
        if (previous.timestampMs === null) previous.timestampMs = message.timestampMs;
        previous.attachmentLinks = mergeAttachmentLinks(previous.attachmentLinks, message.attachmentLinks);
        if (!previous.attachments.length) previous.attachments = message.attachments;
        if (previous.type !== 'Системное') {
          previous.type = reply ? 'Ответ' : 'Сообщение';
          previous.type = messageType(previous);
        }
      }
    });
    const messages = Array.from(byId.values()).sort((a, b) => a.order - b.order);
    const mainMessages = messages.filter(message => !message.threadRootId);
    const groupMap = new Map();
    function ensureThread(rootId) {
      if (!groupMap.has(rootId)) groupMap.set(rootId, { rootId, root: byId.get(rootId) || null, messages: [] });
      return groupMap.get(rootId);
    }
    for (const thread of Array.isArray(metadata.threads) ? metadata.threads : []) {
      if (thread && text(thread.rootId)) ensureThread(text(thread.rootId));
    }
    for (const message of messages) if (message.threadRootId) ensureThread(message.threadRootId).messages.push(message);
    const threadGroups = Array.from(groupMap.values()).sort((a, b) =>
      (a.root?.order ?? a.messages[0]?.order ?? Infinity) - (b.root?.order ?? b.messages[0]?.order ?? Infinity));
    const warnings = new Set(Array.isArray(metadata.warnings) ? metadata.warnings : metadata.warnings ? [text(metadata.warnings)] : []);
    // Missing interface markers describe the strength of the verification, not
    // a collection failure. Their evidence remains in the statistics and log.
    for (const warning of [
      'Полнота истории автоматически не подтверждена.',
      'Интерфейс не предоставил явного подтверждения начала чата.',
      'Полнота переписки не подтверждена: интерфейс не предоставил явных признаков её границ.',
      'В нумерации интерфейса есть разрывы. Они не подтверждают пропуски сообщений.',
      'Файлы и медиа представлены ссылками. Для открытия может требоваться доступ к чату; временные ссылки могут истечь.',
      'Содержимое файлов и медиа не скачивается.',
      'Встречены сообщения, содержимое которых интерфейс не предоставил в текстовом виде.'
    ]) warnings.delete(warning);
    for (const warning of warnings) {
      if (/^Не удалось прочитать содержимое сообщений: \d+\. Эти записи отмечены в выгрузке\.$/.test(warning)) warnings.delete(warning);
    }
    const unavailableMessages = messages.filter(message => message.contentUnavailable);
    if (unavailableMessages.length) warnings.add(`Не удалось прочитать содержимое сообщений: ${unavailableMessages.length}. Эти записи отмечены в выгрузке.`);
    if (metadata.coverage.status !== 'partial') {
      for (const warning of [
        'Продвижение по истории прекратилось. Сохранена только собранная часть истории.',
        'Сохранена доступная история. Полнота переписки и тредов не подтверждена.',
        'Выгрузка завершилась с ограничениями. Сохранена собранная часть истории.'
      ]) warnings.delete(warning);
    }
    if (!hasThreadCollectionIssues(metadata)) {
      warnings.delete('Часть ответов в тредах не удалось загрузить. Подробности — в сведениях о тредах.');
    }
    for (const message of messages) {
      message.dateTime = formatMessageDateTime(message, metadata);
      if (!/^\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}$/.test(message.dateTime)) {
        warnings.add('У части сообщений нет точной даты и времени; сохранено значение, доступное в интерфейсе.');
      }
      message.attachmentEntries = attachmentEntries(message);
    }
    return {
      messages, mainMessages, threadGroups,
      stats: {
        messages: messages.length,
        contentUnavailable: unavailableMessages.length,
        questions: mainMessages.filter(message => message.type === 'Сообщение').length,
        answers: mainMessages.filter(message => message.type === 'Ответ').length,
        threads: messages.filter(message => message.threadRootId && message.type === 'Сообщение').length,
        threadReplies: messages.filter(message => message.threadRootId && message.type === 'Ответ').length,
        system: messages.filter(message => message.type === 'Системное').length,
        attachments: messages.reduce((count, message) => count + message.attachmentEntries.length, 0)
      },
      metadata: { ...metadata, warnings: Array.from(warnings), contentUnavailableCount: unavailableMessages.length,
        version: text(metadata.version) || '1.20' }
    };
  }

  function buildWorkbook(data, XLSX) {
    if (!XLSX || !XLSX.utils) throw new TypeError('Библиотека XLSX недоступна');
    const workbook = XLSX.utils.book_new();
    function append(name, rows, widths) {
      // Primitive strings stay literal text, including text beginning with '='.
      const sheet = XLSX.utils.aoa_to_sheet(rows);
      sheet['!cols'] = widths.map(wch => ({ wch }));
      sheet['!autofilter'] = { ref: sheet['!ref'] };
      XLSX.utils.book_append_sheet(workbook, sheet, name);
      return sheet;
    }
    const headers = ['ID сообщения', 'Дата и время', 'Автор', 'Тип', 'Текст', 'Вложения', 'Ответ на ID', 'Цитата', 'Автор цитаты', 'ID треда'];
    const widths = [30, 22, 24, 18, 65, 55, 30, 55, 24, 30];
    const threadRows = [];
    const threadTargets = new Map();
    const threadLinks = [];
    const threadMerges = [];
    const messageTargets = new Map();
    function appendMessage(rows, links, message, threadId, sheetName) {
      const attachments = message.attachmentEntries;
      const first = attachments[0];
      const rowIndex = rows.length;
      messageTargets.set(message.id, `#'${sheetName}'!A${rowIndex + 1}`);
      rows.push([message.id, message.dateTime, message.sender, message.type, message.message,
        first?.name || '', message.replyToId, message.questionText, message.questionAuthor, threadId]);
      if (first?.url) links.push({ row: rowIndex, column: 5, target: first.url });
      if (threadId && threadTargets.has(threadId)) links.push({ row: rowIndex, column: 9, target: threadTargets.get(threadId) });
      for (const attachment of attachments.slice(1)) {
        const continuation = Array(headers.length).fill('');
        continuation[5] = attachment.name;
        if (attachment.url) links.push({ row: rows.length, column: 5, target: attachment.url });
        rows.push(continuation);
      }
    }
    for (const group of data.threadGroups) {
      const headingRow = threadRows.length;
      threadTargets.set(group.rootId, `#'Треды'!A${headingRow + 1}`);
      const heading = group.root
        ? `Тред ${group.rootId}: ${group.root.message || group.root.attachmentEntries.map(item => item.name).join(', ') || '[Сообщение без текста]'}`
        : `Тред ${group.rootId}: исходное сообщение не загружено`;
      threadRows.push([heading]);
      threadMerges.push({ s: { r: headingRow, c: 0 }, e: { r: headingRow, c: headers.length - 1 } });
      threadRows.push(headers.slice());
      for (const message of group.messages) appendMessage(threadRows, threadLinks, message, group.rootId, 'Треды');
      if (!group.messages.length) threadRows.push(['Ответы не загружены']);
      threadRows.push([]);
    }
    if (!threadRows.length) threadRows.push(['Треды не найдены']);
    const mainRows = [headers.slice()];
    const mainLinks = [];
    for (const message of data.mainMessages) appendMessage(mainRows, mainLinks, message,
      threadTargets.has(message.id) ? message.id : '', 'Сообщения');
    function applyLinks(sheet, links) {
      for (const link of links) {
        const cell = sheet[XLSX.utils.encode_cell({ r: link.row, c: link.column })];
        if (cell) cell.l = { Target: link.target };
      }
    }
    const mainSheet = append('Сообщения', mainRows, widths);
    applyLinks(mainSheet, mainLinks);
    const threadSheet = append('Треды', threadRows, widths);
    delete threadSheet['!autofilter'];
    if (threadMerges.length) threadSheet['!merges'] = threadMerges;
    applyLinks(threadSheet, threadLinks);

    const metadata = data.metadata || {};
    const warnings = Array.isArray(metadata.warnings) ? metadata.warnings.map(text).join('\n') : text(metadata.warnings);
    const coverage = classifyCoverage(metadata.coverage, metadata);
    const summary = metadata.threadsSummary ? { ...metadata.threadsSummary, ...threadCoverageSummary(metadata) } : null;
    const reasons = {
      'not-started': 'Проход не запускался',
      'user-stopped': 'Остановлено пользователем',
      running: 'Проход был прерван',
      'confirmed-start': 'Начало истории подтверждено интерфейсом',
      'confirmed-end': 'Конец истории подтверждён интерфейсом',
      'stable-boundaries': 'Границы истории подтверждены',
      limit: 'Достигнут общий предел времени',
      'no-progress': 'Продвижение по истории прекратилось',
      gaps: 'Обнаружены пропуски в истории',
      'unstable-ids': 'У части сообщений нет постоянного идентификатора',
      'threads-incomplete': 'Часть тредов выгружена не полностью',
      'missing-replies': 'Часть ответов не загрузилась',
      'open-failed': 'Не удалось открыть тред',
      'not-opened': 'Тред не был открыт',
      'no-scroller': 'Не найден контейнер прокрутки',
      'thread-error': 'Ошибка при сборе треда',
      'close-failed': 'Не удалось закрыть панель треда',
      'thread-close-failed': 'Не удалось вернуться из треда к основной переписке'
    };
    const evidence = {
      'first-position': 'Интерфейс показал сообщение с позицией 1',
      'chat-created-event': 'Найдено системное событие создания чата',
      'history-start-marker': 'Интерфейс явно обозначил начало истории',
      'total-count': 'Достигнуто общее число сообщений, указанное интерфейсом',
      'thread-reply-count': 'Достигнут последний номер ответа по счётчику треда'
    };
    const yesNo = value => value === true ? 'Да' : 'Нет';
    const completeness = value => value.status === 'complete' ? 'Да' : value.status === 'partial' ? 'Нет' : 'Не подтверждено';
    const result = coverage.statusReason === 'user-stopped' ? 'Остановлена пользователем'
      : coverage.statusReason === 'limit' ? 'Остановлена по пределу времени'
      : coverage.status === 'partial' ? 'Завершена частично' : 'Завершена';
    const explainReason = (value, state = coverage) => {
      if (value === 'threads-incomplete' && state.status === 'unverified') return 'Полнота тредов не подтверждена';
      if (value === 'stable-boundaries' && (!state.startReached || !state.endReached)) return 'Границы истории не подтверждены';
      if (value === 'confirmed-start' && !state.startReached) return 'Начало истории не подтверждено';
      if (value === 'confirmed-end' && !state.endReached) return 'Конец истории не подтверждён';
      return reasons[value] || 'Не указана';
    };
    const explainEvidence = value => evidence[value] || 'Нет подтверждения от интерфейса';
    const incompleteThreads = (Array.isArray(metadata.threads) ? metadata.threads : [])
      .filter(thread => thread && classifyCoverage(thread.coverage, { ...thread, scope: 'thread' }).status !== 'complete')
      .map(thread => {
        const state = classifyCoverage(thread.coverage, { ...thread, scope: 'thread' });
        const collected = Number.isFinite(thread.collectedReplies) ? thread.collectedReplies : 0;
        const expected = Number.isFinite(thread.expectedReplies) && thread.expectedReplies > 0
          ? ` из ${thread.expectedReplies}` : '';
        const parentUnconfirmed = state.reason === 'open-failed' && thread.openDiagnostics?.threadPanelCount === 1 &&
          ['parent-missing', 'parent-id-missing'].includes(thread.openDiagnostics.threadOpenReason);
        const reason = parentUnconfirmed ? 'Панель треда открылась, но не удалось подтвердить исходное сообщение'
          : reasons[state.reason] ? explainReason(state.reason, state) : 'Полнота истории не подтверждена';
        const numbering = state.positionGaps ? ' Полнота треда по нумерации интерфейса не подтверждена.' : '';
        return [`Тред ${text(thread.rootId)}`, `Собрано ответов: ${collected}${expected}; ${reason}.${numbering}`];
      });
    const mainMessages = data.mainMessages;
    function dateTime(message) {
      return message ? message.dateTime || 'Не указаны интерфейсом' : 'Нет собранных сообщений';
    }
    const statisticsRows = [
      ['Параметр', 'Значение'],
      ['Название чата', text(metadata.chatTitle)],
      ['Время экспорта', text(metadata.exportedAt)],
      ['Версия расширения', text(metadata.version)],
      ['Результат выгрузки', result],
      ['Выгрузка полная', completeness(coverage)],
      ['Начало чата подтверждено', yesNo(coverage.startReached)],
      ['Подтверждение начала', explainEvidence(coverage.startReached ? coverage.startEvidence : '')],
      ['Конец чата подтверждён', yesNo(coverage.endReached)],
      ['Подтверждение конца', explainEvidence(coverage.endReached ? coverage.endEvidence : '')],
      ['Причина остановки вверх', explainReason(coverage.upwardStopReason)],
      ['Причина остановки вниз', explainReason(coverage.downwardStopReason)],
      ['Причина завершения выгрузки', explainReason(coverage.reason)],
      ['Первая собранная позиция', coverage.firstPosition ?? 'Не указана интерфейсом'],
      ['Последняя собранная позиция', coverage.lastPosition ?? 'Не указана интерфейсом'],
      ['Всего позиций по данным интерфейса', coverage.expectedTotal ?? 'Не указано'],
      ...(coverage.positionGaps ? [['Разрывы нумерации интерфейса',
        `${count(coverage.positionGapCount) > 0 ? `${coverage.positionGapCount} позиций` : 'Есть'}; полнота переписки по нумерации не подтверждена`]] : []),
      ['Остановка у верхнего края загруженного фрагмента', coverage.stoppedAtTopEdge == null ? 'Не зафиксирована' : yesNo(coverage.stoppedAtTopEdge)],
      ['Первое собранное сообщение чата', dateTime(mainMessages[0])],
      ['Последнее собранное сообщение чата', dateTime(mainMessages.at(-1))],
      ['Всего сообщений', data.stats.messages],
      ['Сообщений без доступного содержимого', data.stats.contentUnavailable],
      ['Обычных сообщений', data.stats.questions],
      ['Ответов в основном чате', data.stats.answers],
      ['Сообщений в тредах', data.stats.threads],
      ['Ответов в тредах', data.stats.threadReplies],
      ['Системных сообщений', data.stats.system],
      ['Вложений', data.stats.attachments],
      ...(data.stats.attachments ? [['Доступ к вложениям',
        'Файлы и медиа представлены ссылками. Для открытия может требоваться доступ к чату; временные ссылки могут истечь.']] : []),
      ...(summary ? [
        ['Тредов найдено', summary.discovered],
        ['Тредов собрано', summary.collected],
        ['Треды собраны полностью', completeness(summary)]
      ] : []),
      ['Предупреждения', warnings],
      ...incompleteThreads
    ];
    const unreadableLinks = [];
    for (const message of data.messages.filter(message => message.contentUnavailable)) {
      unreadableLinks.push({ row: statisticsRows.length, column: 1, target: messageTargets.get(message.id) });
      statisticsRows.push([`Содержимое сообщения ${message.id}`,
        `Не удалось прочитать; лист «${message.threadRootId ? 'Треды' : 'Сообщения'}»`]);
    }
    const statisticsSheet = append('Статистика', statisticsRows, [38, 100]);
    applyLinks(statisticsSheet, unreadableLinks);
    return workbook;
  }

  return { buildExportData, buildWorkbook, formatMessageDateTime, classifyCoverage, hasThreadCollectionIssues };
});
