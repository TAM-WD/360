(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.ChatExport = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const text = value => value == null ? '' : String(value);
  const isReply = message => Boolean(message.replyToId || message.questionText || message.questionAuthor ||
    message.type === 'Ответ' || message.type === 'Ответ в треде');

  function messageType(message) {
    if (message.type === 'Системное') return 'Системное';
    if (message.threadRootId) return isReply(message) ? 'Ответ в треде' : 'Тред';
    return isReply(message) ? 'Ответ' : 'Сообщение';
  }

  function normalizeMessage(source, position, usedIds) {
    let id = text(source.id);
    if (!id) {
      id = `export-message-${position + 1}`;
      while (usedIds.has(id)) id += '-';
    }
    const message = {
      id,
      time: text(source.time),
      date: text(source.date),
      sender: text(source.sender).trim() || (source.isOwnMessage ? 'Вы' : 'Неизвестный автор'),
      isOwnMessage: Boolean(source.isOwnMessage),
      message: text(source.message),
      replyToId: text(source.replyToId),
      threadRootId: text(source.threadRootId) === id ? '' : text(source.threadRootId),
      questionText: text(source.questionText),
      questionAuthor: text(source.questionAuthor).trim(),
      attachments: Array.isArray(source.attachments) ? source.attachments.map(text).filter(Boolean) : [],
      type: text(source.type),
      order: Number.isFinite(source.order) ? source.order : position
    };
    message.type = messageType(message);
    return message;
  }

  function buildExportData(input, metadata = {}) {
    if (!Array.isArray(input)) throw new TypeError('Ожидался массив сообщений');
    const usedIds = new Set(input.map(message => text(message && message.id)).filter(Boolean));
    const byId = new Map();
    input.forEach((source, position) => {
      const message = normalizeMessage(source || {}, position, usedIds);
      usedIds.add(message.id);
      // Repeated DOM snapshots enrich context; identical text is never a duplicate key.
      const previous = byId.get(message.id);
      if (!previous) byId.set(message.id, message);
      else {
        const reply = isReply(previous) || isReply(message);
        for (const field of ['threadRootId', 'replyToId', 'questionText', 'questionAuthor']) {
          if (!previous[field]) previous[field] = message[field];
        }
        if (previous.type !== 'Системное') {
          previous.type = reply ? 'Ответ' : 'Сообщение';
          previous.type = messageType(previous);
        }
      }
    });
    const messages = Array.from(byId.values()).sort((a, b) => a.order - b.order);
    return {
      messages,
      stats: {
        messages: messages.length,
        questions: messages.filter(message => message.type === 'Сообщение').length,
        answers: messages.filter(message => message.type === 'Ответ').length,
        threads: messages.filter(message => message.type === 'Тред').length,
        threadReplies: messages.filter(message => message.type === 'Ответ в треде').length,
        system: messages.filter(message => message.type === 'Системное').length,
        attachments: messages.reduce((count, message) => count + message.attachments.length, 0)
      },
      metadata: { ...metadata, version: text(metadata.version) || '1.5' }
    };
  }

  function buildWorkbook(data, XLSX) {
    if (!XLSX || !XLSX.utils) throw new TypeError('Библиотека XLSX недоступна');
    const workbook = XLSX.utils.book_new();
    function append(name, rows, widths) {
      // Primitive strings stay literal text, including text beginning with '='.
      const sheet = XLSX.utils.aoa_to_sheet(rows);
      sheet['!cols'] = widths.map(wch => ({ wch }));
      sheet['!autofilter'] = { ref: sheet['!ref'] };
      XLSX.utils.book_append_sheet(workbook, sheet, name);
      return sheet;
    }
    append('Сообщения', [
      ['ID сообщения', 'Дата', 'Время', 'Автор', 'Тип', 'Текст', 'Вложения', 'Ответ на ID', 'Цитата', 'Автор цитаты', 'ID треда'],
      ...data.messages.map(message => [
        message.id, message.date, message.time, message.sender, message.type, message.message,
        message.attachments.join('\n'), message.replyToId, message.questionText, message.questionAuthor, message.threadRootId
      ])
    ], [30, 14, 16, 24, 20, 65, 55, 30, 55, 24, 30]);

    const metadata = data.metadata || {};
    const warnings = Array.isArray(metadata.warnings) ? metadata.warnings.map(text).join('\n') : text(metadata.warnings);
    const coverage = metadata.coverage && typeof metadata.coverage === 'object' ? metadata.coverage : {};
    const summary = metadata.threadsSummary;
    const reasons = {
      'not-started': 'Проход не запускался',
      running: 'Проход был прерван',
      'confirmed-start': 'Начало истории подтверждено интерфейсом',
      'confirmed-end': 'Конец истории подтверждён интерфейсом',
      'stable-boundaries': 'Границы истории подтверждены',
      limit: 'Достигнут общий предел времени',
      'no-progress': 'Продвижение по истории прекратилось',
      gaps: 'Обнаружены пропуски в истории',
      'threads-incomplete': 'Часть тредов выгружена не полностью',
      'missing-replies': 'Часть ответов не загрузилась',
      'open-failed': 'Не удалось открыть тред',
      'not-opened': 'Тред не был открыт',
      'no-scroller': 'Не найден контейнер прокрутки',
      'thread-error': 'Ошибка при сборе треда',
      'close-failed': 'Не удалось закрыть панель треда',
      'thread-close-failed': 'Не удалось вернуться из треда к основной переписке'
    };
    const evidence = {
      'first-position': 'Интерфейс показал сообщение с позицией 1',
      'history-start-marker': 'Интерфейс явно обозначил начало истории',
      'total-count': 'Достигнуто общее число сообщений, указанное интерфейсом',
      'thread-reply-count': 'Собраны все ответы по счётчику треда'
    };
    const yesNo = value => value === true ? 'Да' : 'Нет';
    const explainReason = value => reasons[value] || 'Не указана';
    const explainEvidence = value => evidence[value] || 'Нет подтверждения от интерфейса';
    const incompleteThreads = (Array.isArray(metadata.threads) ? metadata.threads : [])
      .filter(thread => thread && !thread.coverage?.complete)
      .map(thread => {
        const collected = Number.isFinite(thread.collectedReplies) ? thread.collectedReplies : 0;
        const expected = Number.isFinite(thread.expectedReplies) && thread.expectedReplies > 0
          ? ` из ${thread.expectedReplies}` : '';
        const reason = reasons[thread.coverage?.reason] || 'Полнота истории не подтверждена';
        return [`Тред ${text(thread.rootId)}`, `Собрано ответов: ${collected}${expected}; ${reason}.`];
      });
    const mainMessages = data.messages.filter(message => !message.threadRootId);
    function dateTime(message) {
      if (!message) return 'Нет собранных сообщений';
      if (message.date && message.time.includes(message.date)) return message.time;
      return [message.date, message.time].filter(Boolean).join(' ') || 'Не указаны интерфейсом';
    }
    append('Статистика', [
      ['Параметр', 'Значение'],
      ['Название чата', text(metadata.chatTitle)],
      ['Время экспорта', text(metadata.exportedAt)],
      ['Версия расширения', text(metadata.version)],
      ['Выгрузка полная', yesNo(coverage.complete)],
      ['Начало чата подтверждено', yesNo(coverage.startReached)],
      ['Подтверждение начала', explainEvidence(coverage.startEvidence)],
      ['Конец чата подтверждён', yesNo(coverage.endReached)],
      ['Подтверждение конца', explainEvidence(coverage.endEvidence)],
      ['Причина остановки вверх', explainReason(coverage.upwardStopReason)],
      ['Причина остановки вниз', explainReason(coverage.downwardStopReason)],
      ['Причина завершения выгрузки', explainReason(coverage.reason)],
      ['Первая собранная позиция', coverage.firstPosition ?? 'Не указана интерфейсом'],
      ['Последняя собранная позиция', coverage.lastPosition ?? 'Не указана интерфейсом'],
      ['Всего позиций по данным интерфейса', coverage.expectedTotal ?? 'Не указано'],
      ['Остановка у верхнего края загруженного фрагмента', coverage.stoppedAtTopEdge == null ? 'Не зафиксирована' : yesNo(coverage.stoppedAtTopEdge)],
      ['Первое собранное сообщение чата', dateTime(mainMessages[0])],
      ['Последнее собранное сообщение чата', dateTime(mainMessages.at(-1))],
      ['Всего сообщений', data.stats.messages],
      ['Обычных сообщений', data.stats.questions],
      ['Ответов в основном чате', data.stats.answers],
      ['Сообщений в тредах', data.stats.threads],
      ['Ответов в тредах', data.stats.threadReplies],
      ['Системных сообщений', data.stats.system],
      ['Вложений', data.stats.attachments],
      ...(summary ? [
        ['Тредов найдено', summary.discovered],
        ['Тредов собрано', summary.collected],
        ['Треды собраны полностью', yesNo(summary.complete)]
      ] : []),
      ['Предупреждения', warnings],
      ...incompleteThreads
    ], [38, 100]);
    return workbook;
  }

  return { buildExportData, buildWorkbook };
});
