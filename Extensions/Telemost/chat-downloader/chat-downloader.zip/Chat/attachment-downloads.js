(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.AttachmentDownloads = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function validURL(value) {
    try {
      const url = new URL(value);
      return ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password ? url.href : '';
    } catch { return ''; }
  }

  const ERROR_CODES = new Set([
    'FILE_FAILED', 'FILE_ACCESS_DENIED', 'FILE_NO_SPACE', 'FILE_NAME_TOO_LONG', 'FILE_TOO_LARGE',
    'FILE_VIRUS_INFECTED', 'FILE_TRANSIENT_ERROR', 'FILE_BLOCKED', 'FILE_SECURITY_CHECK_FAILED',
    'FILE_TOO_SHORT', 'FILE_HASH_MISMATCH', 'FILE_SAME_AS_SOURCE', 'NETWORK_FAILED',
    'NETWORK_TIMEOUT', 'NETWORK_DISCONNECTED', 'NETWORK_SERVER_DOWN', 'NETWORK_INVALID_REQUEST',
    'SERVER_FAILED', 'SERVER_NO_RANGE', 'SERVER_BAD_CONTENT', 'SERVER_UNAUTHORIZED',
    'SERVER_CERT_PROBLEM', 'SERVER_FORBIDDEN', 'SERVER_UNREACHABLE', 'SERVER_CONTENT_LENGTH_MISMATCH',
    'SERVER_CROSS_ORIGIN_REDIRECT', 'USER_CANCELED', 'USER_SHUTDOWN', 'CRASH'
  ]);
  function safeErrorCode(value) {
    // Chrome may return a code directly, as error.code, or as the entire
    // rejection message. Never return part of a free-form browser exception.
    for (const candidate of [value, value?.code, value?.message]) {
      if (typeof candidate === 'string' && ERROR_CODES.has(candidate)) return candidate;
    }
    return '';
  }

  const MISSING_URL_REASON = 'Адрес вложения не сохранён в выгрузке. Откройте файл в чате.';
  const missingReasons = new Map([
    ['session-url-without-storage-id', 'Чат показал временный адрес. Откройте вложение в чате, чтобы сохранить файл.'],
    ['session-image-unavailable', 'Не удалось сохранить копию изображения по временному адресу. Откройте изображение в чате.'],
    ['session-image-too-large', 'Изображение превышает предел 8 МиБ для временной копии. Сохраните его из чата отдельно.'],
    ['session-image-run-limit', 'Для этой выгрузки достигнут предел 32 МиБ временных копий. Сохраните изображение из чата отдельно.'],
    ['session-image-unsupported', 'Формат временного изображения не распознан. Откройте его в чате.'],
    ['session-image-storage-error', 'Не удалось записать изображение в хранилище расширения. Сохраните его из чата отдельно.'],
    ['storage-id-invalid', 'В карточке указан идентификатор файла неизвестного формата. Откройте вложение в чате.'],
    ['storage-origin-unavailable', 'Не удалось определить адрес файлового сервера этого чата. Откройте вложение в чате.'],
    ['no-url-in-dom', 'В карточке нет адреса для скачивания. Откройте вложение в чате.'],
    ['invalid-url', 'В карточке указан некорректный адрес файла. Откройте вложение в чате.'],
    ['unsupported-url', 'Адрес карточки нельзя использовать для скачивания. Откройте вложение в чате.']
  ]);

  function safeName(value, fallback = 'Вложение') {
    let name = String(value || '').normalize('NFC')
      .replace(/\s+\(\d[\d\s.,]*\s*(?:[КМГТ]?Б|[KMGT]?B|bytes?)\)$/iu, '')
      .replace(/[\x00-\x1f\x7f<>:"/\\|?*\u202a-\u202e\u2066-\u2069]/g, '_')
      .replace(/^[.\s]+|[.\s]+$/g, '');
    if (!name) name = fallback;
    if (/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(name)) name = `_${name}`;
    const extension = name.match(/\.[a-z0-9]{1,12}$/i)?.[0] || '';
    let stem = extension ? name.slice(0, -extension.length) : name;
    while (new TextEncoder().encode(stem + extension).length > 150) stem = Array.from(stem).slice(0, -1).join('');
    return stem + extension;
  }

  function createJob(messages, exportFilename) {
    const random = globalThis.crypto?.randomUUID?.().replace(/-/g, '') ||
      `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;
    const id = `${Date.now().toString(36)}-${random.slice(0, 16)}`;
    const folder = `${safeName(String(exportFilename || 'chat_export').replace(/\.xlsx$/i, ''))}_attachments_${id}`;
    const files = [];
    for (const message of messages || []) {
      for (const entry of message.attachmentEntries || []) {
        files.push(makeFile(folder, files.length, entry, message.id));
      }
    }
    return { id, folder, files };
  }

  function makeFile(folder, index, source, messageId) {
    const name = String(source.name || `Вложение без названия ${index + 1}`);
    const url = validURL(source.url);
    const localCopy = !url && globalThis.SessionImages?.validReference(source.sessionImageKey, source.sessionImagePath);
    const available = Boolean(url || localCopy);
    const urlReason = !available && missingReasons.has(source.urlReason) ? source.urlReason : '';
    let basename = safeName(name);
    if (localCopy) {
      const extension = source.sessionImagePath.slice(source.sessionImagePath.lastIndexOf('.'));
      basename = safeName(basename.replace(/\.[a-z0-9]{1,12}$/i, '') + extension);
    }
    return { name, url, filename: `${folder}/${String(index + 1).padStart(4, '0')}_${basename}`,
      ...(typeof messageId === 'string' && messageId ? { messageId } : {}),
      ...(localCopy ? { sessionImageKey: source.sessionImageKey, sessionImagePath: source.sessionImagePath } : {}),
      ...(urlReason ? { urlReason } : {}),
      state: available ? 'pending' : 'missing', downloadId: null,
      reason: available ? '' : missingReasons.get(urlReason) || MISSING_URL_REASON };
  }

  function acceptJob(input) {
    if (!input || !/^[a-z0-9-]{8,80}$/i.test(input.id) || typeof input.folder !== 'string' ||
        !input.folder || /[\x00-\x1f<>:"/\\|?*]/.test(input.folder) || /^(\.|\.\.)$/.test(input.folder) ||
        !input.folder.endsWith(input.id) || !Array.isArray(input.files)) throw new Error('Некорректный список вложений.');
    return { id: input.id, folder: input.folder,
      ...(/^[a-z0-9-]{8,80}$/i.test(input.diagnosticRunId || '') ? { diagnosticRunId: input.diagnosticRunId } : {}),
      files: input.files.map((file, index) => makeFile(input.folder, index, file, file.messageId)) };
  }

  const MIME_EXTENSIONS = {
    'image/jpeg': 'jpg', 'image/png': 'png', 'image/gif': 'gif', 'image/webp': 'webp',
    'image/avif': 'avif', 'image/heic': 'heic', 'image/heif': 'heif', 'image/svg+xml': 'svg',
    'image/bmp': 'bmp', 'image/tiff': 'tiff', 'video/mp4': 'mp4', 'video/webm': 'webm',
    'video/quicktime': 'mov', 'video/x-matroska': 'mkv', 'audio/mpeg': 'mp3', 'audio/mp4': 'm4a',
    'audio/ogg': 'ogg', 'audio/webm': 'webm', 'audio/wav': 'wav', 'audio/x-wav': 'wav',
    'audio/flac': 'flac', 'application/pdf': 'pdf', 'application/zip': 'zip', 'text/plain': 'txt',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx'
  };

  function determineFilename(filename, item) {
    if (/\.[a-z0-9]{1,12}$/i.test(filename)) return filename;
    const mime = String(item.mime || '').toLowerCase().split(';')[0].trim();
    const proposed = String(item.filename || '').split(/[\\/]/).pop();
    const extension = MIME_EXTENSIONS[mime] || proposed.match(/\.([a-z][a-z0-9]{0,9})$/i)?.[1];
    return extension ? `${filename}.${extension.toLowerCase()}` : filename;
  }

  function buildStatus(job, permissionRequired = false) {
    if (!job) return null;
    const count = state => job.files.filter(file => file.state === state).length;
    const active = count('starting') + count('in_progress');
    const queued = count('pending');
    const done = active === 0 && queued === 0;
    const paused = Boolean(job.paused) && !job.stopped && !done;
    return { id: job.id, folder: job.folder, total: job.files.length,
      completed: count('complete'), failed: count('failed'), missing: count('missing'),
      cancelled: count('cancelled'), stopped: Boolean(job.stopped), active, queued,
      done, paused,
      pauseError: !job.stopped && job.files.some(file =>
        ['starting', 'in_progress'].includes(file.state) && (file.pauseError || paused && !file.paused))
        ? paused ? 'Очередь на паузе, но часть начатых загрузок браузер пока не подтвердил как приостановленные. Проверьте список загрузок браузера.'
          : 'Часть загрузок пока не удалось продолжить. Проверьте список загрузок браузера или нажмите «Продолжить» ещё раз.' : '',
      stopError: job.files.some(file => file.stopError) ? 'Часть загрузок пока не удалось отменить. Проверьте список загрузок браузера или нажмите «Стоп» ещё раз.' : '',
      permissionRequired: permissionRequired && job.files.some(file =>
        ['pending', 'starting', 'in_progress', 'failed', 'cancelled'].includes(file.state) && Boolean(file.url || file.sessionImageKey)),
      firstDownloadId: job.files.find(file => file.state === 'complete' && Number.isInteger(file.downloadId))?.downloadId ?? null,
      failures: job.files.filter(file => ['failed', 'missing'].includes(file.state))
        .map(file => ({ name: file.messageId ? `${file.name} (сообщение ${file.messageId})` : file.name,
          reason: file.reason || (file.state === 'missing' ? MISSING_URL_REASON : 'Не удалось скачать файл.'),
          ...(safeErrorCode(file.errorCode) ? { errorCode: safeErrorCode(file.errorCode) } : {}) })) };
  }

  return { validURL, safeName, safeErrorCode, createJob, acceptJob, determineFilename, buildStatus };
});
