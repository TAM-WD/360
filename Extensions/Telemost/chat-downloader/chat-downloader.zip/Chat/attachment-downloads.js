(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.AttachmentDownloads = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function validURL(value) {
    try {
      const url = new URL(value);
      return ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password ? url.href : '';
    } catch { return ''; }
  }

  function safeName(value, fallback = 'Вложение') {
    let name = String(value || '').normalize('NFC')
      .replace(/\s+\(\d[\d\s.,]*\s*(?:[КМГТ]?Б|[KMGT]?B|bytes?)\)$/iu, '')
      .replace(/[\x00-\x1f\x7f<>:"/\\|?*\u202a-\u202e\u2066-\u2069]/g, '_')
      .replace(/^[.\s]+|[.\s]+$/g, '');
    if (!name) name = fallback;
    if (/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(name)) name = `_${name}`;
    const extension = name.match(/\.[a-z0-9]{1,12}$/i)?.[0] || '';
    let stem = extension ? name.slice(0, -extension.length) : name;
    while (new TextEncoder().encode(stem + extension).length > 150) stem = Array.from(stem).slice(0, -1).join('');
    return stem + extension;
  }

  function createJob(messages, exportFilename) {
    const random = globalThis.crypto?.randomUUID?.().replace(/-/g, '') ||
      `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;
    const id = `${Date.now().toString(36)}-${random.slice(0, 16)}`;
    const folder = `${safeName(String(exportFilename || 'chat_export').replace(/\.xlsx$/i, ''))}_attachments_${id}`;
    const files = [];
    for (const message of messages || []) {
      for (const entry of message.attachmentEntries || []) {
        const name = String(entry.name || 'Вложение');
        const url = validURL(entry.url);
        files.push({ name, url, filename: `${folder}/${String(files.length + 1).padStart(4, '0')}_${safeName(name)}`,
          state: url ? 'pending' : 'missing', downloadId: null, reason: url ? '' : 'В сообщении нет ссылки на файл.' });
      }
    }
    return { id, folder, files };
  }

  function acceptJob(input) {
    if (!input || !/^[a-z0-9-]{8,80}$/i.test(input.id) || typeof input.folder !== 'string' ||
        !input.folder || /[\x00-\x1f<>:"/\\|?*]/.test(input.folder) || /^(\.|\.\.)$/.test(input.folder) ||
        !input.folder.endsWith(input.id) || !Array.isArray(input.files)) throw new Error('Некорректный список вложений.');
    return { id: input.id, folder: input.folder, files: input.files.map((file, index) => {
      const name = String(file.name || 'Вложение');
      const url = validURL(file.url);
      return { name, url, filename: `${input.folder}/${String(index + 1).padStart(4, '0')}_${safeName(name)}`,
        state: url ? 'pending' : 'missing', downloadId: null, reason: url ? '' : 'В сообщении нет ссылки на файл.' };
    }) };
  }

  const MIME_EXTENSIONS = {
    'image/jpeg': 'jpg', 'image/png': 'png', 'image/gif': 'gif', 'image/webp': 'webp',
    'image/avif': 'avif', 'image/heic': 'heic', 'image/heif': 'heif', 'image/svg+xml': 'svg',
    'image/bmp': 'bmp', 'image/tiff': 'tiff', 'video/mp4': 'mp4', 'video/webm': 'webm',
    'video/quicktime': 'mov', 'video/x-matroska': 'mkv', 'audio/mpeg': 'mp3', 'audio/mp4': 'm4a',
    'audio/ogg': 'ogg', 'audio/webm': 'webm', 'audio/wav': 'wav', 'audio/x-wav': 'wav',
    'audio/flac': 'flac', 'application/pdf': 'pdf', 'application/zip': 'zip', 'text/plain': 'txt',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx'
  };

  function determineFilename(filename, item) {
    if (/\.[a-z0-9]{1,12}$/i.test(filename)) return filename;
    const mime = String(item.mime || '').toLowerCase().split(';')[0].trim();
    const proposed = String(item.filename || '').split(/[\\/]/).pop();
    const extension = MIME_EXTENSIONS[mime] || proposed.match(/\.([a-z][a-z0-9]{0,9})$/i)?.[1];
    return extension ? `${filename}.${extension.toLowerCase()}` : filename;
  }

  function buildStatus(job, permissionRequired = false) {
    if (!job) return null;
    const count = state => job.files.filter(file => file.state === state).length;
    const active = count('starting') + count('in_progress');
    const queued = count('pending');
    return { id: job.id, folder: job.folder, total: job.files.length,
      completed: count('complete'), failed: count('failed'), missing: count('missing'), active, queued,
      done: active === 0 && queued === 0,
      permissionRequired: permissionRequired && job.files.some(file =>
        ['pending', 'starting', 'in_progress', 'failed'].includes(file.state) && Boolean(file.url)),
      firstDownloadId: job.files.find(file => file.state === 'complete' && Number.isInteger(file.downloadId))?.downloadId ?? null,
      failures: job.files.filter(file => ['failed', 'missing'].includes(file.state))
        .map(file => ({ name: file.name, reason: file.reason || 'Не удалось скачать файл.' })) };
  }

  return { validURL, safeName, createJob, acceptJob, determineFilename, buildStatus };
});
